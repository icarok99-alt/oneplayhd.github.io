# -*- coding: utf-8 -*-
import sys
import os
import time
import json
import html
import calendar
import urllib.parse
import xml.etree.ElementTree as ET
import re
from datetime import datetime
import base64
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests

# =========================
# Configurações do Addon
# =========================
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_HANDLE = int(sys.argv[1])

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
HEADERS = {'User-Agent': USER_AGENT}

HOME = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
addonIcon = xbmcvfs.translatePath(os.path.join(HOME, 'icon.png'))
addonFanart = xbmcvfs.translatePath(os.path.join(HOME, 'fanart.jpg'))
if not xbmcvfs.exists(addonFanart):
    addonFanart = xbmcvfs.translatePath(os.path.join(HOME, 'fanart.png'))
QR_IMAGE_PATH = xbmcvfs.translatePath(os.path.join(HOME, 'resources', 'media', 'qr_whatsapp_paulo.png'))

USERNAME = ''
PASSWORD = ''
ENABLE_EPG = 'false'
ENABLE_ADULT = 'false'

def refresh_runtime_settings():
    global USERNAME, PASSWORD, ENABLE_EPG, ENABLE_ADULT
    try:
        USERNAME = (ADDON.getSetting('username') or '').strip()
        PASSWORD = (ADDON.getSetting('password') or '').strip()
        ENABLE_EPG = (ADDON.getSetting('enable_epg') or 'false').lower()
        ENABLE_ADULT = (ADDON.getSetting('enable_adult') or 'false').lower()
    except Exception as e:
        log(f"Falha ao reler configurações: {e}", xbmc.LOGERROR)
        USERNAME = ''
        PASSWORD = ''
        ENABLE_EPG = 'false'
        ENABLE_ADULT = 'false'


def has_addon(addon_id):
    try:
        return xbmc.getCondVisibility(f'System.HasAddon({addon_id})')
    except Exception:
        return False


def strip_kodi_url_headers(url):
    try:
        return (url or '').split('|', 1)[0]
    except Exception:
        return url or ''


def detect_stream_manifest_type(url):
    clean_url = strip_kodi_url_headers(url).lower()
    if '.m3u8' in clean_url or 'output=m3u8' in clean_url or 'type=m3u8' in clean_url:
        return 'hls'
    if '.mpd' in clean_url:
        return 'mpd'
    return ''


def detect_stream_extension(url):
    clean_url = strip_kodi_url_headers(url).lower()
    if not clean_url:
        return ''
    base = clean_url.split('?', 1)[0].split('#', 1)[0]
    _, ext = os.path.splitext(base)
    return ext.lstrip('.')


def detect_stream_mime_type(url, stream_kind=''):
    manifest_type = detect_stream_manifest_type(url)
    if manifest_type == 'hls':
        return 'application/vnd.apple.mpegurl'
    if manifest_type == 'mpd':
        return 'application/dash+xml'

    ext = detect_stream_extension(url)
    if ext == 'ts':
        return 'video/mp2t'
    if ext == 'mp4':
        return 'video/mp4'
    if ext == 'mkv':
        return 'video/x-matroska'
    if ext == 'avi':
        return 'video/x-msvideo'
    if ext == 'mov':
        return 'video/quicktime'
    if ext == 'wmv':
        return 'video/x-ms-wmv'
    if ext == 'flv':
        return 'video/x-flv'
    if ext == 'webm':
        return 'video/webm'
    if ext == 'm4v':
        return 'video/x-m4v'
    if ext in ('mpg', 'mpeg'):
        return 'video/mpeg'

    if stream_kind == 'live':
        return 'video/mp2t'
    return ''


def configure_live_stream_listitem(li, url):
    manifest_type = detect_stream_manifest_type(url)
    mime_type = detect_stream_mime_type(url, 'live')

    try:
        li.setContentLookup(False)
    except Exception:
        pass

    if mime_type:
        try:
            li.setMimeType(mime_type)
        except Exception:
            pass

    # Melhor caminho para live quando disponível: ffmpegdirect.
    # Se não existir, o Kodi cai no player nativo com mime correto.
    try:
        if has_addon('inputstream.ffmpegdirect'):
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            if manifest_type:
                li.setProperty('inputstream.ffmpegdirect.manifest_type', manifest_type)
    except Exception as e:
        log(f"Falha ao configurar inputstream live: {e}", xbmc.LOGDEBUG)


def configure_vod_stream_listitem(li, url, stream_kind='vod'):
    manifest_type = detect_stream_manifest_type(url)
    mime_type = detect_stream_mime_type(url, stream_kind)
    ext = detect_stream_extension(url)

    try:
        li.setContentLookup(False)
    except Exception:
        pass

    if mime_type:
        try:
            li.setMimeType(mime_type)
        except Exception:
            pass

    # Arquivos diretos (mp4/mkv/avi...) ficam no player nativo.
    # HLS/DASH/TS ganham inputstream quando disponível.
    try:
        if (manifest_type or ext == 'ts') and has_addon('inputstream.ffmpegdirect'):
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
            if manifest_type:
                li.setProperty('inputstream.ffmpegdirect.manifest_type', manifest_type)
    except Exception as e:
        log(f"Falha ao configurar inputstream VOD: {e}", xbmc.LOGDEBUG)


DNS_LIST_B64 = [
    "aHR0cDovL2JlYW50ZWMuY2E=",
    "aHR0cDovL3J0ZXh0LnZpcA==",
    "aHR0cDovL29uZXBsYXlmYXN0cHJvLnh5eg==",
    "aHR0cDovL2h4MnAueHl6",
    "aHR0cDovL3RvcDJnby5zYnM="
]

def b64_decode(text):
    try:
        return base64.b64decode(text).decode('utf-8')
    except Exception as e:
        log(f"Falha ao decodificar DNS em base64: {e}", xbmc.LOGERROR)
        return ''

def get_base_url():
    try:
        idx = int(ADDON.getSetting("server_choice") or "0")
    except Exception:
        idx = 0

    if not DNS_LIST_B64:
        return ''

    if idx < 0 or idx >= len(DNS_LIST_B64):
        idx = 0

    return b64_decode(DNS_LIST_B64[idx])

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EPG_XML_PATH = os.path.join(PROFILE_DIR, 'epg.xml')
EPG_META_PATH = os.path.join(PROFILE_DIR, 'epg_meta.json')
EPG_TTL = 24 * 3600

_EPG_PARSED = None

DESC_TTL = 7 * 24 * 3600
VOD_DESC_CACHE_PATH = os.path.join(PROFILE_DIR, 'vod_desc_cache.json')
SERIES_DESC_CACHE_PATH = os.path.join(PROFILE_DIR, 'series_desc_cache.json')
SEARCH_STATE_PATH = os.path.join(PROFILE_DIR, 'search_state.json')
_TAG_RE = re.compile(r'<[^>]+>')

# =========================
# Utilitários
# =========================
def clear_desc_caches():
    try:
        if os.path.exists(VOD_DESC_CACHE_PATH):
            os.remove(VOD_DESC_CACHE_PATH)
        if os.path.exists(SERIES_DESC_CACHE_PATH):
            os.remove(SERIES_DESC_CACHE_PATH)
        log("Caches de sinopse limpos por mudança de servidor.")
    except Exception as e:
        log(f"Falha ao limpar cache de sinopse: {e}", xbmc.LOGERROR)

def show_expire_popup(days_left):
    if days_left is None:
        return

    try:
        warn_days = int(ADDON.getSetting('expire_warning_days')) + 1
    except Exception:
        warn_days = 3

    dialog = xbmcgui.Dialog()

    def center_text(text):
        # Adiciona linhas no topo e no final para simular centralização
        return "\n\n\n" + text + "\n\n\n"

    if days_left < 0:
        # Conta vencida
        message = center_text(
            "[COLOR red][B]SUA CONTA ESTÁ VENCIDA[/B][/COLOR]\n"
            "[COLOR white][B]Renove agora para continuar usando o serviço.[/B][/COLOR]"
        )
        dialog.ok("[COLOR white][B]CONTA VENCIDA[/B][/COLOR]", message)
        return

    if days_left <= warn_days:
        # Aviso de vencimento
        message = center_text(
            f"[COLOR white]Sua conta vence em: [B][COLOR yellow]{days_left} dia(s)[/COLOR][/B][/COLOR]\n"
            "[COLOR white]Evite bloqueio renovando com antecedência.[/COLOR]"
        )
        dialog.ok("[COLOR white][B]AVISO DE VENCIMENTO[/B][/COLOR]", message)

def color(text, color_name):
    return f"[COLOR {color_name}]{text}[/COLOR]"

def format_date(text):
    return color(text, 'lightblue')

def get_status_color(status):
    status = (status or '').lower()
    if status in ['active', 'ativo']:
        return 'lime'
    if status in ['expired', 'expirado', 'disabled']:
        return 'red'
    return 'orange'

def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

refresh_runtime_settings()

def show_dialog(title, message):
    xbmcgui.Dialog().ok(title, message)


class QRCodeDialog(xbmcgui.WindowXMLDialog):
    CONTROL_IMAGE = 1001
    CONTROL_OK = 1002
    ACTION_PREVIOUS_MENU = 10
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def __init__(self, *args, **kwargs):
        self.image_path = kwargs.pop('image_path', '')
        super().__init__(*args, **kwargs)

    def onInit(self):
        try:
            image_control = self.getControl(self.CONTROL_IMAGE)
            try:
                image_control.setImage(self.image_path, useCache=False)
            except TypeError:
                image_control.setImage(self.image_path)
        except Exception as e:
            log(f"Falha ao carregar imagem do QR no diálogo: {e}", xbmc.LOGERROR)

        try:
            self.setFocusId(self.CONTROL_OK)
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == self.CONTROL_OK:
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = int(action)

        if action_id in (self.ACTION_PREVIOUS_MENU, self.ACTION_NAV_BACK, self.ACTION_BACKSPACE):
            self.close()
        else:
            super().onAction(action)


def show_qr_code():
    message = (
        "[B]Escaneie o QR Code para falar com o suporte[/B]\n\n"
        "[COLOR white]Se o QR não abrir, use o WhatsApp:[/COLOR]\n"
        "[COLOR gold](31) 99594-9574[/COLOR]"
    )

    if xbmcvfs.exists(QR_IMAGE_PATH):
        try:
            dialog = QRCodeDialog('QRCodeDialog.xml', ADDON.getAddonInfo('path'), 'Default', '1080i', image_path=QR_IMAGE_PATH)
            dialog.doModal()
            del dialog
            return
        except Exception as e:
            log(f"Falha ao abrir QR Code em janela customizada: {e}", xbmc.LOGERROR)

    xbmcgui.Dialog().ok("QR Code", message)

def build_url(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)

def ensure_profile_dir():
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdir(PROFILE_DIR)

def load_search_state():
    try:
        ensure_profile_dir()
        if not xbmcvfs.exists(SEARCH_STATE_PATH):
            return {}
        with open(SEARCH_STATE_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception as e:
        log(f"Falha ao ler estado da pesquisa: {e}", xbmc.LOGDEBUG)
        return {}

def save_search_state(data):
    try:
        ensure_profile_dir()
        with open(SEARCH_STATE_PATH, 'w', encoding='utf-8') as f:
            json.dump(data or {}, f)
    except Exception as e:
        log(f"Falha ao salvar estado da pesquisa: {e}", xbmc.LOGDEBUG)

def remember_search(scope, query, results=None):
    state = load_search_state()
    state['last_scope'] = (scope or 'all').strip()
    state['last_query'] = (query or '').strip()
    if results is not None:
        state['last_results'] = results if isinstance(results, list) else []
    save_search_state(state)

def mark_resume_search(scope, query):
    state = load_search_state()
    state['resume_once'] = True
    state['last_scope'] = (scope or state.get('last_scope') or 'all').strip()
    state['last_query'] = (query or state.get('last_query') or '').strip()
    save_search_state(state)

def pop_resume_search():
    state = load_search_state()
    query = (state.get('last_query') or '').strip()
    scope = (state.get('last_scope') or 'all').strip()
    if state.get('resume_once') and query:
        state['resume_once'] = False
        save_search_state(state)
        cached_results = state.get('last_results')
        if isinstance(cached_results, list):
            return {'scope': scope, 'query': query, 'results': cached_results}
        return {'scope': scope, 'query': query}
    return None

def has_valid_credentials():
    return bool(USERNAME and PASSWORD and get_base_url())

def open_settings_and_refresh():
    ADDON.openSettings()
    refresh_runtime_settings()
    return has_valid_credentials()


def build_root_menu():
    items = [{
        'title': 'Entrar',
        'mode': 'enter',
        'plot': 'Acesso ao OnePlay VIP. Configure sua conta e entre no catálogo.',
        'fanart': addonFanart
        }
    ]
    build_menu(items)


def retry_after_settings_change(previous_fingerprint=''):
    try:
        xbmc.sleep(150)
    except Exception:
        pass

    refresh_runtime_settings()

    if not has_valid_credentials():
        return None

    current_fingerprint = fingerprint()
    if previous_fingerprint and current_fingerprint == previous_fingerprint:
        return None

    return get_json("")

def get_param_map():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        parsed = urllib.parse.urlparse(sys.argv[2])
        q = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        for k, v in q.items():
            params[k] = v[0] if isinstance(v, list) else v
    return params

def get_param(name, default=""):
    return PARAMS.get(name, default)

def fingerprint():
    BASE_URL = get_base_url()
    return f"{BASE_URL}|{USERNAME}|{PASSWORD}"

def safe_requests_get(url, **kw):
    kw.setdefault('headers', HEADERS)
    kw.setdefault('timeout', 30)

    retries = int(kw.pop('retries', 2))
    backoff = float(kw.pop('backoff', 1.0))
    last_exc = None
    for attempt in range(retries + 1):
        try:
            r = requests.get(url, **kw)
            if r.status_code == 429 and attempt < retries:
                time.sleep(backoff * (2 ** attempt))
                continue
            r.raise_for_status()
            return r
        except requests.RequestException as e:
            last_exc = e
            if isinstance(e, requests.HTTPError):
                resp = getattr(e, 'response', None)
                if resp is not None and resp.status_code == 429 and attempt < retries:
                    time.sleep(backoff * (2 ** attempt))
                    continue
            break
    raise last_exc if last_exc else requests.RequestException("Falha na requisição")

def open_settings_after_error(context='erro'):
    try:
        ADDON.openSettings()
        refresh_runtime_settings()
    except Exception as exc:
        log(f"Falha ao abrir configurações após {context}: {exc}", xbmc.LOGERROR)


def show_settings_error(title, message, context='erro de configuração'):
    xbmcgui.Dialog().ok(title, message)
    open_settings_after_error(context)


def show_login_error(open_settings=True):
    msg = (
        "[B][COLOR red]Não foi possível entrar[/COLOR][/B]\n\n"
        "[COLOR white]Verifique se o [B]usuário[/B], a [B]senha[/B] e o [B]portal[/B] estão corretos.[/COLOR]\n\n"
        "[COLOR gold]Dicas:[/COLOR]\n"
        "[COLOR white]• Confirme se não há espaço extra no login[/COLOR]\n"
        "[COLOR white]• Verifique se a conta ainda está ativa[/COLOR]\n"
        "[COLOR white]• Confira se o portal selecionado é o certo[/COLOR]"
    )
    xbmcgui.Dialog().ok("Erro de acesso", msg)
    if open_settings:
        open_settings_after_error('erro de login')

def get_json(endpoint):
    BASE_URL = get_base_url()
    if not all([BASE_URL, USERNAME, PASSWORD]):
        log("Credenciais incompletas.", xbmc.LOGERROR)
        show_settings_error("Configuração necessária", "Configure portal, usuário e senha nas configurações.", "configuração necessária")
        return None

    query = urllib.parse.urlencode({'username': USERNAME, 'password': PASSWORD})
    url = f"{BASE_URL.rstrip('/')}/player_api.php?{query}"
    if endpoint:
        url += f"&{endpoint}"
    log("Chamando API player_api.php")

    try:
        r = safe_requests_get(url)

        # alguns portais devolvem vazio, HTML ou texto quebrado quando login falha
        raw = (r.text or '').strip()
        if not raw:
            log("Resposta vazia da API.", xbmc.LOGERROR)
            show_login_error()
            return None

        try:
            data = r.json()
        except ValueError:
            log("Resposta inválida (não-JSON) da API.", xbmc.LOGERROR)

            raw_lower = raw.lower()
            if (
                '<html' in raw_lower or
                'access denied' in raw_lower or
                'unauthorized' in raw_lower or
                'invalid' in raw_lower or
                'username' in raw_lower or
                'password' in raw_lower
            ):
                show_login_error()
            else:
                show_settings_error(
                    "Erro de comunicação",
                    "O servidor respondeu em formato inválido.\nVerifique o portal e tente novamente.",
                    "erro de comunicação"
                )
            return None

        # xtream costuma retornar auth=0 quando login falha
        user_info = data.get('user_info', {}) if isinstance(data, dict) else {}
        auth = str(user_info.get('auth', '1')).strip()
        status = str(user_info.get('status', '')).strip().lower()

        if auth == '0':
            log("API retornou auth=0.", xbmc.LOGERROR)
            show_login_error()
            return None

        if status in ['disabled', 'banned']:
            show_settings_error(
                "Acesso bloqueado",
                "Sua conta está bloqueada ou desativada.\nConfira o portal/usuário ou entre em contato com o suporte.",
                "acesso bloqueado"
            )
            return None

        if status in ['expired', 'expirado']:
            show_settings_error(
                "Conta vencida",
                "Sua conta está vencida.\nRenove ou confira o portal/usuário para continuar.",
                "conta vencida"
            )
            return None

        return data

    except requests.RequestException as e:
        try:
            status = e.response.status_code if getattr(e, 'response', None) else None
        except Exception:
            status = None

        log(f"Erro na requisição: {e}", xbmc.LOGERROR)

        if status == 429:
            show_dialog("Erro 429", "Muitas requisições para a API.\nTente novamente em instantes.")
        elif status in (401, 403):
            show_login_error()
        else:
            show_settings_error(
                "Erro de conexão",
                "Não foi possível comunicar com o servidor.\nVerifique o portal e tente novamente.",
                "erro de conexão"
            )

    return None

# =========================
# Descrições (helpers + cache)
# =========================
def clean_plot(text):
    text = html.unescape(text or '')
    text = _TAG_RE.sub('', text)
    return text.strip()

def desc_cache_load(path):
    ensure_profile_dir()
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f) or {}
        except Exception:
            return {}
    return {}

def desc_cache_save(path, cache):
    try:
        ensure_profile_dir()
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Falha ao salvar cache de descrições: {e}", xbmc.LOGERROR)

def desc_cache_get(cache, key):
    k = str(key)
    e = cache.get(k)
    if not isinstance(e, dict):
        return (False, '')
    fetched_at = e.get('fetched_at', 0)
    if not fetched_at or (time.time() - fetched_at) > DESC_TTL:
        return (False, '')
    return (True, e.get('plot', '') or '')

def desc_cache_put(cache, key, plot):
    cache[str(key)] = {'plot': plot or '', 'fetched_at': time.time()}

def extract_vod_plot(vod_info_json):
    if not isinstance(vod_info_json, dict):
        return ''
    info = vod_info_json.get('info') or {}
    movie_data = vod_info_json.get('movie_data') or {}
    plot = (
        info.get('plot')
        or info.get('description')
        or movie_data.get('plot')
        or movie_data.get('description')
        or ''
    )
    return clean_plot(plot)

def extract_series_plot(series_info_json):
    if not isinstance(series_info_json, dict):
        return ''
    info = series_info_json.get('info') or {}
    plot = (
        info.get('plot')
        or info.get('description')
        or info.get('overview')
        or ''
    )
    return clean_plot(plot)

def get_vod_plot_cached(vod_id):
    cache = desc_cache_load(VOD_DESC_CACHE_PATH)
    has, plot = desc_cache_get(cache, vod_id)
    if has:
        return plot

    vod_info = get_json(f"action=get_vod_info&vod_id={vod_id}")
    plot = extract_vod_plot(vod_info)
    desc_cache_put(cache, vod_id, plot)
    desc_cache_save(VOD_DESC_CACHE_PATH, cache)
    return plot

def get_series_plot_cached(series_id):
    cache = desc_cache_load(SERIES_DESC_CACHE_PATH)
    has, plot = desc_cache_get(cache, series_id)
    if has:
        return plot

    series_info = get_json(f"action=get_series_info&series_id={series_id}")
    plot = extract_series_plot(series_info)
    desc_cache_put(cache, series_id, plot)
    desc_cache_save(SERIES_DESC_CACHE_PATH, cache)
    return plot


# =========================
# EPG (cache + parsing)
# =========================
def epg_meta_load():
    if os.path.exists(EPG_META_PATH):
        try:
            with open(EPG_META_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def epg_meta_save(meta):
    try:
        with open(EPG_META_PATH, 'w', encoding='utf-8') as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Falha ao salvar meta EPG: {e}", xbmc.LOGERROR)

def epg_should_refresh():
    meta = epg_meta_load()
    fp = fingerprint()
    meta_fp = meta.get('fingerprint')
    fetched_at = meta.get('fetched_at', 0)
    if meta_fp != fp:
        log("Fingerprint mudou (portal/usuário/senha). Renovando EPG e limpando caches.")
        clear_desc_caches()
        return True
    if not os.path.exists(EPG_XML_PATH):
        log("EPG não existe. Baixando.")
        return True
    if (time.time() - fetched_at) >= EPG_TTL:
        log("EPG expirado. Renovando.")
        return True
    return False

def epg_download():
    ensure_profile_dir()
    BASE_URL = get_base_url()
    url = f"{BASE_URL.rstrip('/')}/xmltv.php?username={USERNAME}&password={PASSWORD}"
    log(f"Baixando EPG: {url}")
    r = safe_requests_get(url)
    with open(EPG_XML_PATH, 'w', encoding='utf-8') as f:
        f.write(r.text)
    epg_meta_save({'fingerprint': fingerprint(), 'fetched_at': time.time()})

def parse_xmltv_time(ts):
    if not ts:
        return int(time.time())
    ts = ts.strip()
    if len(ts) < 14 or not ts[:14].isdigit():
        log(f"Timestamp XMLTV inválido: {ts}")
        return int(time.time())

    base = ts[:14]
    try:
        dt = datetime.strptime(base, "%Y%m%d%H%M%S")
    except Exception:
        return int(time.time())

    offset_secs = 0
    rest = ts[14:].strip()
    if rest:
        rest = rest.replace(' ', '')
        if rest.startswith(('+', '-')) and len(rest) >= 5:
            try:
                sign = 1 if rest[0] == '+' else -1
                hh = int(rest[1:3])
                mm = int(rest[3:5])
                offset_secs = sign * (hh * 3600 + mm * 60)
            except Exception:
                offset_secs = 0

    epoch = calendar.timegm(dt.timetuple()) - offset_secs
    return epoch if epoch > 0 else int(time.time())

def normalize_epg_channel_id(cid):
    if not cid:
        return ''
    return cid.strip().lower().replace('&amp;', '&')

def epg_load_parsed():
    global _EPG_PARSED

    if epg_should_refresh():
        try:
            epg_download()
        except Exception as e:
            log(f"Falha ao baixar EPG: {e}", xbmc.LOGERROR)
            _EPG_PARSED = {'channels': {}, 'progs': {}}
            return _EPG_PARSED

    if not os.path.exists(EPG_XML_PATH):
        _EPG_PARSED = {'channels': {}, 'progs': {}}
        return _EPG_PARSED

    try:
        tree = ET.parse(EPG_XML_PATH)
        root = tree.getroot()

        channels = {}
        progs = {}

        for c in root.findall(".//channel"):
            cid = normalize_epg_channel_id(c.get('id'))
            dn = (c.findtext('display-name') or '').strip()
            channels[cid] = dn

        for p in root.findall(".//programme"):
            cid = normalize_epg_channel_id(p.get('channel'))

            try:
                start = int(p.get('start_timestamp'))
            except (TypeError, ValueError):
                start = parse_xmltv_time(p.get('start'))

            try:
                stop = int(p.get('stop_timestamp') or p.get('end_timestamp'))
            except (TypeError, ValueError):
                stop = parse_xmltv_time(p.get('stop') or p.get('end'))

            if stop <= start:
                stop = start + 3600

            title = (p.findtext('title') or '').strip()
            desc = (p.findtext('desc') or '').strip()

            if cid not in progs:
                progs[cid] = []

            progs[cid].append({'start': start, 'end': stop, 'title': title, 'desc': desc})

        for cid, arr in progs.items():
            arr.sort(key=lambda x: x['start'])

        _EPG_PARSED = {'channels': channels, 'progs': progs}
        log(f"EPG carregado: canais={len(channels)}, programas={sum(len(v) for v in progs.values())}")
    except Exception as e:
        log(f"Erro parseando EPG: {e}", xbmc.LOGERROR)
        _EPG_PARSED = {'channels': {}, 'progs': {}}

    return _EPG_PARSED

def epg_lookup_current_next(epg_channel_id, epg):
    cid = normalize_epg_channel_id(epg_channel_id)
    now = int(time.time())

    plist = epg['progs'].get(cid, [])
    current, nextp = None, None

    for i, pr in enumerate(plist):
        start = pr.get('start') or now
        end = pr.get('end') or (start + 3600)
        if end <= start:
            end = start + 3600
        pr['start'] = start
        pr['end'] = end

        if start <= now < end:
            current = pr
            if i + 1 < len(plist):
                nextp = plist[i + 1]
            break
        if start > now:
            nextp = pr
            if i - 1 >= 0 and plist[i - 1]['end'] > now:
                current = plist[i - 1]
            break

    return current, nextp

# =========================
# UI (menus)
# =========================
def build_menu(items, mode=None, is_playable=False):
    if not items:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    for item in items:
        label = item.get('title', '')
        li = xbmcgui.ListItem(label=label)

        icon = item.get('icon', addonIcon) or addonIcon
        fanart = item.get('fanart', addonFanart) or addonFanart
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)

        plot = item.get('plot', '') or ''
        info = {'title': label}
        if plot:
            info['plot'] = plot
        li.setInfo('video', info)

        media_type = item.get('media_type') or ''
        if media_type:
            try:
                li.setProperty('mediatype', media_type)
            except Exception:
                pass

        # Context menu: Sinopse (um item por vez => evita 429)
        cm = []
        if item.get('vod_id'):
            cm_url = build_url(mode='show_vod_plot', vod_id=str(item['vod_id']), title=label)
            cm.append(("Sinopse", f'RunPlugin({cm_url})'))
        if item.get('series_id'):
            cm_url = build_url(mode='show_series_plot', series_id=str(item['series_id']), title=label)
            cm.append(("Sinopse", f'RunPlugin({cm_url})'))
        if cm:
            li.addContextMenuItems(cm, replaceItems=False)

        if 'url' in item and is_playable:
            play = item['url'] or ''
            if not play:
                log(f"Ignorando item reproduzível sem URL: {label}", xbmc.LOGDEBUG)
                continue
            if 'User-Agent=' not in play:
                play = play + '|User-Agent=' + USER_AGENT

            li.setProperty('IsPlayable', 'true')

            params = {
                'mode': 'play',
                'url': play,
                'title': label,
                'icon': icon,
                'fanart': fanart,
                'normalplayer': str(item.get('normalplayer', 'false')).lower(),
                'stream_kind': item.get('stream_kind', ''),
                'container_extension': item.get('container_extension', '')
            }
            if item.get('vod_id'):
                params['vod_id'] = str(item['vod_id'])
            if item.get('series_id'):
                params['series_id'] = str(item['series_id'])
            if item.get('from_search'):
                params['from_search'] = str(item.get('from_search')).lower()
            if item.get('search_scope'):
                params['search_scope'] = item.get('search_scope', '')
            if item.get('search_query'):
                params['search_query'] = item.get('search_query', '')

            url = build_url(**params)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)
        else:
            url_params = {'mode': mode} if mode else {'mode': item.get('mode')}
            if 'params' in item:
                qs = urllib.parse.parse_qs(item['params'], keep_blank_values=True)
                for k, v in qs.items():
                    url_params[k] = v[0] if isinstance(v, list) else v
            url = build_url(**url_params)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, item.get('folder', True))

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# =========================
# Funções de dados
# =========================
def get_categories(endpoint):
    data = get_json(endpoint)
    if not data:
        return []

    if isinstance(data, list):
        cats = data
    elif isinstance(data, dict) and 'categories' in data:
        cats = data['categories']
    else:
        cats = list(data.values()) if isinstance(data, dict) else []

    items = []
    for cat in cats:
        name = html.unescape(cat.get('category_name', 'Sem nome'))
        if 'adult' in name.lower() and ENABLE_ADULT.lower() != 'true':
            continue
        items.append({
            'title': name,
            'params': f"category_id={cat.get('category_id', '')}"
        })
    return items

def ensure_epg_loaded():
    global _EPG_PARSED
    if _EPG_PARSED is None:
        _EPG_PARSED = epg_load_parsed()
    return _EPG_PARSED

def annotate_live_with_epg(items_from_api):
    epg = ensure_epg_loaded()
    out = []
    for s in items_from_api:
        name = s.get('title') or s.get('name') or 'Sem nome'
        epg_id = s.get('epg_channel_id')
        current, nextp = epg_lookup_current_next(epg_id, epg) if epg_id else (None, None)

        label = name
        plot = ''
        if current:
            label = f"{name} - {current.get('title', '').strip()}"
            plot += f"Agora: {current.get('title', '').strip()}\n{current.get('desc', '').strip()}\n\n"
        if nextp:
            plot += f"Próximo: {nextp.get('title', '').strip()}\n{nextp.get('desc', '').strip()}"

        s2 = dict(s)
        s2['title'] = label
        if plot.strip():
            s2['plot'] = plot.strip()
        out.append(s2)
    return out

def get_items(endpoint, category_id=None):
    BASE_URL = get_base_url()
    params = f"&category_id={category_id}" if category_id else ""
    data = get_json(f"action={endpoint}{params}")
    if not data:
        return []

    items = []

    if endpoint in ['get_live_streams', 'get_vod_streams']:
        vod_cache = None
        if endpoint == 'get_vod_streams':
            vod_cache = desc_cache_load(VOD_DESC_CACHE_PATH)

        for s in data:
            url = s.get('stream_url', '')
            sid = s.get('stream_id')
            stype = s.get('stream_type', '')
            name = html.unescape(s.get('name', 'Sem nome'))
            icon = s.get('stream_icon', '')
            epg_channel_id = s.get('epg_channel_id') or None
            container_extension = (s.get('container_extension') or 'mp4').lower()

            if sid:
                if endpoint == 'get_live_streams':
                    url = f'{BASE_URL.rstrip("/")}/live/{USERNAME}/{PASSWORD}/{sid}.m3u8'
                else:
                    url = f'{BASE_URL.rstrip("/")}/{stype}/{USERNAME}/{PASSWORD}/{sid}.{container_extension}'

            if not url:
                log(f"Ignorando item sem URL retornado pela API: {name}", xbmc.LOGDEBUG)
                continue

            item = {
                'title': name,
                'url': url,
                'icon': icon,
                'fanart': addonFanart,
                'container_extension': container_extension
            }

            if epg_channel_id:
                item['epg_channel_id'] = epg_channel_id

            if endpoint == 'get_live_streams':
                item['media_type'] = 'video'
                item['normalplayer'] = 'false'
                item['stream_kind'] = 'live'
            else:
                item['media_type'] = 'movie'
                item['normalplayer'] = 'false'
                item['stream_kind'] = 'vod'

            # Filme: NÃO buscar vod_info aqui (evita 429). Só usa cache/lista.
            if endpoint == 'get_vod_streams' and sid:
                item['vod_id'] = sid
                plot = clean_plot(s.get('plot') or s.get('description') or '')
                if not plot and vod_cache is not None:
                    has, cached_plot = desc_cache_get(vod_cache, sid)
                    if has:
                        plot = cached_plot
                if plot:
                    item['plot'] = plot

            items.append(item)

        if endpoint == 'get_live_streams' and ENABLE_EPG.lower() == 'true':
            items = annotate_live_with_epg(items)

    elif endpoint == 'get_series':
        series_cache = desc_cache_load(SERIES_DESC_CACHE_PATH)

        for s in data:
            icon = (s.get('info', {}) or {}).get('cover_big') or (s.get('info', {}) or {}).get('movie_image', '')
            if not icon:
                backdrops = s.get('backdrop_path') or []
                if isinstance(backdrops, str):
                    backdrops = [backdrops]
                icon = s.get('cover') if s.get('cover') else (backdrops[0] if backdrops else '')

            series_id = s.get('series_id', '')
            title = html.unescape(s.get('name', 'Sem nome'))

            if not series_id:
                log(f"Ignorando série sem series_id: {title}", xbmc.LOGDEBUG)
                continue

            item = {
                'title': title,
                'params': f"series_id={series_id}",
                'icon': icon,
                'series_id': series_id,
                'fanart': addonFanart,
                'media_type': 'tvshow'
            }

            # Série: NÃO buscar series_info aqui (evita 429). Só cache/lista.
            plot = clean_plot(
                s.get('plot')
                or (s.get('info', {}) or {}).get('plot')
                or (s.get('info', {}) or {}).get('overview')
                or ''
            )
            if not plot and series_id:
                has, cached_plot = desc_cache_get(series_cache, series_id)
                if has:
                    plot = cached_plot
            if plot:
                item['plot'] = plot

            items.append(item)

    return items


def get_seasons(series_id):
    BASE_URL = get_base_url()
    data = get_json(f"action=get_series_info&series_id={series_id}")
    if not data:
        return []

    # Aproveita esta chamada (já necessária) para salvar a sinopse da série no cache
    try:
        plot = extract_series_plot(data)
        if plot and series_id:
            cache = desc_cache_load(SERIES_DESC_CACHE_PATH)
            desc_cache_put(cache, series_id, plot)
            desc_cache_save(SERIES_DESC_CACHE_PATH, cache)
    except Exception as e:
        log(f"Falha ao cachear sinopse da série: {e}", xbmc.LOGDEBUG)

    seasons = data.get('episodes', {})
    items = []

    def _season_sort_key(raw_name):
        m = re.search(r'\d+', str(raw_name or ''))
        if m:
            try:
                return (0, int(m.group(0)))
            except Exception:
                pass
        return (1, str(raw_name or '').lower())

    for season_name in sorted(seasons.keys(), key=_season_sort_key):
        episodes = seasons.get(season_name) or []
        ep_list = []
        for index, ep in enumerate(episodes):
            index += 1
            title = html.unescape(ep.get('title', 'Sem título'))
            eid = ep.get('id') or ep.get('episode_id') or ep.get('stream_id')
            ext = (ep.get('info', {}) or {}).get('container_extension') or 'mp4'
            icon = (ep.get('info', {}) or {}).get('cover_big') or (ep.get('info', {}) or {}).get('movie_image', '')
            url = f"{BASE_URL.rstrip('/')}/series/{USERNAME}/{PASSWORD}/{eid}.{ext}" if eid else ep.get('direct_source', '')
            if not url:
                log(f"Ignorando episódio sem URL em {season_name}: {title}", xbmc.LOGDEBUG)
                continue

            ep_list.append({'title': str(index) + ' - ' + title, 'url': url, 'icon': icon, 'fanart': addonFanart, 'media_type': 'episode', 'normalplayer': 'false', 'stream_kind': 'episode', 'container_extension': ext.lower()})

        if not ep_list:
            continue

        payload = urllib.parse.quote(json.dumps(ep_list, ensure_ascii=False), safe='')
        items.append({
            'title': f"Temporada {season_name}",
            'params': f"episodes={payload}&series_id={series_id}"
        })
    return items

def search_global(query, scope='all', max_results=120):
    query = (query or '').strip().lower()
    if not query:
        show_dialog("Aviso", "Digite algo para pesquisar.")
        return []

    if len(query) < 3:
        show_dialog("Aviso", "Digite pelo menos 3 caracteres para pesquisar.")
        return []

    scope_map = {
        'all': [
            ('get_live_streams', 'Canal: ', True),
            ('get_vod_streams', 'Filme: ', True),
            ('get_series', 'Série: ', False)
        ],
        'live': [('get_live_streams', 'Canal: ', True)],
        'vod': [('get_vod_streams', 'Filme: ', True)],
        'series': [('get_series', 'Série: ', False)]
    }
    plan = scope_map.get(scope, scope_map['all'])

    results = []
    seen = set()
    progress = xbmcgui.DialogProgress()
    progress.create('Pesquisa Global', 'Consultando catálogo...')

    try:
        total = len(plan)
        for idx, (endpoint, prefix, playable) in enumerate(plan, start=1):
            if progress.iscanceled():
                break

            label = {
                'get_live_streams': 'Buscando canais...',
                'get_vod_streams': 'Buscando filmes...',
                'get_series': 'Buscando séries...'
            }.get(endpoint, 'Pesquisando...')
            progress.update(int(((idx - 1) / float(total)) * 100), label)

            items = get_items(endpoint)
            for i in items:
                title = (i.get('title', '') or '').strip()
                if not title:
                    continue
                if query not in title.lower():
                    continue

                key = f"{endpoint}|{title.lower()}|{i.get('url', '')}|{i.get('params', '')}"
                if key in seen:
                    continue
                seen.add(key)

                entry = {
                    'title': prefix + title,
                    'icon': i.get('icon', ''),
                    'fanart': i.get('fanart', addonFanart),
                    'plot': i.get('plot', ''),
                    'media_type': i.get('media_type', '')
                }

                if playable:
                    entry['url'] = i.get('url', '')
                    entry['normalplayer'] = i.get('normalplayer', 'false')
                    entry['stream_kind'] = i.get('stream_kind', '')
                    entry['container_extension'] = i.get('container_extension', '')
                    entry['from_search'] = 'true'
                    entry['search_scope'] = scope
                    entry['search_query'] = query
                    if i.get('vod_id'):
                        entry['vod_id'] = i['vod_id']
                else:
                    entry['mode'] = 'seasons'
                    entry['params'] = i.get('params', '')
                    if i.get('series_id'):
                        entry['series_id'] = i['series_id']

                results.append(entry)
                if len(results) >= max_results:
                    progress.update(100, 'Limite de resultados atingido.')
                    return results

            progress.update(int((idx / float(total)) * 100), label)
    finally:
        progress.close()

    if not results:
        show_dialog("Aviso", "Nenhum resultado encontrado.")

    return results

def get_account_info():
    data = get_json("")
    if not data:
        return None

    user_info = data.get('user_info', {})
    if not user_info:
        log("Nenhuma informação de usuário retornada pela API.", xbmc.LOGERROR)
        show_dialog("Erro", "Não foi possível obter informações da conta.")
        return None

    username = user_info.get('username', 'Não informado')
    status = user_info.get('status', 'Não informado')
    max_connections = user_info.get('max_connections', 'Não informado')
    active_connections = user_info.get('active_cons', 'Não informado')

    created_at = user_info.get('created_at', 0)
    exp_date = user_info.get('exp_date', 0)

    try:
        created_at_str = datetime.fromtimestamp(int(created_at)).strftime('%d/%m/%Y') if created_at and str(created_at).isdigit() else 'Não informado'
    except Exception:
        created_at_str = 'Não informado'

    try:
        exp_date_str = datetime.fromtimestamp(int(exp_date)).strftime('%d/%m/%Y') if exp_date and str(exp_date).isdigit() else 'Não informado'
    except Exception:
        exp_date_str = 'Não informado'

    status_color = get_status_color(status)
    info_text = (
        f"[B]Usuário:[/B] {color(username, 'white')}\n"
        f"[B]Status:[/B] {color(status.upper(), status_color)}\n\n"
        f"[B]Criado em:[/B] {format_date(created_at_str)}\n"
        f"[B]Vencimento:[/B] {format_date(exp_date_str)}\n\n"
        f"[B]Conexões Máximas:[/B] {color(max_connections, 'white')}\n"
        f"[B]Conexões Ativas:[/B] {color(active_connections, 'orange')}"
    )

    return info_text

def play_item(url, title, icon, normalplayer, fanart=None, vod_id=None, series_id=None, stream_kind='', container_extension=''):
    # Busca sinopse de forma leve (apenas no item que vai tocar)
    plot = ''
    try:
        if vod_id:
            plot = get_vod_plot_cached(vod_id) or ''
        elif series_id:
            plot = get_series_plot_cached(series_id) or ''
    except Exception as e:
        log(f"Falha ao obter sinopse no play: {e}", xbmc.LOGDEBUG)
        plot = ''

    if url and 'User-Agent=' not in url:
        url = url + '|User-Agent=' + USER_AGENT

    fanart = fanart or addonFanart
    use_resolved = normalplayer == 'false' or stream_kind in ('live', 'vod', 'episode')

    if use_resolved:
        li = xbmcgui.ListItem(path=url)
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        info = {'title': title}
        if plot:
            info['plot'] = plot
        li.setInfo('video', info)
        if stream_kind == 'live':
            configure_live_stream_listitem(li, url)
        elif stream_kind in ('vod', 'episode'):
            if container_extension and not detect_stream_extension(url):
                try:
                    li.setProperty('oneplay.container_extension', container_extension)
                except Exception:
                    pass
            configure_vod_stream_listitem(li, url, stream_kind)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
    else:
        li = xbmcgui.ListItem(label=title, path=url)
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        info = {'title': title}
        if plot:
            info['plot'] = plot
        li.setInfo('video', info)
        if stream_kind in ('vod', 'episode'):
            configure_vod_stream_listitem(li, url, stream_kind)
        player = xbmc.Player()
        player.play(item=url, listitem=li)

def days_until_expire(exp_date):
    try:
        exp_date = int(exp_date)
        if exp_date <= 0:
            return None
        now = int(time.time())
        seconds_left = exp_date - now
        return int(seconds_left // 86400)
    except Exception:
        return None

def get_enter_menu_items():
    settings_item = {
        'title': 'Configurações',
        'mode': 'settings',
        'plot': 'Abra as configurações do addon.',
        'fanart': addonFanart
    }
    return [
        {
            'title': 'Informações da Conta',
            'mode': 'account_info',
            'plot': 'Mostra status da conta, validade, criação e limite de conexões.',
            'fanart': addonFanart
        },
        {
            'title': 'Pesquisa Global',
            'mode': 'search',
            'plot': 'Busca canais, filmes e séries em todo o catálogo.',
            'fanart': addonFanart
        },
        {
            'title': 'TV (Canais Ao Vivo)',
            'mode': 'tv',
            'plot': 'Lista as categorias de canais ao vivo disponíveis.',
            'fanart': addonFanart
        },
        {
            'title': 'Filmes',
            'mode': 'movies',
            'plot': 'Acesse as categorias de filmes disponíveis no portal.',
            'fanart': addonFanart
        },
        {
            'title': 'Séries',
            'mode': 'series',
            'plot': 'Acesse as categorias, temporadas e episódios das séries.',
            'fanart': addonFanart
        },
        settings_item
    ]

# =========================
# Rotas
# =========================
PARAMS = get_param_map()
mode = get_param('mode', 'main')
log(f"Modo: {mode}")

if mode == 'main':
    build_root_menu()

elif mode == 'enter':
    refresh_runtime_settings()
    data = None
    needs_qr = not USERNAME or not PASSWORD

    if not has_valid_credentials():
        if needs_qr:
            show_qr_code()
        if not open_settings_and_refresh():
            show_dialog('Configuração necessária', 'Defina portal, usuário e senha para continuar.')
            build_root_menu()
        else:
            try:
                previous_fingerprint = fingerprint()
                data = get_json("")
                if not data:
                    data = retry_after_settings_change(previous_fingerprint)
                if not data:
                    build_root_menu()
                else:
                    user_info = (data or {}).get('user_info', {})
                    exp_date = user_info.get('exp_date', 0)
                    days_left = days_until_expire(exp_date)
                    show_expire_popup(days_left)
                    build_menu(get_enter_menu_items())
            except Exception as e:
                log(f"Erro aviso vencimento: {e}", xbmc.LOGDEBUG)
                build_root_menu()
    else:
        try:
            previous_fingerprint = fingerprint()
            data = get_json("")
            if not data:
                data = retry_after_settings_change(previous_fingerprint)
            if not data:
                build_root_menu()
            else:
                user_info = (data or {}).get('user_info', {})
                exp_date = user_info.get('exp_date', 0)
                days_left = days_until_expire(exp_date)
                show_expire_popup(days_left)
                build_menu(get_enter_menu_items())
        except Exception as e:
            log(f"Erro aviso vencimento: {e}", xbmc.LOGDEBUG)
            build_root_menu()

elif mode == 'account_info':
    info_text = get_account_info()
    if info_text:
        xbmcgui.Dialog().textviewer("Informações da Conta", info_text)
    else:
        show_dialog("Erro", "Não foi possível obter informações da conta.")

elif mode == 'show_qr':
    show_qr_code()

elif mode == 'settings':
    ADDON.openSettings()

elif mode == 'tv':
    build_menu(get_categories('action=get_live_categories'), 'live_items')

elif mode == 'live_items':
    cid = get_param('category_id')
    build_menu(get_items('get_live_streams', cid), is_playable=True)

elif mode == 'movies':
    build_menu(get_categories('action=get_vod_categories'), 'movie_items')

elif mode == 'movie_items':
    cid = get_param('category_id')
    build_menu(get_items('get_vod_streams', cid), is_playable=True)

elif mode == 'series':
    build_menu(get_categories('action=get_series_categories'), 'series_items')

elif mode == 'series_items':
    cid = get_param('category_id')
    build_menu(get_items('get_series', cid), 'seasons')

elif mode == 'seasons':
    sid = get_param('series_id')
    build_menu(get_seasons(sid), 'episodes')

elif mode == 'episodes':
    eps_json = urllib.parse.unquote(get_param('episodes', '[]'))
    try:
        eps = json.loads(eps_json)
        if not isinstance(eps, list):
            raise ValueError('episodes inválido')
    except Exception as e:
        log(f"Falha ao carregar episódios: {e}", xbmc.LOGERROR)
        eps = []
    build_menu(eps, is_playable=True)

elif mode == 'search':
    resumed = pop_resume_search()
    if resumed:
        cached_results = resumed.get('results') if isinstance(resumed, dict) else None
        if isinstance(cached_results, list):
            build_menu(cached_results, is_playable=True)
        else:
            results = search_global(resumed.get('query', ''), scope=resumed.get('scope', 'all'))
            remember_search(resumed.get('scope', 'all'), resumed.get('query', ''), results)
            build_menu(results, is_playable=True)
    else:
        scopes = [
            ('all', 'Tudo'),
            ('live', 'Canais ao Vivo'),
            ('vod', 'Filmes'),
            ('series', 'Séries')
        ]
        labels = [label for _, label in scopes]
        sel = xbmcgui.Dialog().select('Onde deseja pesquisar?', labels)
        if sel >= 0:
            scope = scopes[sel][0]
            kb = xbmc.Keyboard('', 'Digite pelo menos 3 letras')
            kb.doModal()
            if kb.isConfirmed():
                query = (kb.getText() or '').strip()
                if query:
                    results = search_global(query, scope=scope)
                    remember_search(scope, query, results)
                    build_menu(results, is_playable=True)
                else:
                    show_dialog("Aviso", "Digite algo para pesquisar.")

elif mode == 'show_vod_plot':
    vod_id = get_param('vod_id')
    title = get_param('title', 'Sinopse')
    if vod_id:
        plot = get_vod_plot_cached(vod_id) or ''
        if plot:
            xbmcgui.Dialog().textviewer(title, plot)
        else:
            show_dialog("Sinopse", "Sem descrição disponível.")
    else:
        show_dialog("Erro", "vod_id ausente.")

elif mode == 'show_series_plot':
    series_id = get_param('series_id')
    title = get_param('title', 'Sinopse')
    if series_id:
        plot = get_series_plot_cached(series_id) or ''
        if plot:
            xbmcgui.Dialog().textviewer(title, plot)
        else:
            show_dialog("Sinopse", "Sem descrição disponível.")
    else:
        show_dialog("Erro", "series_id ausente.")

elif mode == 'play':
    url = get_param('url')
    normalplayer = get_param('normalplayer', 'false')
    title = get_param('title', 'Reproduzindo')
    icon = get_param('icon', addonIcon)
    fanart = get_param('fanart', addonFanart)
    vod_id = get_param('vod_id', '') or None
    series_id = get_param('series_id', '') or None
    stream_kind = get_param('stream_kind', '')
    container_extension = get_param('container_extension', '')
    if get_param('from_search', 'false') == 'true' and stream_kind in ('live', 'vod', 'episode'):
        mark_resume_search(get_param('search_scope', 'all'), get_param('search_query', ''))
    play_item(url, title, icon, normalplayer, fanart=fanart, vod_id=vod_id, series_id=series_id, stream_kind=stream_kind, container_extension=container_extension)

else:
    show_dialog("Erro", f"Modo desconhecido: {mode}")