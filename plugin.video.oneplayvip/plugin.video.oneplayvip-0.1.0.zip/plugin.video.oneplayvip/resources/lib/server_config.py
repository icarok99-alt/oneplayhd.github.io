# -*- coding: utf-8 -*-
import base64

DNS_LIST_B64 = [
    "aHR0cDovL3NtZzIudmlw",
    "aHR0cDovL29uZTIwMjYudmlw",
    "aHR0cDovL3J0ZXh0LnZpcA==",
    "aHR0cDovL29uZXBsYXlmYXN0cHJvLnh5eg==",
    "aHR0cDovL2Zpc3RmYXN0LnZpcA==",
    "aHR0cDovL2h4MnAueHl6",
    "aHR0cDovL3RvcDJnby5zYnM=",
]


def _emit(log_fn, message):
    if not log_fn:
        return
    try:
        log_fn(message)
    except Exception:
        pass


def b64_decode(text, log_fn=None):
    try:
        return base64.b64decode(text).decode('utf-8')
    except Exception as exc:
        _emit(log_fn, f'Falha ao decodificar DNS em base64: {exc}')
        return ''


def get_server_labels(dns_list=None):
    dns_list = dns_list or DNS_LIST_B64
    return [f'SERVIDOR {i + 1}' for i in range(len(dns_list))]


def get_current_server_choice(addon, dns_list=None):
    dns_list = dns_list or DNS_LIST_B64
    try:
        idx = int(addon.getSetting('server_choice') or '0')
    except Exception:
        idx = 0
    if idx < 0 or idx >= len(dns_list):
        idx = 0
    return idx


def get_base_url(addon, dns_list=None, log_fn=None):
    dns_list = dns_list or DNS_LIST_B64
    idx = get_current_server_choice(addon, dns_list=dns_list)
    if not dns_list:
        return ''
    return b64_decode(dns_list[idx], log_fn=log_fn)


def get_server_name(addon, idx=None, dns_list=None):
    dns_list = dns_list or DNS_LIST_B64
    labels = get_server_labels(dns_list=dns_list)
    idx = get_current_server_choice(addon, dns_list=dns_list) if idx is None else int(idx)
    if 0 <= idx < len(labels):
        return labels[idx]
    return f'SERVIDOR {idx + 1}'


def get_server_summary(addon, idx=None, dns_list=None):
    return get_server_name(addon, idx=idx, dns_list=dns_list)


def set_server_choice(addon, choice_idx, dns_list=None, refresh_fn=None, log_fn=None):
    dns_list = dns_list or DNS_LIST_B64
    try:
        choice_idx = int(choice_idx)
        if choice_idx < 0 or choice_idx >= len(dns_list):
            return False
        addon.setSetting('server_choice', str(choice_idx))
        if refresh_fn:
            refresh_fn()
        return True
    except Exception as exc:
        _emit(log_fn, f'Falha ao salvar servidor selecionado: {exc}')
        return False
