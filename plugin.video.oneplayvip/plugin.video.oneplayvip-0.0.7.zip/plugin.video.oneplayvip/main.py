# -*- coding: utf-8 -*-
import sys
import os
import time
import json
import html
import calendar
import urllib.parse
import xml.etree.ElementTree as ET
import ntpath
from urllib.request import build_opener, install_opener, urlretrieve
import re
from datetime import datetime
import base64
import hashlib
import unicodedata
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests

# =========================
# Configurações do Addon
# =========================
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_HANDLE = int(sys.argv[1])

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
HEADERS = {'User-Agent': USER_AGENT}

HOME = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
addonIcon = xbmcvfs.translatePath(os.path.join(HOME, 'icon.png'))
addonFanart = xbmcvfs.translatePath(os.path.join(HOME, 'fanart.jpg'))
if not xbmcvfs.exists(addonFanart):
    addonFanart = xbmcvfs.translatePath(os.path.join(HOME, 'fanart.png'))
QR_IMAGE_PATH = xbmcvfs.translatePath(os.path.join(HOME, 'resources', 'media', 'qr_whatsapp_paulo.png'))
SUPPORT_WHATSAPP = '(31) 99594-9574'
SUPPORT_CONTACT_LABEL = 'Suporte / WhatsApp'
APK_DOWNLOAD_FOLDER_ANDROID = '/storage/emulated/0/Download'
APK_ENTRIES_B64 = [('OnePlay Alpha - PRINCIPAL', 'aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlBbHBoYS5hcGs='),]

USERNAME = ''
PASSWORD = ''
ENABLE_EPG = 'false'
ENABLE_ADULT = 'false'
ADULT_PIN = ''
DEFAULT_ADULT_PIN = '0000'
ADULT_SESSION_PROPERTY = f'{ADDON_ID}.adult_unlocked'
SILENT_ACTION_MODES = {'download_apk', 'install_help'}

def refresh_runtime_settings():
    global USERNAME, PASSWORD, ENABLE_EPG, ENABLE_ADULT, ADULT_PIN
    try:
        USERNAME = (ADDON.getSetting('username') or '').strip()
        PASSWORD = (ADDON.getSetting('password') or '').strip()
        ENABLE_EPG = (ADDON.getSetting('enable_epg') or 'false').lower()
        ENABLE_ADULT = (ADDON.getSetting('enable_adult') or 'false').lower()
        configured_pin = (ADDON.getSetting('adult_pin') or '').strip()
        ADULT_PIN = configured_pin or DEFAULT_ADULT_PIN
        if configured_pin != ADULT_PIN:
            try:
                ADDON.setSetting('adult_pin', ADULT_PIN)
            except Exception:
                pass
        if ENABLE_ADULT != 'true':
            try:
                xbmcgui.Window(10000).clearProperty(ADULT_SESSION_PROPERTY)
            except Exception:
                pass
    except Exception as e:
        log(f"Falha ao reler configurações: {e}", xbmc.LOGERROR)
        USERNAME = ''
        PASSWORD = ''
        ENABLE_EPG = 'false'
        ENABLE_ADULT = 'false'
        ADULT_PIN = DEFAULT_ADULT_PIN


def has_addon(addon_id):
    try:
        return xbmc.getCondVisibility(f'System.HasAddon({addon_id})')
    except Exception:
        return False


def strip_kodi_url_headers(url):
    try:
        return (url or '').split('|', 1)[0]
    except Exception:
        return url or ''


def detect_stream_manifest_type(url):
    clean_url = strip_kodi_url_headers(url).lower()
    if '.m3u8' in clean_url or 'output=m3u8' in clean_url or 'type=m3u8' in clean_url:
        return 'hls'
    if '.mpd' in clean_url:
        return 'mpd'
    return ''


def detect_stream_extension(url):
    clean_url = strip_kodi_url_headers(url).lower()
    if not clean_url:
        return ''
    base = clean_url.split('?', 1)[0].split('#', 1)[0]
    _, ext = os.path.splitext(base)
    return ext.lstrip('.')


def detect_stream_mime_type(url, stream_kind=''):
    manifest_type = detect_stream_manifest_type(url)
    if manifest_type == 'hls':
        return 'application/vnd.apple.mpegurl'
    if manifest_type == 'mpd':
        return 'application/dash+xml'

    ext = detect_stream_extension(url)
    if ext == 'ts':
        return 'video/mp2t'
    if ext == 'mp4':
        return 'video/mp4'
    if ext == 'mkv':
        return 'video/x-matroska'
    if ext == 'avi':
        return 'video/x-msvideo'
    if ext == 'mov':
        return 'video/quicktime'
    if ext == 'wmv':
        return 'video/x-ms-wmv'
    if ext == 'flv':
        return 'video/x-flv'
    if ext == 'webm':
        return 'video/webm'
    if ext == 'm4v':
        return 'video/x-m4v'
    if ext in ('mpg', 'mpeg'):
        return 'video/mpeg'

    if stream_kind == 'live':
        return 'video/mp2t'
    return ''


def configure_live_stream_listitem(li, url):
    manifest_type = detect_stream_manifest_type(url)
    mime_type = detect_stream_mime_type(url, 'live')

    try:
        li.setContentLookup(False)
    except Exception:
        pass

    if mime_type:
        try:
            li.setMimeType(mime_type)
        except Exception:
            pass

    # Melhor caminho para live quando disponível: ffmpegdirect.
    # Se não existir, o Kodi cai no player nativo com mime correto.
    try:
        if has_addon('inputstream.ffmpegdirect'):
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            if manifest_type:
                li.setProperty('inputstream.ffmpegdirect.manifest_type', manifest_type)
    except Exception as e:
        log(f"Falha ao configurar inputstream live: {e}", xbmc.LOGDEBUG)


def configure_vod_stream_listitem(li, url, stream_kind='vod'):
    manifest_type = detect_stream_manifest_type(url)
    mime_type = detect_stream_mime_type(url, stream_kind)
    ext = detect_stream_extension(url)

    try:
        li.setContentLookup(False)
    except Exception:
        pass

    if mime_type:
        try:
            li.setMimeType(mime_type)
        except Exception:
            pass

    # Arquivos diretos (mp4/mkv/avi...) ficam no player nativo.
    # HLS/DASH/TS ganham inputstream quando disponível.
    try:
        if (manifest_type or ext == 'ts') and has_addon('inputstream.ffmpegdirect'):
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
            if manifest_type:
                li.setProperty('inputstream.ffmpegdirect.manifest_type', manifest_type)
    except Exception as e:
        log(f"Falha ao configurar inputstream VOD: {e}", xbmc.LOGDEBUG)


DNS_LIST_B64 = [
    "aHR0cDovL2JlYW50ZWMuY2E=",
    "aHR0cDovL3J0ZXh0LnZpcA==",
    "aHR0cDovL29uZXBsYXlmYXN0cHJvLnh5eg==",
    "aHR0cDovL2h4MnAueHl6",
    "aHR0cDovL3RvcDJnby5zYnM="
]

def b64_decode(text):
    try:
        return base64.b64decode(text).decode('utf-8')
    except Exception as e:
        log(f"Falha ao decodificar DNS em base64: {e}", xbmc.LOGERROR)
        return ''

def get_base_url():
    try:
        idx = int(ADDON.getSetting("server_choice") or "0")
    except Exception:
        idx = 0

    if not DNS_LIST_B64:
        return ''

    if idx < 0 or idx >= len(DNS_LIST_B64):
        idx = 0

    return b64_decode(DNS_LIST_B64[idx])

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
LEGACY_EPG_XML_PATH = os.path.join(PROFILE_DIR, 'epg.xml')
LEGACY_EPG_META_PATH = os.path.join(PROFILE_DIR, 'epg_meta.json')
EPG_TTL = 24 * 3600

_EPG_PARSED = None
_EPG_PARSED_SCOPE = None

DESC_TTL = 7 * 24 * 3600
LEGACY_VOD_DESC_CACHE_PATH = os.path.join(PROFILE_DIR, 'vod_desc_cache.json')
LEGACY_SERIES_DESC_CACHE_PATH = os.path.join(PROFILE_DIR, 'series_desc_cache.json')
LEGACY_SEARCH_STATE_PATH = os.path.join(PROFILE_DIR, 'search_state.json')
LEGACY_FAVORITES_PATH = os.path.join(PROFILE_DIR, 'favorites.json')
LEGACY_RESUME_POINTS_PATH = os.path.join(PROFILE_DIR, 'resume_points.json')
SCOPED_STORAGE_ROOT = os.path.join(PROFILE_DIR, 'profiles')
VALIDATED_SCOPE_STATE_PATH = os.path.join(PROFILE_DIR, '.validated_scope_state.json')
VOD_DESC_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.vod_desc_scoped_migrated')
SERIES_DESC_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.series_desc_scoped_migrated')
SEARCH_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.search_scoped_migrated')
FAVORITES_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.favorites_scoped_migrated')
RESUME_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.resume_scoped_migrated')
EPG_XML_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.epg_xml_scoped_migrated')
EPG_META_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.epg_meta_scoped_migrated')
MAX_RESUME_POINTS = 300
ADULT_MARKERS = ('18+', '+18', 'xxx', 'porn', 'porno', 'sex', 'adulttime', 'adulto', 'onlyfans', 'privacy', 'novinha', 'novinho', 'interracialsexx', 'mypervyfamily', 'brazzersexxtra', 'blacked raw', 'brad montana', 'mia khalifa', 'brasileirinhas')
_TAG_RE = re.compile(r'<[^>]+>')

# =========================
# Utilitários
# =========================
def clear_desc_caches():
    try:
        vod_path = vod_desc_cache_storage_path()
        series_path = series_desc_cache_storage_path()
        if os.path.exists(vod_path):
            os.remove(vod_path)
        if os.path.exists(series_path):
            os.remove(series_path)
        log("Caches de sinopse limpos por mudança de servidor.")
    except Exception as e:
        log(f"Falha ao limpar cache de sinopse: {e}", xbmc.LOGERROR)

def show_expire_popup(days_left, exp_date=None):
    if is_silent_action_mode():
        return

    if days_left is None:
        return

    try:
        warn_days = int(ADDON.getSetting('expire_warning_days')) + 1
    except Exception:
        warn_days = 3

    dialog = xbmcgui.Dialog()

    def center_text(text):
        # Adiciona linhas no topo e no final para simular centralização
        return "\n\n\n" + text + "\n\n\n"

    if days_left < 0:
        # Conta vencida
        message = center_text(
            "[COLOR red][B]SUA CONTA ESTÁ VENCIDA[/B][/COLOR]\n"
            "[COLOR white][B]Renove agora para continuar usando o serviço.[/B][/COLOR]"
        )
        dialog.ok("[COLOR white][B]CONTA VENCIDA[/B][/COLOR]", message)
        return

    if days_left <= warn_days:
        # Aviso de vencimento
        due_line = f"[COLOR white]Sua conta vence em: [B][COLOR yellow]{days_left} dia(s)[/COLOR][/B][/COLOR]"
        try:
            if days_left == 0 and exp_date:
                due_line = (
                    f"[COLOR white]Sua conta vence [B][COLOR yellow]hoje às {time.strftime('%H:%M', time.localtime(int(exp_date)))}[/COLOR][/B][/COLOR]"
                )
        except Exception:
            pass
        message = center_text(
            due_line + "\n"
            "[COLOR white]Evite bloqueio renovando com antecedência.[/COLOR]"
        )
        dialog.ok("[COLOR white][B]AVISO DE VENCIMENTO[/B][/COLOR]", message)

def color(text, color_name):
    return f"[COLOR {color_name}]{text}[/COLOR]"

def format_date(text):
    return color(text, 'lightblue')

def get_status_color(status):
    status = (status or '').lower()
    if status in ['active', 'ativo']:
        return 'lime'
    if status in ['expired', 'expirado', 'disabled']:
        return 'red'
    return 'orange'

def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

refresh_runtime_settings()

def is_silent_action_mode():
    try:
        return mode in SILENT_ACTION_MODES
    except Exception:
        return False


def should_suppress_account_dialog(title=''):
    if not is_silent_action_mode():
        return False
    normalized = (title or '').strip().lower()
    blocked_titles = {
        'configuração necessária',
        'erro de acesso',
        'acesso bloqueado',
        'conta vencida',
        'erro de comunicação',
        'erro de conexão'
    }
    return normalized in blocked_titles


def settle_after_settings_action(delay_ms=350):
    if is_silent_action_mode():
        try:
            xbmc.sleep(int(delay_ms))
        except Exception:
            pass


def show_dialog(title, message):
    if should_suppress_account_dialog(title):
        log(f"Diálogo suprimido no modo {mode}: {title} - {message}", xbmc.LOGDEBUG)
        return False
    return xbmcgui.Dialog().ok(title, message)


def get_platform_name():
    try:
        if xbmc.getCondVisibility('system.platform.android'):
            return 'android'
        if xbmc.getCondVisibility('system.platform.windows'):
            return 'windows'
        if xbmc.getCondVisibility('system.platform.osx'):
            return 'osx'
        if xbmc.getCondVisibility('system.platform.ios') or xbmc.getCondVisibility('system.platform.darwin'):
            return 'ios'
        if xbmc.getCondVisibility('system.platform.linux') or xbmc.getCondVisibility('system.platform.linux.Raspberrypi'):
            return 'linux'
    except Exception:
        pass
    return 'unknown'


def decode_b64_url(data):
    try:
        missing_padding = len(data or '') % 4
        if missing_padding:
            data += '=' * (4 - missing_padding)
        return base64.b64decode((data or '').encode('utf-8')).decode('utf-8')
    except Exception as e:
        log(f'Falha ao decodificar URL de APK: {e}', xbmc.LOGERROR)
        return ''


def get_apk_entries():
    items = []
    for name, b64_url in APK_ENTRIES_B64:
        url = decode_b64_url(b64_url)
        if url:
            items.append((name, url))
    return items


def notify(message, heading=None, iconimage=None, time_ms=3500, sound=False):
    heading = heading or ADDON.getAddonInfo('name')
    if iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    elif iconimage is None:
        iconimage = addonIcon
    xbmcgui.Dialog().notification(heading, message, iconimage, time_ms, sound=sound)


def normalize_bool(value):
    return str(value or '').strip().lower() in ('1', 'true', 'yes', 'on')


def refresh_container():
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


def end_directory(cache_to_disc=True):
    try:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=cache_to_disc)
    except TypeError:
        end_directory(cache_to_disc=True)


def show_install_apk_help(download_path=''):
    settle_after_settings_action(250)
    filename = ntpath.basename(download_path) if download_path else 'OnePlayAlpha.apk'
    lines = [
        '1. Feche o Kodi.',
        '2. Abra o gerenciador de arquivos do Android.',
        f'3. Vá até a pasta: [COLOR lime]Download / {filename}[/COLOR].',
        '4. Se o Android bloquear, libere [COLOR yellow]Instalar apps desconhecidos[/COLOR].',
        '5. Faça a instalação e abra o aplicativo.'
    ]
    xbmcgui.Dialog().ok('Como instalar o APK', '\n'.join(lines))


def select_apk_url():
    items = get_apk_entries()
    if not items:
        show_dialog('Download de APK', 'Nenhum APK disponível no momento.')
        return ''

    if len(items) == 1:
        return items[0][1]

    names = [name for name, _url in items]
    urls = [_url for _name, _url in items]
    selected = xbmcgui.Dialog().select('Selecione o APK para baixar', names)
    if selected < 0:
        return ''
    return urls[selected]


def download_progress_hook(numblocks, blocksize, filesize, dp):
    try:
        downloaded = numblocks * blocksize
        percent = int(min((downloaded * 100) / filesize, 100)) if filesize > 0 else 0
        elapsed = max(time.time() - download_progress_hook.start_time, 0.001)
        speed_kbps = (downloaded / elapsed) / 1024.0
        eta_seconds = ((filesize - downloaded) / (downloaded / elapsed)) if filesize > 0 and downloaded > 0 else 0
        downloaded_mb = float(downloaded) / (1024 * 1024)
        total_mb = float(filesize) / (1024 * 1024) if filesize > 0 else 0
        mins, secs = divmod(max(int(eta_seconds), 0), 60)
        message = (
            f'{downloaded_mb:.2f} MB de {total_mb:.2f} MB\n'
            f'[COLOR yellow]Velocidade:[/COLOR] {speed_kbps:.02f} KB/s  '
            f'[COLOR yellow]Tempo restante:[/COLOR] {mins:02d}:{secs:02d}'
        )
        dp.update(percent, message)
    except Exception:
        try:
            dp.update(0, 'Baixando arquivo...')
        except Exception:
            pass

    if dp.iscanceled():
        dp.close()
        raise Exception('Download cancelado pelo usuário.')


def perform_apk_download(url, destination_path):
    filename = ntpath.basename(url.split('?', 1)[0]) or 'OnePlayAlpha.apk'
    dp = xbmcgui.DialogProgress()
    dp.create(f'Baixando {filename}...', 'Por favor, aguarde...')
    try:
        opener = build_opener()
        opener.addheaders = [('User-Agent', USER_AGENT)]
        install_opener(opener)
        download_progress_hook.start_time = time.time()
        urlretrieve(url, destination_path, lambda nb, bs, fs: download_progress_hook(nb, bs, fs, dp))
        dp.update(100, 'Finalizando download...')
        return True
    except Exception as e:
        try:
            if xbmcvfs.exists(destination_path):
                xbmcvfs.delete(destination_path)
        except Exception:
            pass
        log(f'Falha no download do APK: {e}', xbmc.LOGERROR)
        notify('Erro ao baixar o APK', iconimage='ERROR')
        return False
    finally:
        try:
            dp.close()
        except Exception:
            pass


def handle_apk_download():
    settle_after_settings_action(400)

    if get_platform_name() != 'android':
        show_dialog('Download de APK', 'Esse recurso foi feito para Android.\nAbra este addon em um dispositivo android TV para baixar o APK direto.\n\n[B]Att: Paulo_OnePlay[/B]')
        return

    url = select_apk_url()
    if not url:
        return

    filename = ntpath.basename(url.split('?', 1)[0]) or 'OnePlayAlpha.apk'
    if not xbmcvfs.exists(APK_DOWNLOAD_FOLDER_ANDROID):
        xbmcvfs.mkdirs(APK_DOWNLOAD_FOLDER_ANDROID)

    destination_path = os.path.join(APK_DOWNLOAD_FOLDER_ANDROID, filename)

    try:
        if xbmcvfs.exists(destination_path):
            xbmcvfs.delete(destination_path)
    except Exception:
        pass

    if perform_apk_download(url, destination_path):
        try:
            xbmc.sleep(250)
        except Exception:
            pass

        xbmcgui.Dialog().ok(
            'Download concluído',
            '[COLOR yellow]APK baixado com sucesso.[/COLOR]\n'
            f'Arquivo salvo em:\n[COLOR lime]{destination_path}[/COLOR]\n\n'
            '[COLOR white]Toque em OK para ver as instruções de instalação.[/COLOR]'
        )

        try:
            xbmc.sleep(300)
        except Exception:
            pass
        show_install_apk_help(destination_path)

class QRCodeDialog(xbmcgui.WindowXMLDialog):
    CONTROL_IMAGE = 1001
    CONTROL_OK = 1002
    ACTION_PREVIOUS_MENU = 10
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def __init__(self, *args, **kwargs):
        self.image_path = kwargs.pop('image_path', '')
        super().__init__(*args, **kwargs)

    def onInit(self):
        try:
            image_control = self.getControl(self.CONTROL_IMAGE)
            try:
                image_control.setImage(self.image_path, useCache=False)
            except TypeError:
                image_control.setImage(self.image_path)
        except Exception as e:
            log(f"Falha ao carregar imagem do QR no diálogo: {e}", xbmc.LOGERROR)

        try:
            self.setFocusId(self.CONTROL_OK)
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == self.CONTROL_OK:
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = int(action)

        if action_id in (self.ACTION_PREVIOUS_MENU, self.ACTION_NAV_BACK, self.ACTION_BACKSPACE):
            self.close()
        else:
            super().onAction(action)


def show_qr_code():
    message = (
        "[B]Escaneie o QR Code para falar com o suporte[/B]\n\n"
        "[COLOR white]Se o QR não abrir, use o WhatsApp:[/COLOR]\n"
        f"[COLOR gold]{SUPPORT_WHATSAPP}[/COLOR]"
    )

    if xbmcvfs.exists(QR_IMAGE_PATH):
        try:
            dialog = QRCodeDialog('QRCodeDialog.xml', ADDON.getAddonInfo('path'), 'Default', '1080i', image_path=QR_IMAGE_PATH)
            dialog.doModal()
            del dialog
            return
        except Exception as e:
            log(f"Falha ao abrir QR Code em janela customizada: {e}", xbmc.LOGERROR)

    xbmcgui.Dialog().ok("QR Code", message)


def is_adult_name(text):
    lowered = (text or '').strip().lower()
    return bool(lowered and any(marker in lowered for marker in ADULT_MARKERS))


def is_adult_enabled():
    return ENABLE_ADULT.lower() == 'true'


def clear_adult_session():
    try:
        xbmcgui.Window(10000).clearProperty(ADULT_SESSION_PROPERTY)
    except Exception:
        pass


def is_adult_session_unlocked():
    try:
        return xbmcgui.Window(10000).getProperty(ADULT_SESSION_PROPERTY) == 'true'
    except Exception:
        return False


def prompt_current_adult_pin(title='Conteúdo Adulto'):
    entered = xbmcgui.Dialog().input(title, type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if entered is None:
        return False
    return (entered or '').strip() == (ADULT_PIN or DEFAULT_ADULT_PIN).strip()


def ensure_adult_access(label='Conteúdo Adulto'):
    if not is_adult_enabled():
        show_dialog('Conteúdo Adulto', 'O conteúdo adulto está desativado nas configurações do addon.')
        return False
    if prompt_current_adult_pin(f'PIN Adulto - {label}'):
        return True
    show_dialog('Conteúdo Adulto', 'PIN inválido.')
    return False

def build_url(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)

def ensure_profile_dir():
    try:
        os.makedirs(PROFILE_DIR, exist_ok=True)
    except Exception:
        try:
            if not xbmcvfs.exists(PROFILE_DIR):
                xbmcvfs.mkdirs(PROFILE_DIR)
        except Exception:
            pass


def ensure_parent_dir(path):
    try:
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
    except Exception:
        try:
            parent = os.path.dirname(path)
            if parent and not xbmcvfs.exists(parent):
                xbmcvfs.mkdirs(parent)
        except Exception:
            pass


def storage_identity_from_values(base_url='', username=''):
    base_url = (base_url or '').strip().rstrip('/').lower()
    username = (username or '').strip().lower()
    return f'{base_url}|{username}' if (base_url or username) else 'default'


def current_storage_identity():
    return storage_identity_from_values(get_base_url(), USERNAME)


def scope_name_from_identity(identity, base_url='', username=''):
    identity = (identity or '').strip() or 'default'
    if identity == 'default':
        return 'default'
    if not (base_url or username):
        try:
            base_url, username = identity.split('|', 1)
        except Exception:
            base_url, username = '', ''
    try:
        parsed = urllib.parse.urlparse((base_url or '').strip())
        host = parsed.netloc or parsed.path or 'server'
    except Exception:
        host = (base_url or '').strip() or 'server'
    safe_host = re.sub(r'[^A-Za-z0-9._-]+', '_', (host or 'server')).strip('._-') or 'server'
    safe_user = re.sub(r'[^A-Za-z0-9._-]+', '_', (username or 'user')).strip('._-') or 'user'
    digest = hashlib.sha1(identity.encode('utf-8')).hexdigest()[:10]
    return f'{safe_host}__{safe_user}__{digest}'


def read_validated_scope_state():
    try:
        if not xbmcvfs.exists(VALIDATED_SCOPE_STATE_PATH):
            return {}
        with open(VALIDATED_SCOPE_STATE_PATH, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def remember_validated_scope_state(base_url='', username=''):
    try:
        identity = storage_identity_from_values(base_url, username)
        if identity == 'default':
            return False
        payload = {
            'identity': identity,
            'scope_name': scope_name_from_identity(identity, base_url, username),
            'updated_at': int(time.time())
        }
        ensure_profile_dir()
        with open(VALIDATED_SCOPE_STATE_PATH, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, ensure_ascii=False)
        return True
    except Exception as exc:
        log(f'Falha ao salvar estado do escopo validado: {exc}', xbmc.LOGDEBUG)
        return False


def current_storage_scope_name():
    current_identity = current_storage_identity()
    validated_state = read_validated_scope_state()
    validated_identity = (validated_state.get('identity') or '').strip()
    validated_scope = (validated_state.get('scope_name') or '').strip()

    if current_identity != 'default' and current_identity == validated_identity:
        return scope_name_from_identity(current_identity, get_base_url(), USERNAME)

    if validated_identity and validated_scope:
        return validated_scope

    return 'default'


def get_scoped_storage_path(filename):
    return os.path.join(SCOPED_STORAGE_ROOT, current_storage_scope_name(), filename)


def ensure_marker_file(marker_path):
    try:
        ensure_parent_dir(marker_path)
        if not xbmcvfs.exists(marker_path):
            with open(marker_path, 'w', encoding='utf-8') as fh:
                fh.write(current_storage_identity())
    except Exception as exc:
        log(f'Falha ao criar marcador {marker_path}: {exc}', xbmc.LOGDEBUG)


def maybe_migrate_legacy_json(scoped_path, legacy_path, marker_path, default_payload):
    try:
        ensure_profile_dir()
        ensure_parent_dir(scoped_path)
        if xbmcvfs.exists(scoped_path):
            return scoped_path
        if xbmcvfs.exists(marker_path):
            return scoped_path
        if not xbmcvfs.exists(legacy_path):
            return scoped_path
        data = load_json_file(legacy_path, default_payload)
        if data is None:
            data = default_payload
        if save_json_file(scoped_path, data):
            ensure_marker_file(marker_path)
            try:
                backup_path = legacy_path + '.legacy.bak'
                if not xbmcvfs.exists(backup_path):
                    xbmcvfs.copy(legacy_path, backup_path)
            except Exception:
                pass
            log(f'Dados migrados para armazenamento individual: {scoped_path}')
    except Exception as exc:
        log(f'Falha ao migrar JSON legado {legacy_path}: {exc}', xbmc.LOGDEBUG)
    return scoped_path


def favorites_storage_path():
    return maybe_migrate_legacy_json(get_scoped_storage_path('favorites.json'), LEGACY_FAVORITES_PATH, FAVORITES_MIGRATION_MARKER, {'items': []})


def resume_points_storage_path():
    return maybe_migrate_legacy_json(get_scoped_storage_path('resume_points.json'), LEGACY_RESUME_POINTS_PATH, RESUME_MIGRATION_MARKER, {})


def maybe_migrate_legacy_file(scoped_path, legacy_path, marker_path):
    try:
        ensure_profile_dir()
        ensure_parent_dir(scoped_path)
        if xbmcvfs.exists(scoped_path):
            return scoped_path
        if xbmcvfs.exists(marker_path):
            return scoped_path
        if not xbmcvfs.exists(legacy_path):
            return scoped_path
        if xbmcvfs.copy(legacy_path, scoped_path):
            ensure_marker_file(marker_path)
            try:
                backup_path = legacy_path + '.legacy.bak'
                if not xbmcvfs.exists(backup_path):
                    xbmcvfs.copy(legacy_path, backup_path)
            except Exception:
                pass
            log(f'Arquivo legado migrado para armazenamento individual: {scoped_path}')
    except Exception as exc:
        log(f'Falha ao migrar arquivo legado {legacy_path}: {exc}', xbmc.LOGDEBUG)
    return scoped_path


def vod_desc_cache_storage_path():
    return maybe_migrate_legacy_json(get_scoped_storage_path('vod_desc_cache.json'), LEGACY_VOD_DESC_CACHE_PATH, VOD_DESC_MIGRATION_MARKER, {})


def series_desc_cache_storage_path():
    return maybe_migrate_legacy_json(get_scoped_storage_path('series_desc_cache.json'), LEGACY_SERIES_DESC_CACHE_PATH, SERIES_DESC_MIGRATION_MARKER, {})


def search_state_storage_path():
    return maybe_migrate_legacy_json(get_scoped_storage_path('search_state.json'), LEGACY_SEARCH_STATE_PATH, SEARCH_MIGRATION_MARKER, {})


def epg_xml_storage_path():
    return maybe_migrate_legacy_file(get_scoped_storage_path('epg.xml'), LEGACY_EPG_XML_PATH, EPG_XML_MIGRATION_MARKER)


def epg_meta_storage_path():
    return maybe_migrate_legacy_json(get_scoped_storage_path('epg_meta.json'), LEGACY_EPG_META_PATH, EPG_META_MIGRATION_MARKER, {})


def load_json_file(path, default=None):
    try:
        ensure_profile_dir()
        ensure_parent_dir(path)
        if not xbmcvfs.exists(path):
            return default
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception as exc:
        log(f'Falha ao ler JSON {path}: {exc}', xbmc.LOGDEBUG)
        return default


def save_json_file(path, data):
    try:
        ensure_profile_dir()
        ensure_parent_dir(path)
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        return True
    except Exception as exc:
        log(f'Falha ao salvar JSON {path}: {exc}', xbmc.LOGDEBUG)
        return False


def normalize_sort_text(text):
    try:
        text = str(text or '').strip().lower()
        text = unicodedata.normalize('NFKD', text)
        return ''.join(ch for ch in text if not unicodedata.combining(ch))
    except Exception:
        return str(text or '').strip().lower()


def favorite_prefix(kind):
    kind = (kind or '').strip().lower()
    if kind == 'live':
        return 'Canal:'
    if kind == 'vod':
        return 'Filme:'
    if kind == 'series':
        return 'Séries:'
    return ''


def favorite_base_title(kind, title):
    title = (title or 'Favorito').strip() or 'Favorito'
    known_prefixes = ['Canal:', 'Filme:', 'Série:', 'Séries:']
    for pref in known_prefixes:
        if title.startswith(pref):
            stripped = title[len(pref):].strip()
            if stripped:
                title = stripped
            break
    return title


def favorite_display_title(kind, title):
    title = favorite_base_title(kind, title)
    prefix = favorite_prefix(kind)
    return f'{prefix} {title}'.strip() if prefix else title


def is_vod_resume_enabled():
    try:
        return (ADDON.getSetting('enable_vod_resume') or 'true').lower() == 'true'
    except Exception:
        return True


def load_resume_points():
    data = load_json_file(resume_points_storage_path(), {})
    return data if isinstance(data, dict) else {}


def trim_resume_points(data):
    if not isinstance(data, dict):
        return {}
    if len(data) <= MAX_RESUME_POINTS:
        return data
    def _resume_sort_key(item):
        entry = item[1] if isinstance(item[1], dict) else {}
        try:
            updated_at = int(entry.get('updated_at') or 0)
        except Exception:
            updated_at = 0
        return updated_at
    trimmed = sorted(data.items(), key=_resume_sort_key, reverse=True)[:MAX_RESUME_POINTS]
    return {key: value for key, value in trimmed}


def save_resume_points(data):
    save_json_file(resume_points_storage_path(), trim_resume_points(data or {}))


def make_resume_key(stream_kind='', vod_id='', stream_id='', url=''):
    stream_kind = (stream_kind or '').strip().lower()
    vod_id = str(vod_id or '').strip()
    stream_id = str(stream_id or '').strip()
    clean_url = strip_kodi_url_headers(url).strip()
    if stream_kind == 'vod' and vod_id:
        return f'vod:{vod_id}'
    if stream_kind == 'episode':
        if stream_id:
            return f'episode:{stream_id}'
        if clean_url:
            return f'episode_url:{clean_url}'
    return ''


def get_resume_point(resume_key):
    if not resume_key:
        return None
    data = load_resume_points()
    entry = data.get(resume_key)
    return entry if isinstance(entry, dict) else None


def sanitize_resume_meta(meta):
    meta = meta if isinstance(meta, dict) else {}
    out = {}
    for key in ('url', 'icon', 'fanart', 'plot', 'normalplayer', 'stream_kind', 'container_extension', 'vod_id', 'series_id', 'stream_id', 'is_adult'):
        if key in meta and meta.get(key) not in (None, ''):
            out[key] = meta.get(key)
    if 'url' in out:
        out['url'] = str(out.get('url') or '').strip()
    if 'stream_kind' in out:
        out['stream_kind'] = str(out.get('stream_kind') or '').strip().lower()
    if 'normalplayer' in out:
        out['normalplayer'] = str(out.get('normalplayer') or 'false').lower()
    if 'is_adult' in out:
        out['is_adult'] = normalize_bool(out.get('is_adult', False))
    return out


def set_resume_point(resume_key, title, position, total, meta=None):
    if not resume_key:
        return
    try:
        position = float(position or 0)
        total = float(total or 0)
    except Exception:
        return
    if position <= 0 or total <= 0:
        return
    data = load_resume_points()
    existing = data.get(resume_key) if isinstance(data.get(resume_key), dict) else {}
    payload = dict(existing)
    payload.update({
        'title': title or existing.get('title', ''),
        'position': position,
        'total': total,
        'updated_at': int(time.time())
    })
    clean_meta = sanitize_resume_meta(meta)
    if clean_meta:
        payload.update(clean_meta)
    data[resume_key] = payload
    save_resume_points(data)


def resume_entry_is_active(entry):
    if not isinstance(entry, dict):
        return False
    try:
        position = float(entry.get('position') or 0)
        total = float(entry.get('total') or 0)
    except Exception:
        return False
    if position < 30:
        return False
    if total > 0 and position >= max(total - 120, total * 0.95):
        return False
    return True


def continue_resume_prefix(stream_kind):
    return 'Filme: ' if str(stream_kind or '').strip().lower() == 'vod' else 'Série: '


def list_continue_watching_items():
    data = load_resume_points()
    items = []
    legacy_count = 0
    for resume_key, entry in data.items():
        if not resume_entry_is_active(entry):
            continue
        stream_kind = str(entry.get('stream_kind') or '').strip().lower()
        if stream_kind not in ('vod', 'episode'):
            legacy_count += 1
            continue
        play_url = str(entry.get('url') or '').strip()
        if not play_url:
            legacy_count += 1
            continue
        title = str(entry.get('title') or 'Sem título').strip() or 'Sem título'
        title = favorite_base_title('series' if stream_kind == 'episode' else stream_kind, title)
        try:
            updated_at = int(entry.get('updated_at') or 0)
        except Exception:
            updated_at = 0
        try:
            position = float(entry.get('position') or 0)
            total = float(entry.get('total') or 0)
        except Exception:
            position = 0.0
            total = 0.0
        plot = str(entry.get('plot') or '').strip()
        progress_text = f'Continuar em: {format_resume_time(position)}'
        if total > 0:
            progress_text += f' de {format_resume_time(total)}'
        plot = f'{progress_text}\n\n{plot}' if plot else progress_text
        items.append({
            'resume_key': str(resume_key or ''),
            'title': continue_resume_prefix(stream_kind) + title,
            'play_title': title,
            'url': play_url,
            'icon': str(entry.get('icon') or addonIcon),
            'fanart': str(entry.get('fanart') or addonFanart),
            'plot': plot,
            'normalplayer': str(entry.get('normalplayer') or 'false').lower(),
            'stream_kind': stream_kind,
            'container_extension': str(entry.get('container_extension') or ''),
            'vod_id': str(entry.get('vod_id') or ''),
            'series_id': str(entry.get('series_id') or ''),
            'stream_id': str(entry.get('stream_id') or ''),
            'is_adult': normalize_bool(entry.get('is_adult', False)),
            'updated_at': updated_at,
            'position': position,
            'total': total
        })
    items.sort(key=lambda it: int(it.get('updated_at') or 0), reverse=True)
    return items, legacy_count


def focus_first_list_item():
    try:
        xbmc.sleep(60)
        xbmc.executebuiltin('SetFocus(50,0,absolute)')
    except Exception as e:
        log(f"Falha ao focar primeiro item da lista: {e}", xbmc.LOGDEBUG)


def return_to_root_menu_with_message(title, message=''):
    if message:
        show_dialog(title, message)
    try:
        xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='main'))
    except Exception as e:
        log(f"Falha ao retornar ao menu principal com replace: {e}", xbmc.LOGERROR)
        build_root_menu()
    raise SystemExit


def return_to_enter_menu_with_message(title, message=''):
    if message:
        show_dialog(title, message)
    try:
        xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
    except Exception as e:
        log(f"Falha ao retornar ao menu Enter com replace: {e}", xbmc.LOGERROR)
        build_menu(get_enter_menu_items())
    raise SystemExit


def build_continue_watching_menu():
    items, legacy_count = list_continue_watching_items()
    if not items:
        return_to_enter_menu_with_message('Continue Assistindo', 'Nenhum conteúdo em resume no momento.')
        return
    for item in items:
        label = item.get('title', '')
        play_title = item.get('play_title', label)
        li = xbmcgui.ListItem(label=label)
        icon = item.get('icon', addonIcon) or addonIcon
        fanart = item.get('fanart', addonFanart) or addonFanart
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        info = {'title': label}
        plot = item.get('plot', '') or ''
        if plot:
            info['plot'] = plot
        if item.get('stream_kind') == 'vod':
            info['mediatype'] = 'movie'
        elif item.get('stream_kind') == 'episode':
            info['mediatype'] = 'episode'
        li.setInfo('video', info)
        li.setProperty('IsPlayable', 'true')
        cm = []
        resume_key = item.get('resume_key', '')
        if resume_key:
            cm_url = build_url(mode='clear_resume_entry', resume_key=resume_key)
            cm.append(('Remover de Continue Assistindo', f'RunPlugin({cm_url})'))
        if cm:
            li.addContextMenuItems(cm, replaceItems=False)
        play = item.get('url', '')
        if 'User-Agent=' not in play:
            play = play + '|User-Agent=' + USER_AGENT
        params = {
            'mode': 'play',
            'url': play,
            'title': play_title,
            'icon': icon,
            'fanart': fanart,
            'normalplayer': str(item.get('normalplayer', 'false')).lower(),
            'stream_kind': item.get('stream_kind', ''),
            'container_extension': item.get('container_extension', ''),
            'stream_id': str(item.get('stream_id', '') or ''),
            'is_adult': str(normalize_bool(item.get('is_adult', False))).lower(),
            'resume_key': resume_key
        }
        if str(item.get('stream_kind', '') or '') in ('vod', 'episode'):
            params['play_nonce'] = str(int(time.time() * 1000))
        if item.get('vod_id'):
            params['vod_id'] = str(item.get('vod_id'))
        if item.get('series_id'):
            params['series_id'] = str(item.get('series_id'))
        url = build_url(**params)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)
    end_directory(cache_to_disc=True)


def clear_resume_point(resume_key):
    if not resume_key:
        return
    data = load_resume_points()
    if resume_key in data:
        del data[resume_key]
        save_resume_points(data)


def format_resume_time(seconds):
    try:
        seconds = int(float(seconds or 0))
    except Exception:
        seconds = 0
    if seconds <= 0:
        return '00:00'
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return f'{h:02d}:{m:02d}:{s:02d}'
    return f'{m:02d}:{s:02d}'


def prompt_resume_position(title, resume_entry, resume_key=''):
    if not isinstance(resume_entry, dict):
        return 0.0
    try:
        position = float(resume_entry.get('position') or 0)
        total = float(resume_entry.get('total') or 0)
    except Exception:
        return 0.0
    if position < 30:
        return 0.0
    if total > 0 and position >= max(total - 120, total * 0.95):
        return 0.0
    message = f'Deseja continuar de onde parou?\n\nParado em: {format_resume_time(position)}'
    if total > 0:
        message += f' de {format_resume_time(total)}'
    try:
        yes = xbmcgui.Dialog().yesno(title or 'Continuar assistindo', message, yeslabel='Continuar', nolabel='Do início')
    except Exception:
        yes = False
    if yes:
        return position
    clear_resume_point(resume_key)
    return 0.0


def monitor_and_persist_resume(player, resume_key, title='', meta=None):
    if not resume_key:
        return
    monitor = xbmc.Monitor()
    started = False
    last_pos = 0.0
    last_total = 0.0
    startup_deadline = time.time() + 20.0
    while not monitor.abortRequested() and time.time() < startup_deadline:
        try:
            if player.isPlayingVideo() or player.isPlaying():
                started = True
                break
        except Exception:
            pass
        if monitor.waitForAbort(0.25):
            return
    if not started:
        return
    while not monitor.abortRequested():
        try:
            if not (player.isPlayingVideo() or player.isPlaying()):
                break
            pos = float(player.getTime() or 0)
            total = float(player.getTotalTime() or 0)
            if pos > 0:
                last_pos = pos
            if total > 0:
                last_total = total
        except Exception:
            pass
        if monitor.waitForAbort(1.0):
            return
    if last_total > 0 and last_pos >= max(last_total - 120, last_total * 0.95):
        clear_resume_point(resume_key)
        return
    if last_pos >= 30 and (last_total <= 0 or last_pos < max(last_total - 30, last_total * 0.99)):
        set_resume_point(resume_key, title, last_pos, last_total, meta=meta)


def apply_resume_seek(player, resume_seconds):
    try:
        resume_seconds = float(resume_seconds or 0)
    except Exception:
        resume_seconds = 0.0
    if resume_seconds <= 0:
        return
    monitor = xbmc.Monitor()
    deadline = time.time() + 20.0
    while not monitor.abortRequested() and time.time() < deadline:
        try:
            if player.isPlayingVideo() or player.isPlaying():
                player.seekTime(resume_seconds)
                return
        except Exception:
            pass
        if monitor.waitForAbort(0.25):
            return


def favorites_load():
    data = load_json_file(favorites_storage_path(), {'items': []})
    if not isinstance(data, dict):
        data = {'items': []}
    items = data.get('items')
    data['items'] = items if isinstance(items, list) else []
    return data


def favorites_save(data):
    payload = {'items': []}
    if isinstance(data, dict):
        items = data.get('items')
        if isinstance(items, list):
            payload['items'] = items
    return save_json_file(favorites_storage_path(), payload)


def favorite_key(kind, item_id):
    kind = (kind or '').strip().lower()
    item_id = str(item_id or '').strip()
    if not kind or not item_id:
        return ''
    return f'{kind}:{item_id}'


def favorites_key_set():
    return {str(item.get('key', '')) for item in favorites_load().get('items', []) if str(item.get('key', '')).strip()}


def infer_favorite_kind(item):
    kind = (item.get('favorite_kind') or '').strip().lower()
    if kind in ('live', 'vod', 'series'):
        return kind
    if item.get('series_id'):
        return 'series'
    if item.get('stream_kind') == 'live':
        return 'live'
    if item.get('stream_kind') == 'vod' or item.get('vod_id') or item.get('stream_id'):
        return 'vod'
    return ''


def favorite_entry_from_item(item):
    kind = infer_favorite_kind(item)
    title = favorite_base_title(kind, html.unescape(item.get('favorite_title') or item.get('title') or '').strip())
    icon = item.get('icon', '') or ''
    fanart = item.get('fanart', addonFanart) or addonFanart
    plot = item.get('plot', '') or ''
    category_id = str(item.get('category_id', '') or '').strip()
    is_adult = normalize_bool(item.get('is_adult', False))

    if kind == 'live':
        stream_id = str(item.get('stream_id', '') or '').strip()
        if not stream_id:
            return None
        return {'key': favorite_key('live', stream_id), 'kind': 'live', 'title': title, 'stream_id': stream_id, 'epg_channel_id': str(item.get('epg_channel_id', '') or '').strip(), 'container_extension': 'm3u8', 'icon': icon, 'fanart': fanart, 'plot': plot, 'category_id': category_id, 'is_adult': is_adult, 'added_at': time.time()}

    if kind == 'vod':
        vod_id = str(item.get('vod_id') or item.get('stream_id') or '').strip()
        if not vod_id:
            return None
        ext = (item.get('container_extension') or 'mp4').lower()
        stream_type = (item.get('stream_type') or 'movie').strip() or 'movie'
        return {'key': favorite_key('vod', vod_id), 'kind': 'vod', 'title': title, 'vod_id': vod_id, 'stream_type': stream_type, 'container_extension': ext, 'icon': icon, 'fanart': fanart, 'plot': plot, 'category_id': category_id, 'is_adult': is_adult, 'added_at': time.time()}

    if kind == 'series':
        series_id = str(item.get('series_id', '') or '').strip()
        if not series_id:
            return None
        return {'key': favorite_key('series', series_id), 'kind': 'series', 'title': title, 'series_id': series_id, 'icon': icon, 'fanart': fanart, 'plot': plot, 'category_id': category_id, 'is_adult': is_adult, 'added_at': time.time()}

    return None


def favorite_entry_from_params(params):
    item = {'favorite_kind': params.get('fav_kind', ''), 'title': params.get('title', ''), 'favorite_title': params.get('favorite_title', ''), 'icon': params.get('icon', ''), 'fanart': params.get('fanart', addonFanart), 'plot': params.get('plot', ''), 'category_id': params.get('category_id', ''), 'is_adult': params.get('is_adult', 'false'), 'stream_id': params.get('stream_id', ''), 'vod_id': params.get('vod_id', ''), 'series_id': params.get('series_id', ''), 'container_extension': params.get('container_extension', ''), 'stream_type': params.get('stream_type', ''), 'stream_kind': params.get('stream_kind', ''), 'epg_channel_id': params.get('epg_channel_id', '')}
    return favorite_entry_from_item(item)


def add_favorite(entry):
    if not isinstance(entry, dict) or not entry.get('key'):
        return False
    data = favorites_load()
    items = [it for it in data.get('items', []) if str(it.get('key', '')) != entry['key']]
    items.insert(0, entry)
    data['items'] = items
    return favorites_save(data)


def remove_favorite(favorite_key_value):
    favorite_key_value = str(favorite_key_value or '').strip()
    if not favorite_key_value:
        return False
    data = favorites_load()
    items = data.get('items', [])
    new_items = [it for it in items if str(it.get('key', '')) != favorite_key_value]
    if len(new_items) == len(items):
        return False
    data['items'] = new_items
    return favorites_save(data)


def favorite_to_menu_item(fav):
    kind = (fav.get('kind') or '').strip().lower()
    title = fav.get('title', 'Favorito') or 'Favorito'
    icon = fav.get('icon', '') or addonIcon
    fanart = fav.get('fanart', addonFanart) or addonFanart
    plot = fav.get('plot', '') or ''
    category_id = str(fav.get('category_id', '') or '').strip()
    is_adult = normalize_bool(fav.get('is_adult', False))
    base_url = get_base_url().rstrip('/')

    if kind == 'live':
        stream_id = str(fav.get('stream_id', '') or '').strip()
        if not stream_id or not base_url or not USERNAME or not PASSWORD:
            return None
        return {'title': title, 'url': f'{base_url}/live/{USERNAME}/{PASSWORD}/{stream_id}.m3u8', 'icon': icon, 'fanart': fanart, 'plot': plot, 'media_type': 'video', 'normalplayer': 'false', 'stream_kind': 'live', 'stream_id': stream_id, 'epg_channel_id': str(fav.get('epg_channel_id', '') or '').strip(), 'container_extension': 'm3u8', 'category_id': category_id, 'is_adult': is_adult, 'favorite_kind': 'live', 'favorite_key': fav.get('key', '')}

    if kind == 'vod':
        vod_id = str(fav.get('vod_id', '') or '').strip()
        stream_type = (fav.get('stream_type') or 'movie').strip() or 'movie'
        ext = (fav.get('container_extension') or 'mp4').lower()
        if not vod_id or not base_url or not USERNAME or not PASSWORD:
            return None
        return {'title': title, 'url': f'{base_url}/{stream_type}/{USERNAME}/{PASSWORD}/{vod_id}.{ext}', 'icon': icon, 'fanart': fanart, 'plot': plot, 'media_type': 'movie', 'normalplayer': 'false', 'stream_kind': 'vod', 'stream_id': vod_id, 'vod_id': vod_id, 'container_extension': ext, 'stream_type': stream_type, 'category_id': category_id, 'is_adult': is_adult, 'favorite_kind': 'vod', 'favorite_key': fav.get('key', '')}

    if kind == 'series':
        series_id = str(fav.get('series_id', '') or '').strip()
        if not series_id:
            return None
        return {'title': title, 'mode': 'seasons', 'params': f"series_id={series_id}&category_id={urllib.parse.quote(category_id, safe='')}&is_adult={'true' if is_adult else 'false'}", 'icon': icon, 'fanart': fanart, 'plot': plot, 'media_type': 'tvshow', 'series_id': series_id, 'category_id': category_id, 'is_adult': is_adult, 'favorite_kind': 'series', 'favorite_key': fav.get('key', '')}

    return None


def list_favorites_items():
    items = []
    for fav in favorites_load().get('items', []):
        item = favorite_to_menu_item(fav)
        if not item:
            continue
        if item.get('is_adult') and not is_adult_enabled():
            continue
        item['display_title'] = favorite_display_title(item.get('favorite_kind') or infer_favorite_kind(item), item.get('title', 'Favorito'))
        items.append(item)
    items.sort(key=lambda it: normalize_sort_text(it.get('display_title') or it.get('title') or ''))
    return items


def build_favorites_menu():
    items = list_favorites_items()
    if not items:
        return_to_enter_menu_with_message('Favoritos', 'Nenhum favorito salvo no momento.')
        return

    favorite_keys = favorites_key_set()
    for item in items:
        label = item.get('display_title') or item.get('title', '')
        play_title = item.get('title', label)
        li = xbmcgui.ListItem(label=label)
        icon = item.get('icon', addonIcon) or addonIcon
        fanart = item.get('fanart', addonFanart) or addonFanart
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        plot = item.get('plot', '') or ''
        info = {'title': label}
        if plot:
            info['plot'] = plot
        li.setInfo('video', info)
        favorite_key_value = item.get('favorite_key', '')
        cm = []
        if favorite_key_value and favorite_key_value in favorite_keys:
            cm_url = build_url(mode='remove_favorite', favorite_key=favorite_key_value, from_favorites='true')
            cm.append(('Remover dos Favoritos do Addon', f'RunPlugin({cm_url})'))
        if cm:
            li.addContextMenuItems(cm, replaceItems=False)

        if item.get('url'):
            play = item['url']
            if 'User-Agent=' not in play:
                play = play + '|User-Agent=' + USER_AGENT
            params = {'mode': 'play', 'url': play, 'title': play_title, 'icon': icon, 'fanart': fanart, 'normalplayer': str(item.get('normalplayer', 'false')).lower(), 'stream_kind': item.get('stream_kind', ''), 'container_extension': item.get('container_extension', ''), 'category_id': str(item.get('category_id', '') or ''), 'stream_id': str(item.get('stream_id', '') or ''), 'epg_channel_id': str(item.get('epg_channel_id', '') or ''), 'is_adult': str(normalize_bool(item.get('is_adult', False))).lower()}
            if str(item.get('stream_kind', '') or '') in ('vod', 'episode'):
                params['play_nonce'] = str(int(time.time() * 1000))
            if item.get('vod_id'):
                params['vod_id'] = str(item.get('vod_id'))
            if item.get('series_id'):
                params['series_id'] = str(item.get('series_id'))
            url = build_url(**params)
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)
        else:
            url_params = {'mode': item.get('mode', 'seasons')}
            if 'params' in item:
                qs = urllib.parse.parse_qs(item['params'], keep_blank_values=True)
                for k, v in qs.items():
                    url_params[k] = v[0] if isinstance(v, list) else v
            url = build_url(**url_params)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, True)
    end_directory(cache_to_disc=True)

def load_search_state():
    try:
        ensure_profile_dir()
        search_path = search_state_storage_path()
        if not xbmcvfs.exists(search_path):
            return {}
        with open(search_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception as e:
        log(f"Falha ao ler estado da pesquisa: {e}", xbmc.LOGDEBUG)
        return {}

def save_search_state(data):
    try:
        ensure_profile_dir()
        search_path = search_state_storage_path()
        ensure_parent_dir(search_path)
        with open(search_path, 'w', encoding='utf-8') as f:
            json.dump(data or {}, f)
    except Exception as e:
        log(f"Falha ao salvar estado da pesquisa: {e}", xbmc.LOGDEBUG)

def remember_search(scope, query, results=None):
    state = load_search_state()
    state['last_scope'] = (scope or 'all').strip()
    state['last_query'] = (query or '').strip()
    if results is not None:
        state['last_results'] = results if isinstance(results, list) else []
    save_search_state(state)

def mark_resume_search(scope, query):
    state = load_search_state()
    state['resume_once'] = True
    state['last_scope'] = (scope or state.get('last_scope') or 'all').strip()
    state['last_query'] = (query or state.get('last_query') or '').strip()
    save_search_state(state)

def pop_resume_search():
    state = load_search_state()
    query = (state.get('last_query') or '').strip()
    scope = (state.get('last_scope') or 'all').strip()
    if state.get('resume_once') and query:
        state['resume_once'] = False
        save_search_state(state)
        cached_results = state.get('last_results')
        if isinstance(cached_results, list):
            return {'scope': scope, 'query': query, 'results': cached_results}
        return {'scope': scope, 'query': query}
    return None

def has_valid_credentials():
    return bool(USERNAME and PASSWORD and get_base_url())

def open_settings_and_refresh():
    ADDON.openSettings()
    refresh_runtime_settings()
    return has_valid_credentials()


def build_root_menu():
    items = [{
        'title': 'Entrar',
        'mode': 'enter',
        'plot': 'Acesso ao OnePlay VIP. Configure sua conta e entre no catálogo.',
        'fanart': addonFanart
        }
    ]
    build_menu(items)


def retry_after_settings_change(previous_fingerprint=''):
    try:
        xbmc.sleep(150)
    except Exception:
        pass

    refresh_runtime_settings()

    if not has_valid_credentials():
        return None

    current_fingerprint = fingerprint()
    if previous_fingerprint and current_fingerprint == previous_fingerprint:
        return None

    try:
        global _EPG_PARSED, _EPG_PARSED_SCOPE
        _EPG_PARSED = None
        _EPG_PARSED_SCOPE = None
    except Exception:
        pass

    return get_json("")

def get_param_map():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        parsed = urllib.parse.urlparse(sys.argv[2])
        q = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        for k, v in q.items():
            params[k] = v[0] if isinstance(v, list) else v
    return params

def get_param(name, default=""):
    return PARAMS.get(name, default)

def fingerprint():
    BASE_URL = get_base_url()
    return f"{BASE_URL}|{USERNAME}|{PASSWORD}"

def safe_requests_get(url, **kw):
    kw.setdefault('headers', HEADERS)
    kw.setdefault('timeout', 30)

    retries = int(kw.pop('retries', 2))
    backoff = float(kw.pop('backoff', 1.0))
    last_exc = None
    for attempt in range(retries + 1):
        try:
            r = requests.get(url, **kw)
            if r.status_code == 429 and attempt < retries:
                time.sleep(backoff * (2 ** attempt))
                continue
            r.raise_for_status()
            return r
        except requests.RequestException as e:
            last_exc = e
            if isinstance(e, requests.HTTPError):
                resp = getattr(e, 'response', None)
                if resp is not None and resp.status_code == 429 and attempt < retries:
                    time.sleep(backoff * (2 ** attempt))
                    continue
            break
    raise last_exc if last_exc else requests.RequestException("Falha na requisição")

def open_settings_after_error(context='erro'):
    if is_silent_action_mode():
        log(f"Abertura de configurações suprimida no modo {mode} após {context}", xbmc.LOGDEBUG)
        return
    try:
        ADDON.openSettings()
        refresh_runtime_settings()
        xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
        raise SystemExit
    except SystemExit:
        raise
    except Exception as exc:
        log(f"Falha ao abrir configurações após {context}: {exc}", xbmc.LOGERROR)
        try:
            xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
            raise SystemExit
        except SystemExit:
            raise
        except Exception as ret_exc:
            log(f"Falha ao retornar ao menu Enter após {context}: {ret_exc}", xbmc.LOGERROR)


def show_settings_error(title, message, context='erro de configuração'):
    if mode in ('download_apk', 'install_help'):
        log(f"Aviso de configuração suprimido no modo {mode}: {title} - {message}", xbmc.LOGDEBUG)
        return
    xbmcgui.Dialog().ok(title, message)
    open_settings_after_error(context)


def show_login_error(open_settings=True):
    if mode in ('download_apk', 'install_help'):
        log(f"Aviso de login suprimido no modo {mode}", xbmc.LOGDEBUG)
        return
    msg = (
        "[B][COLOR red]Não foi possível entrar[/COLOR][/B]\n\n"
        "[COLOR white]Verifique se o [B]usuário[/B], a [B]senha[/B] e o [B]servidor[/B] estão corretos.[/COLOR]\n\n"
        "[COLOR gold]Dicas:[/COLOR]\n"
        "[COLOR white]• Confirme se não há espaço extra no login[/COLOR]\n"
        "[COLOR white]• Verifique se a conta ainda está ativa[/COLOR]\n"
        "[COLOR white]• Confira se o servidor selecionado é o certo[/COLOR]"
    )
    xbmcgui.Dialog().ok("Erro de acesso", msg)
    if open_settings:
        open_settings_after_error('erro de login')

def get_json(endpoint):
    BASE_URL = get_base_url()
    if not all([BASE_URL, USERNAME, PASSWORD]):
        log("Credenciais incompletas.", xbmc.LOGERROR)
        show_settings_error("Configuração necessária", "Configure: usuário, senha e servidor nas configurações.", "configuração necessária")
        return None

    query = urllib.parse.urlencode({'username': USERNAME, 'password': PASSWORD})
    url = f"{BASE_URL.rstrip('/')}/player_api.php?{query}"
    if endpoint:
        url += f"&{endpoint}"
    log("Chamando API player_api.php")

    try:
        r = safe_requests_get(url)

        # alguns portais devolvem vazio, HTML ou texto quebrado quando login falha
        raw = (r.text or '').strip()
        if not raw:
            log("Resposta vazia da API.", xbmc.LOGERROR)
            show_login_error()
            return None

        try:
            data = r.json()
        except ValueError:
            log("Resposta inválida (não-JSON) da API.", xbmc.LOGERROR)

            raw_lower = raw.lower()
            if (
                '<html' in raw_lower or
                'access denied' in raw_lower or
                'unauthorized' in raw_lower or
                'invalid' in raw_lower or
                'username' in raw_lower or
                'password' in raw_lower
            ):
                show_login_error()
            else:
                show_settings_error(
                    "Erro de comunicação",
                    "O servidor respondeu em formato inválido.\nVerifique o usúario/senha ou servidor e tente novamente.",
                    "erro de comunicação"
                )
            return None

        # xtream costuma retornar auth=0 quando login falha
        user_info = data.get('user_info', {}) if isinstance(data, dict) else {}
        auth = str(user_info.get('auth', '1')).strip()
        status = str(user_info.get('status', '')).strip().lower()

        if auth == '0':
            log("API retornou auth=0.", xbmc.LOGERROR)
            show_login_error()
            return None

        if status in ['disabled', 'banned']:
            show_settings_error(
                "Acesso bloqueado",
                "Sua conta está bloqueada ou desativada.\nConfira o usuário/servidor ou entre em contato com o suporte.",
                "acesso bloqueado"
            )
            return None

        if status in ['expired', 'expirado']:
            show_settings_error(
                "Conta vencida",
                "Sua conta está vencida.\nRenove ou confira o usuário/servidor para continuar.",
                "conta vencida"
            )
            return None

        remember_validated_scope_state(BASE_URL, USERNAME)
        return data

    except requests.RequestException as e:
        try:
            status = e.response.status_code if getattr(e, 'response', None) else None
        except Exception:
            status = None

        log(f"Erro na requisição: {e}", xbmc.LOGERROR)

        if status == 429:
            show_dialog("Erro 429", "Muitas requisições para a API.\nTente novamente em instantes.")
        elif status in (401, 403):
            show_login_error()
        else:
            show_settings_error(
                "Erro de conexão",
                "Não foi possível comunicar com o servidor.\nVerifique o usuario/senha ou servidor e tente novamente.",
                "erro de conexão"
            )

    return None

# =========================
# Descrições (helpers + cache)
# =========================
def clean_plot(text):
    text = html.unescape(text or '')
    text = _TAG_RE.sub('', text)
    return text.strip()

def desc_cache_load(path):
    ensure_profile_dir()
    ensure_parent_dir(path)
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f) or {}
        except Exception:
            return {}
    return {}

def desc_cache_save(path, cache):
    try:
        ensure_profile_dir()
        ensure_parent_dir(path)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Falha ao salvar cache de descrições: {e}", xbmc.LOGERROR)

def desc_cache_get(cache, key):
    k = str(key)
    e = cache.get(k)
    if not isinstance(e, dict):
        return (False, '')
    fetched_at = e.get('fetched_at', 0)
    if not fetched_at or (time.time() - fetched_at) > DESC_TTL:
        return (False, '')
    return (True, e.get('plot', '') or '')

def desc_cache_put(cache, key, plot):
    cache[str(key)] = {'plot': plot or '', 'fetched_at': time.time()}

def extract_vod_plot(vod_info_json):
    if not isinstance(vod_info_json, dict):
        return ''
    info = vod_info_json.get('info') or {}
    movie_data = vod_info_json.get('movie_data') or {}
    plot = (
        info.get('plot')
        or info.get('description')
        or movie_data.get('plot')
        or movie_data.get('description')
        or ''
    )
    return clean_plot(plot)

def extract_series_plot(series_info_json):
    if not isinstance(series_info_json, dict):
        return ''
    info = series_info_json.get('info') or {}
    plot = (
        info.get('plot')
        or info.get('description')
        or info.get('overview')
        or ''
    )
    return clean_plot(plot)

def get_vod_plot_cached(vod_id):
    cache = desc_cache_load(vod_desc_cache_storage_path())
    has, plot = desc_cache_get(cache, vod_id)
    if has:
        return plot

    vod_info = get_json(f"action=get_vod_info&vod_id={vod_id}")
    plot = extract_vod_plot(vod_info)
    desc_cache_put(cache, vod_id, plot)
    desc_cache_save(vod_desc_cache_storage_path(), cache)
    return plot

def get_series_plot_cached(series_id):
    cache = desc_cache_load(series_desc_cache_storage_path())
    has, plot = desc_cache_get(cache, series_id)
    if has:
        return plot

    series_info = get_json(f"action=get_series_info&series_id={series_id}")
    plot = extract_series_plot(series_info)
    desc_cache_put(cache, series_id, plot)
    desc_cache_save(series_desc_cache_storage_path(), cache)
    return plot


# =========================
# EPG (cache + parsing)
# =========================
def epg_meta_load():
    meta_path = epg_meta_storage_path()
    if os.path.exists(meta_path):
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def epg_meta_save(meta):
    try:
        meta_path = epg_meta_storage_path()
        ensure_parent_dir(meta_path)
        with open(meta_path, 'w', encoding='utf-8') as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Falha ao salvar meta EPG: {e}", xbmc.LOGERROR)

def epg_should_refresh():
    meta = epg_meta_load()
    fp = fingerprint()
    meta_fp = meta.get('fingerprint')
    fetched_at = meta.get('fetched_at', 0)
    if meta_fp != fp:
        log("Fingerprint mudou (usuário/senha/servidor). Renovando EPG e limpando caches.")
        clear_desc_caches()
        return True
    epg_xml_path = epg_xml_storage_path()
    if not os.path.exists(epg_xml_path):
        log("EPG não existe. Baixando.")
        return True
    if (time.time() - fetched_at) >= EPG_TTL:
        log("EPG expirado. Renovando.")
        return True
    return False

def epg_build_urls():
    base_url = get_base_url().rstrip('/')
    return [
        (f"{base_url}/xmltv.php?username={USERNAME}&password={PASSWORD}", 'principal'),
        (f"{base_url}/epg.php?username={USERNAME}&password={PASSWORD}", 'fallback')
    ]


def epg_validate_xml_text(xml_text):
    if not xml_text:
        return False, 'resposta vazia'
    text = xml_text.strip()
    if len(text) < 32:
        return False, 'resposta muito curta'
    if not text.startswith('<'):
        return False, 'resposta não parece XML'
    try:
        root = ET.fromstring(text)
    except Exception as e:
        return False, f'xml inválido: {e}'
    if root.tag not in ('tv', 'xmltv', 'epg'):
        # Alguns provedores usam <tv>; qualquer raiz com programme/channel também serve.
        has_epg_nodes = bool(root.findall('.//channel') or root.findall('.//programme'))
        if not has_epg_nodes:
            return False, f'raiz XML inesperada: {root.tag}'
    has_programmes = bool(root.findall('.//programme'))
    has_channels = bool(root.findall('.//channel'))
    if not has_programmes and not has_channels:
        return False, 'XML sem canais nem programas'
    return True, 'ok'



def epg_download():
    ensure_profile_dir()
    last_error = None
    epg_xml_path = epg_xml_storage_path()
    ensure_parent_dir(epg_xml_path)

    for url, label in epg_build_urls():
        try:
            log(f"Baixando EPG ({label}): {url}")
            r = safe_requests_get(url)
            xml_text = r.text
            valid, reason = epg_validate_xml_text(xml_text)
            if not valid:
                log(f"EPG {label} rejeitado: {reason}", xbmc.LOGWARNING)
                last_error = reason
                continue
            with open(epg_xml_path, 'w', encoding='utf-8') as f:
                f.write(xml_text)
            epg_meta_save({'fingerprint': fingerprint(), 'fetched_at': time.time(), 'source': label})
            log(f"EPG salvo com sucesso pela fonte {label}")
            return
        except Exception as e:
            last_error = str(e)
            log(f"Falha ao baixar EPG ({label}): {e}", xbmc.LOGWARNING)

    raise Exception(last_error or 'falha desconhecida ao baixar EPG')

XMLTV_DEFAULT_OFFSET_SECS = -(3 * 3600)  # America/Sao_Paulo quando o feed vier sem timezone

def parse_xmltv_time(ts):
    if not ts:
        return int(time.time())
    ts = ts.strip()
    if len(ts) < 14 or not ts[:14].isdigit():
        log(f"Timestamp XMLTV inválido: {ts}")
        return int(time.time())

    base = ts[:14]
    try:
        dt = datetime.strptime(base, "%Y%m%d%H%M%S")
    except Exception:
        return int(time.time())

    offset_secs = XMLTV_DEFAULT_OFFSET_SECS
    rest = ts[14:].strip()
    if rest:
        rest = rest.replace(' ', '')
        if rest.startswith(('+', '-')) and len(rest) >= 5:
            try:
                sign = 1 if rest[0] == '+' else -1
                hh = int(rest[1:3])
                mm = int(rest[3:5])
                offset_secs = sign * (hh * 3600 + mm * 60)
            except Exception:
                offset_secs = XMLTV_DEFAULT_OFFSET_SECS
        else:
            log(f"XMLTV sem timezone reconhecível, assumindo America/Sao_Paulo: {ts}")
    else:
        log(f"XMLTV sem timezone, assumindo America/Sao_Paulo: {ts}")

    epoch = calendar.timegm(dt.timetuple()) - offset_secs
    return epoch if epoch > 0 else int(time.time())

def normalize_epg_channel_id(cid):
    if not cid:
        return ''
    return cid.strip().lower().replace('&amp;', '&')

def epg_load_parsed():
    global _EPG_PARSED, _EPG_PARSED_SCOPE

    current_scope = current_storage_identity()
    if _EPG_PARSED is not None and _EPG_PARSED_SCOPE == current_scope:
        return _EPG_PARSED

    if epg_should_refresh():
        try:
            epg_download()
        except Exception as e:
            log(f"Falha ao baixar EPG: {e}", xbmc.LOGERROR)
            _EPG_PARSED = {'channels': {}, 'progs': {}}
            _EPG_PARSED_SCOPE = current_scope
            return _EPG_PARSED

    epg_xml_path = epg_xml_storage_path()
    if not os.path.exists(epg_xml_path):
        _EPG_PARSED = {'channels': {}, 'progs': {}}
        _EPG_PARSED_SCOPE = current_scope
        return _EPG_PARSED

    try:
        tree = ET.parse(epg_xml_path)
        root = tree.getroot()

        channels = {}
        progs = {}

        for c in root.findall(".//channel"):
            cid = normalize_epg_channel_id(c.get('id'))
            dn = (c.findtext('display-name') or '').strip()
            channels[cid] = dn

        for p in root.findall(".//programme"):
            cid = normalize_epg_channel_id(p.get('channel'))

            try:
                start = int(p.get('start_timestamp'))
            except (TypeError, ValueError):
                start = parse_xmltv_time(p.get('start'))

            try:
                stop = int(p.get('stop_timestamp') or p.get('end_timestamp'))
            except (TypeError, ValueError):
                stop = parse_xmltv_time(p.get('stop') or p.get('end'))

            if stop <= start:
                stop = start + 3600

            title = (p.findtext('title') or '').strip()
            desc = (p.findtext('desc') or '').strip()

            if cid not in progs:
                progs[cid] = []

            progs[cid].append({'start': start, 'end': stop, 'title': title, 'desc': desc})

        for cid, arr in progs.items():
            arr.sort(key=lambda x: x['start'])

        _EPG_PARSED = {'channels': channels, 'progs': progs}
        _EPG_PARSED_SCOPE = current_scope
        log(f"EPG carregado: canais={len(channels)}, programas={sum(len(v) for v in progs.values())}")
    except Exception as e:
        log(f"Erro parseando EPG: {e}", xbmc.LOGERROR)
        _EPG_PARSED = {'channels': {}, 'progs': {}}
        _EPG_PARSED_SCOPE = current_scope

    return _EPG_PARSED

def epg_lookup_current_next(epg_channel_id, epg):
    cid = normalize_epg_channel_id(epg_channel_id)
    now = int(time.time())

    plist = epg['progs'].get(cid, [])
    current, nextp = None, None

    for i, pr in enumerate(plist):
        start = pr.get('start') or now
        end = pr.get('end') or (start + 3600)
        if end <= start:
            end = start + 3600
        pr['start'] = start
        pr['end'] = end

        if start <= now < end:
            current = pr
            if i + 1 < len(plist):
                nextp = plist[i + 1]
            break
        if start > now:
            nextp = pr
            if i - 1 >= 0 and plist[i - 1]['end'] > now:
                current = plist[i - 1]
            break

    return current, nextp

# =========================
# UI (menus)
# =========================
def build_menu(items, mode=None, is_playable=False):
    if not items:
        end_directory(cache_to_disc=True)
        return

    favorite_keys = favorites_key_set()

    for item in items:
        label = item.get('title', '')
        li = xbmcgui.ListItem(label=label)

        icon = item.get('icon', addonIcon) or addonIcon
        fanart = item.get('fanart', addonFanart) or addonFanart
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)

        plot = item.get('plot', '') or ''
        info = {'title': label}
        if plot:
            info['plot'] = plot
        li.setInfo('video', info)

        media_type = item.get('media_type') or ''
        if media_type:
            try:
                li.setProperty('mediatype', media_type)
            except Exception:
                pass

        item_is_adult = normalize_bool(item.get('is_adult', False))
        cm = []
        if item.get('vod_id'):
            cm_url = build_url(mode='show_vod_plot', vod_id=str(item['vod_id']), title=label, category_id=str(item.get('category_id', '') or ''), is_adult=str(item_is_adult).lower())
            cm.append(("Sinopse", f'RunPlugin({cm_url})'))
        if item.get('series_id'):
            cm_url = build_url(mode='show_series_plot', series_id=str(item['series_id']), title=label, category_id=str(item.get('category_id', '') or ''), is_adult=str(item_is_adult).lower())
            cm.append(("Sinopse", f'RunPlugin({cm_url})'))

        favorite_entry = favorite_entry_from_item(item)
        favorite_key_value = favorite_entry.get('key', '') if favorite_entry else ''
        favorite_kind = infer_favorite_kind(item)
        if favorite_kind and favorite_key_value:
            base_params = {
                'fav_kind': favorite_kind,
                'title': label,
                'favorite_title': str(item.get('favorite_title') or favorite_base_title(favorite_kind, label)),
                'icon': icon,
                'fanart': fanart,
                'plot': plot,
                'category_id': str(item.get('category_id', '') or ''),
                'is_adult': str(item_is_adult).lower(),
                'stream_id': str(item.get('stream_id', '') or ''),
                'vod_id': str(item.get('vod_id', '') or ''),
                'series_id': str(item.get('series_id', '') or ''),
                'container_extension': str(item.get('container_extension', '') or ''),
                'stream_type': str(item.get('stream_type', '') or ''),
                'stream_kind': str(item.get('stream_kind', '') or ''),
                'epg_channel_id': str(item.get('epg_channel_id', '') or '')
            }
            if item.get('from_search'):
                base_params['from_search'] = str(item.get('from_search')).lower()
                if item.get('search_scope'):
                    base_params['search_scope'] = item.get('search_scope', '')
                if item.get('search_query'):
                    base_params['search_query'] = item.get('search_query', '')
            if favorite_key_value in favorite_keys:
                remove_params = {'mode': 'remove_favorite', 'favorite_key': favorite_key_value}
                if item.get('from_search'):
                    remove_params['from_search'] = str(item.get('from_search')).lower()
                    if item.get('search_scope'):
                        remove_params['search_scope'] = item.get('search_scope', '')
                    if item.get('search_query'):
                        remove_params['search_query'] = item.get('search_query', '')
                cm_url = build_url(**remove_params)
                cm.append(("Remover dos Favoritos do Addon", f'RunPlugin({cm_url})'))
            else:
                cm_url = build_url(mode='add_favorite', **base_params)
                cm.append(("Adicionar aos Favoritos do Addon", f'RunPlugin({cm_url})'))

        if cm:
            li.addContextMenuItems(cm, replaceItems=False)

        if 'url' in item and is_playable:
            play = item['url'] or ''
            if not play:
                log(f"Ignorando item reproduzível sem URL: {label}", xbmc.LOGDEBUG)
                continue
            if 'User-Agent=' not in play:
                play = play + '|User-Agent=' + USER_AGENT

            li.setProperty('IsPlayable', 'true')

            params = {
                'mode': 'play',
                'url': play,
                'title': label,
                'icon': icon,
                'fanart': fanart,
                'normalplayer': str(item.get('normalplayer', 'false')).lower(),
                'stream_kind': item.get('stream_kind', ''),
                'container_extension': item.get('container_extension', ''),
                'category_id': str(item.get('category_id', '') or ''),
                'stream_id': str(item.get('stream_id', '') or ''),
                'epg_channel_id': str(item.get('epg_channel_id', '') or ''),
                'is_adult': str(item_is_adult).lower()
            }
            # Em filmes/episódios, evita o bookmark/resume nativo do Kodi
            # preso na URL do plugin (que pode disparar antes do fluxo interno do addon).
            if str(item.get('stream_kind', '') or '') in ('vod', 'episode'):
                params['play_nonce'] = str(int(time.time() * 1000))
            if item.get('vod_id'):
                params['vod_id'] = str(item['vod_id'])
            if item.get('series_id'):
                params['series_id'] = str(item['series_id'])
            if item.get('from_search'):
                params['from_search'] = str(item.get('from_search')).lower()
            if item.get('search_scope'):
                params['search_scope'] = item.get('search_scope', '')
            if item.get('search_query'):
                params['search_query'] = item.get('search_query', '')

            url = build_url(**params)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)
        else:
            url_params = {'mode': mode} if mode else {'mode': item.get('mode')}
            if 'params' in item:
                qs = urllib.parse.parse_qs(item['params'], keep_blank_values=True)
                for k, v in qs.items():
                    url_params[k] = v[0] if isinstance(v, list) else v
            if item.get('category_id'):
                url_params['category_id'] = str(item.get('category_id', '') or '')
            if item.get('is_adult'):
                url_params['is_adult'] = str(item_is_adult).lower()
            if item.get('from_search'):
                url_params['from_search'] = str(item.get('from_search')).lower()
            if item.get('search_scope'):
                url_params['search_scope'] = item.get('search_scope', '')
            if item.get('search_query'):
                url_params['search_query'] = item.get('search_query', '')
            url = build_url(**url_params)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, item.get('folder', True))

    end_directory(cache_to_disc=True)

# =========================
# Funções de dados
# =========================
# =========================
# Funções de dados
# =========================
def get_categories(endpoint):
    data = get_json(endpoint)
    if not data:
        return []

    if isinstance(data, list):
        cats = data
    elif isinstance(data, dict) and 'categories' in data:
        cats = data['categories']
    else:
        cats = list(data.values()) if isinstance(data, dict) else []

    items = []
    for cat in cats:
        name = html.unescape(cat.get('category_name', 'Sem nome'))
        category_id = str(cat.get('category_id', '') or '').strip()
        item_is_adult = is_adult_name(name)
        if item_is_adult and not is_adult_enabled():
            continue
        items.append({'title': name, 'params': f"category_id={category_id}", 'category_id': category_id, 'is_adult': item_is_adult})
    return items

def get_adult_category_ids(endpoint):
    data = get_json(endpoint)
    if not data:
        return set()

    if isinstance(data, list):
        cats = data
    elif isinstance(data, dict) and 'categories' in data:
        cats = data['categories']
    else:
        cats = list(data.values()) if isinstance(data, dict) else []

    adult_ids = set()
    for cat in cats:
        name = html.unescape((cat.get('category_name', '') or '').strip())
        category_id = str(cat.get('category_id', '') or '').strip()
        if category_id and is_adult_name(name):
            adult_ids.add(category_id)
    return adult_ids


def get_adult_content_ids(endpoint, adult_category_ids=None):
    adult_category_ids = {str(x or '').strip() for x in (adult_category_ids or set()) if str(x or '').strip()}
    if not adult_category_ids:
        return set()

    key_name = 'stream_id'
    if endpoint == 'get_series':
        key_name = 'series_id'

    ids = set()
    for cid in adult_category_ids:
        try:
            items = get_items(endpoint, cid, True, adult_category_ids)
        except Exception as exc:
            log(f'Falha ao mapear conteúdo adulto em {endpoint}/{cid}: {exc}', xbmc.LOGERROR)
            continue
        for item in items:
            item_id = str(item.get(key_name, '') or '').strip()
            if item_id:
                ids.add(item_id)
    return ids


def ensure_epg_loaded():
    global _EPG_PARSED, _EPG_PARSED_SCOPE
    current_scope = current_storage_identity()
    if _EPG_PARSED is None or _EPG_PARSED_SCOPE != current_scope:
        _EPG_PARSED = epg_load_parsed()
    return _EPG_PARSED

def epg_format_range(pr):
    if not pr:
        return ''
    try:
        start = int(pr.get('start') or 0)
        end = int(pr.get('end') or 0)
    except Exception:
        start, end = 0, 0
    if start <= 0:
        return ''
    if end <= start:
        end = start + 3600
    return f"{datetime.fromtimestamp(start).strftime('%H:%M')} - {datetime.fromtimestamp(end).strftime('%H:%M')}"


def annotate_live_with_epg(items_from_api):
    epg = ensure_epg_loaded()
    out = []
    for s in items_from_api:
        name = s.get('title') or s.get('name') or 'Sem nome'
        epg_id = s.get('epg_channel_id')
        current, nextp = epg_lookup_current_next(epg_id, epg) if epg_id else (None, None)

        label = name
        plot = ''
        if current:
            current_title = current.get('title', '').strip()
            current_desc = current.get('desc', '').strip()
            current_range = epg_format_range(current)
            label = f"{name} - {current_title}" if current_title else name
            if current_range and current_title:
                plot += f"Agora: {current_range} | {current_title}\n"
            elif current_title:
                plot += f"Agora: {current_title}\n"
            if current_desc:
                plot += f"{current_desc}\n\n"
            else:
                plot += "\n"
        if nextp:
            next_title = nextp.get('title', '').strip()
            next_desc = nextp.get('desc', '').strip()
            next_range = epg_format_range(nextp)
            if next_range and next_title:
                plot += f"Próximo: {next_range} | {next_title}\n"
            elif next_title:
                plot += f"Próximo: {next_title}\n"
            if next_desc:
                plot += f"{next_desc}"

        s2 = dict(s)
        s2['title'] = label
        if plot.strip():
            s2['plot'] = plot.strip()
        out.append(s2)
    return out

def get_items(endpoint, category_id=None, category_is_adult=False, adult_category_ids=None):
    BASE_URL = get_base_url()
    params = f"&category_id={category_id}" if category_id else ""
    data = get_json(f"action={endpoint}{params}")
    if not data:
        return []

    if adult_category_ids is None:
        adult_category_ids = set()
    else:
        adult_category_ids = {str(x or '').strip() for x in adult_category_ids if str(x or '').strip()}

    items = []

    if endpoint in ['get_live_streams', 'get_vod_streams']:
        vod_cache = None
        if endpoint == 'get_vod_streams':
            vod_cache = desc_cache_load(vod_desc_cache_storage_path())

        for s in data:
            url = s.get('stream_url', '')
            sid = s.get('stream_id')
            stype = s.get('stream_type', '')
            name = html.unescape(s.get('name', 'Sem nome'))
            icon = s.get('stream_icon', '')
            epg_channel_id = s.get('epg_channel_id') or None
            container_extension = (s.get('container_extension') or 'mp4').lower()
            item_category_id = str(s.get('category_id') or category_id or '').strip()
            item_is_adult = bool(category_is_adult) or item_category_id in adult_category_ids or is_adult_name(name)

            if sid:
                if endpoint == 'get_live_streams':
                    url = f'{BASE_URL.rstrip("/")}/live/{USERNAME}/{PASSWORD}/{sid}.m3u8'
                else:
                    url = f'{BASE_URL.rstrip("/")}/{stype}/{USERNAME}/{PASSWORD}/{sid}.{container_extension}'

            if not url:
                log(f"Ignorando item sem URL retornado pela API: {name}", xbmc.LOGDEBUG)
                continue

            item = {'title': name, 'url': url, 'icon': icon, 'fanart': addonFanart, 'container_extension': container_extension, 'stream_id': str(sid or ''), 'stream_type': stype, 'category_id': item_category_id, 'is_adult': item_is_adult}

            if epg_channel_id:
                item['epg_channel_id'] = epg_channel_id

            if endpoint == 'get_live_streams':
                item['media_type'] = 'video'
                item['normalplayer'] = 'false'
                item['stream_kind'] = 'live'
                item['favorite_kind'] = 'live'
            else:
                item['media_type'] = 'movie'
                item['normalplayer'] = 'false'
                item['stream_kind'] = 'vod'
                item['favorite_kind'] = 'vod'

            if endpoint == 'get_vod_streams' and sid:
                item['vod_id'] = sid
                plot = clean_plot(s.get('plot') or s.get('description') or '')
                if not plot and vod_cache is not None:
                    has, cached_plot = desc_cache_get(vod_cache, sid)
                    if has:
                        plot = cached_plot
                if plot:
                    item['plot'] = plot

            items.append(item)

        if endpoint == 'get_live_streams' and ENABLE_EPG.lower() == 'true':
            items = annotate_live_with_epg(items)

    elif endpoint == 'get_series':
        series_cache = desc_cache_load(series_desc_cache_storage_path())

        for s in data:
            icon = (s.get('info', {}) or {}).get('cover_big') or (s.get('info', {}) or {}).get('movie_image', '')
            if not icon:
                backdrops = s.get('backdrop_path') or []
                if isinstance(backdrops, str):
                    backdrops = [backdrops]
                icon = s.get('cover') if s.get('cover') else (backdrops[0] if backdrops else '')

            series_id = s.get('series_id', '')
            title = html.unescape(s.get('name', 'Sem nome'))
            item_category_id = str(s.get('category_id') or category_id or '').strip()
            item_is_adult = bool(category_is_adult) or item_category_id in adult_category_ids or is_adult_name(title)

            if not series_id:
                log(f"Ignorando série sem series_id: {title}", xbmc.LOGDEBUG)
                continue

            item = {'title': title, 'params': f"series_id={series_id}&category_id={urllib.parse.quote(item_category_id, safe='')}&is_adult={'true' if item_is_adult else 'false'}", 'icon': icon, 'series_id': series_id, 'fanart': addonFanart, 'media_type': 'tvshow', 'category_id': item_category_id, 'is_adult': item_is_adult, 'favorite_kind': 'series'}

            plot = clean_plot(s.get('plot') or (s.get('info', {}) or {}).get('plot') or (s.get('info', {}) or {}).get('overview') or '')
            if not plot and series_id:
                has, cached_plot = desc_cache_get(series_cache, series_id)
                if has:
                    plot = cached_plot
            if plot:
                item['plot'] = plot

            items.append(item)

    return items

def get_seasons(series_id, category_id='', is_adult=False):
    BASE_URL = get_base_url()
    data = get_json(f"action=get_series_info&series_id={series_id}")
    if not data:
        return []

    try:
        plot = extract_series_plot(data)
        if plot and series_id:
            cache = desc_cache_load(series_desc_cache_storage_path())
            desc_cache_put(cache, series_id, plot)
            desc_cache_save(series_desc_cache_storage_path(), cache)
    except Exception as e:
        log(f"Falha ao cachear sinopse da série: {e}", xbmc.LOGDEBUG)

    seasons = data.get('episodes', {})
    items = []

    def _season_sort_key(raw_name):
        m = re.search(r'\d+', str(raw_name or ''))
        if m:
            try:
                return (0, int(m.group(0)))
            except Exception:
                pass
        return (1, str(raw_name or '').lower())

    for season_name in sorted(seasons.keys(), key=_season_sort_key):
        episodes = seasons.get(season_name) or []
        ep_list = []
        for index, ep in enumerate(episodes):
            index += 1
            title = html.unescape(ep.get('title', 'Sem título'))
            eid = ep.get('id') or ep.get('episode_id') or ep.get('stream_id')
            ext = (ep.get('info', {}) or {}).get('container_extension') or 'mp4'
            icon = (ep.get('info', {}) or {}).get('cover_big') or (ep.get('info', {}) or {}).get('movie_image', '')
            url = f"{BASE_URL.rstrip('/')}/series/{USERNAME}/{PASSWORD}/{eid}.{ext}" if eid else ep.get('direct_source', '')
            if not url:
                log(f"Ignorando episódio sem URL em {season_name}: {title}", xbmc.LOGDEBUG)
                continue

            ep_list.append({'title': str(index) + ' - ' + title, 'url': url, 'icon': icon, 'fanart': addonFanart, 'media_type': 'episode', 'normalplayer': 'false', 'stream_kind': 'episode', 'stream_id': str(eid or ''), 'series_id': str(series_id or ''), 'container_extension': ext.lower(), 'category_id': str(category_id or ''), 'is_adult': bool(is_adult)})

        if not ep_list:
            continue

        payload = urllib.parse.quote(json.dumps(ep_list, ensure_ascii=False), safe='')
        items.append({'title': f"Temporada {season_name}", 'params': f"episodes={payload}&series_id={series_id}&category_id={urllib.parse.quote(str(category_id or ''), safe='')}&is_adult={'true' if is_adult else 'false'}"})
    return items

def search_global(query, scope='all', max_results=120):
    query = (query or '').strip().lower()
    if not query:
        show_dialog("Aviso", "Digite algo para pesquisar.")
        return []

    if len(query) < 3:
        show_dialog("Aviso", "Digite pelo menos 3 caracteres para pesquisar.")
        return []

    scope_map = {
        'all': [('get_live_streams', 'Canal: ', True), ('get_vod_streams', 'Filme: ', True), ('get_series', 'Série: ', False)],
        'live': [('get_live_streams', 'Canal: ', True)],
        'vod': [('get_vod_streams', 'Filme: ', True)],
        'series': [('get_series', 'Série: ', False)]
    }
    plan = scope_map.get(scope, scope_map['all'])

    adult_category_map = {
        'get_live_streams': get_adult_category_ids('get_live_categories'),
        'get_vod_streams': get_adult_category_ids('get_vod_categories'),
        'get_series': get_adult_category_ids('get_series_categories')
    }
    adult_content_map = {
        'get_live_streams': get_adult_content_ids('get_live_streams', adult_category_map.get('get_live_streams', set())),
        'get_vod_streams': get_adult_content_ids('get_vod_streams', adult_category_map.get('get_vod_streams', set())),
        'get_series': get_adult_content_ids('get_series', adult_category_map.get('get_series', set()))
    }

    results = []
    seen = set()
    progress = xbmcgui.DialogProgress()
    progress.create('Pesquisa Global', 'Consultando catálogo...')

    try:
        total = len(plan)
        for idx, (endpoint, prefix, playable) in enumerate(plan, start=1):
            if progress.iscanceled():
                break
            label = {'get_live_streams': 'Buscando canais...', 'get_vod_streams': 'Buscando filmes...', 'get_series': 'Buscando séries...'}.get(endpoint, 'Pesquisando...')
            progress.update(int(((idx - 1) / float(total)) * 100), label)
            items = get_items(endpoint, adult_category_ids=adult_category_map.get(endpoint, set()))
            adult_content_ids = adult_content_map.get(endpoint, set())
            for i in items:
                title = (i.get('title', '') or '').strip()
                if not title or query not in title.lower():
                    continue
                item_is_adult = normalize_bool(i.get('is_adult', False))
                if not item_is_adult:
                    if endpoint == 'get_series':
                        lookup_id = str(i.get('series_id', '') or '').strip()
                    else:
                        lookup_id = str(i.get('stream_id', '') or i.get('vod_id', '') or '').strip()
                    if lookup_id and lookup_id in adult_content_ids:
                        item_is_adult = True
                if item_is_adult:
                    continue
                key = f"{endpoint}|{title.lower()}|{i.get('url', '')}|{i.get('params', '')}"
                if key in seen:
                    continue
                seen.add(key)
                entry = {'title': prefix + title, 'favorite_title': title, 'icon': i.get('icon', ''), 'fanart': i.get('fanart', addonFanart), 'plot': i.get('plot', ''), 'media_type': i.get('media_type', ''), 'category_id': str(i.get('category_id', '') or ''), 'is_adult': item_is_adult}
                entry['from_search'] = 'true'
                entry['search_scope'] = scope
                entry['search_query'] = query
                if playable:
                    entry['url'] = i.get('url', '')
                    entry['normalplayer'] = i.get('normalplayer', 'false')
                    entry['stream_kind'] = i.get('stream_kind', '')
                    entry['container_extension'] = i.get('container_extension', '')
                    entry['stream_id'] = i.get('stream_id', '')
                    entry['stream_type'] = i.get('stream_type', '')
                    entry['epg_channel_id'] = i.get('epg_channel_id', '')
                    if i.get('vod_id'):
                        entry['vod_id'] = i['vod_id']
                else:
                    entry['mode'] = 'seasons'
                    entry['params'] = i.get('params', '')
                    if i.get('series_id'):
                        entry['series_id'] = i['series_id']
                results.append(entry)
                if len(results) >= max_results:
                    progress.update(100, 'Limite de resultados atingido.')
                    return results
            progress.update(int((idx / float(total)) * 100), label)
    finally:
        progress.close()

    return results

def get_account_info():
    data = get_json("")
    if not data:
        return None
    user_info = data.get('user_info', {})
    if not user_info:
        log("Nenhuma informação de usuário retornada pela API.", xbmc.LOGERROR)
        show_dialog("Erro", "Não foi possível obter informações da conta.")
        return None
    username = user_info.get('username', 'Não informado')
    status = user_info.get('status', 'Não informado')
    max_connections = user_info.get('max_connections', 'Não informado')
    active_connections = user_info.get('active_cons', 'Não informado')
    created_at = user_info.get('created_at', 0)
    exp_date = user_info.get('exp_date', 0)
    try:
        created_at_str = datetime.fromtimestamp(int(created_at)).strftime('%d/%m/%Y') if created_at and str(created_at).isdigit() else 'Não informado'
    except Exception:
        created_at_str = 'Não informado'
    try:
        exp_date_str = datetime.fromtimestamp(int(exp_date)).strftime('%d/%m/%Y') if exp_date and str(exp_date).isdigit() else 'Não informado'
    except Exception:
        exp_date_str = 'Não informado'
    status_color = get_status_color(status)
    info_text = (
        f"[B]Usuário:[/B] {color(username, 'white')}\n"
        f"[B]Status:[/B] {color(status.upper(), status_color)}\n\n"
        f"[B]Criado em:[/B] {format_date(created_at_str)}\n"
        f"[B]Vencimento:[/B] {format_date(exp_date_str)}\n\n"
        f"[B]Conexões Máximas:[/B] {color(max_connections, 'white')}\n"
        f"[B]Conexões Ativas:[/B] {color(active_connections, 'orange')}\n\n"
        f"[B]{SUPPORT_CONTACT_LABEL}:[/B] {color(SUPPORT_WHATSAPP, 'gold')}\n"
        f"[B]QR Code:[/B] Feche esta tela para abrir o suporte via WhatsApp / QR Code."
    )
    return info_text

def play_item(url, title, icon, normalplayer, fanart=None, vod_id=None, series_id=None, stream_kind='', container_extension='', stream_id='', is_adult=False):
    # Busca sinopse de forma leve (apenas no item que vai tocar)
    plot = ''
    try:
        if vod_id:
            plot = get_vod_plot_cached(vod_id) or ''
        elif series_id:
            plot = get_series_plot_cached(series_id) or ''
    except Exception as e:
        log(f"Falha ao obter sinopse no play: {e}", xbmc.LOGDEBUG)
        plot = ''

    if url and 'User-Agent=' not in url:
        url = url + '|User-Agent=' + USER_AGENT

    fanart = fanart or addonFanart
    resume_meta = {
        'url': url,
        'icon': icon,
        'fanart': fanart,
        'plot': plot,
        'normalplayer': normalplayer,
        'stream_kind': stream_kind,
        'container_extension': container_extension,
        'vod_id': vod_id or '',
        'series_id': series_id or '',
        'stream_id': stream_id or '',
        'is_adult': normalize_bool(is_adult)
    }

    # Resume leve para filmes e episódios sem sair do fluxo base da 0.0.5:
    # mantém setResolvedUrl e só adiciona seek/monitor por cima.
    use_resume = is_vod_resume_enabled() and (
        (stream_kind == 'vod' and bool(vod_id)) or
        (stream_kind == 'episode' and (bool(stream_id) or bool(url)))
    )
    resume_key = ''
    resume_entry = None
    resume_seconds = 0.0
    resume_total = 0.0
    if use_resume:
        resume_key = make_resume_key(stream_kind=stream_kind, vod_id=vod_id, stream_id=stream_id, url=url)
        resume_entry = get_resume_point(resume_key)
        resume_seconds = prompt_resume_position(title, resume_entry, resume_key=resume_key)
        try:
            resume_total = float((resume_entry or {}).get('total') or 0)
        except Exception:
            resume_total = 0.0

    use_resolved = normalplayer == 'false' or stream_kind in ('live', 'vod', 'episode')

    if use_resolved:
        li = xbmcgui.ListItem(path=url)
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        info = {'title': title}
        if plot:
            info['plot'] = plot
        if stream_kind == 'vod':
            info['mediatype'] = 'movie'
        elif stream_kind == 'episode':
            info['mediatype'] = 'episode'
        li.setInfo('video', info)
        if stream_kind == 'live':
            configure_live_stream_listitem(li, url)
        elif stream_kind in ('vod', 'episode'):
            if container_extension and not detect_stream_extension(url):
                try:
                    li.setProperty('oneplay.container_extension', container_extension)
                except Exception:
                    pass
            configure_vod_stream_listitem(li, url, stream_kind)
            try:
                li.setProperty('IsPlayable', 'true')
            except Exception:
                pass
            if use_resume and resume_seconds > 0:
                try:
                    tag = li.getVideoInfoTag()
                    try:
                        tag.setResumePoint(float(resume_seconds), float(resume_total or 0))
                    except Exception:
                        pass
                except Exception:
                    pass
                try:
                    li.setProperty('ResumeTime', str(float(resume_seconds)))
                    if resume_total > 0:
                        li.setProperty('TotalTime', str(float(resume_total)))
                    li.setProperty('StartOffset', str(float(resume_seconds)))
                except Exception:
                    pass
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
        if use_resume:
            player = xbmc.Player()
            if resume_seconds > 0:
                apply_resume_seek(player, resume_seconds)
            monitor_and_persist_resume(player, resume_key, title=title, meta=resume_meta)
    else:
        li = xbmcgui.ListItem(label=title, path=url)
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        info = {'title': title}
        if plot:
            info['plot'] = plot
        li.setInfo('video', info)
        if stream_kind in ('vod', 'episode'):
            configure_vod_stream_listitem(li, url, stream_kind)
        player = xbmc.Player()
        player.play(item=url, listitem=li)

def days_until_expire(exp_date):
    try:
        exp_date = int(exp_date)
        if exp_date <= 0:
            return None
        now = int(time.time())
        seconds_left = exp_date - now
        return int(seconds_left // 86400)
    except Exception:
        return None

def get_enter_menu_items():
    settings_item = {'title': 'Configurações', 'mode': 'settings', 'plot': 'Abra as configurações do addon.', 'fanart': addonFanart}
    items = [
        {'title': 'Informações da Conta', 'mode': 'account_info', 'plot': 'Mostra status da conta, validade, criação e limite de conexões. Ao fechar, permite abrir o suporte por WhatsApp / QR Code.', 'fanart': addonFanart},
        {'title': 'Pesquisa Global', 'mode': 'search', 'plot': 'Busca canais, filmes e séries em todo o catálogo.', 'fanart': addonFanart},
        {'title': 'Favoritos', 'mode': 'favorites', 'plot': 'Atalhos rápidos para canais, filmes e séries favoritados.', 'fanart': addonFanart},
        {'title': 'TV (Canais Ao Vivo)', 'mode': 'tv', 'plot': 'Lista as categorias de canais ao vivo disponíveis.', 'fanart': addonFanart},
        {'title': 'Filmes', 'mode': 'movies', 'plot': 'Acesse as categorias de filmes disponíveis no servidor.', 'fanart': addonFanart},
        {'title': 'Séries', 'mode': 'series', 'plot': 'Acesse as categorias, temporadas e episódios das séries.', 'fanart': addonFanart},
    ]
    if is_vod_resume_enabled():
        items.insert(2, {'title': 'Continue Assistindo', 'mode': 'continue_watching', 'plot': 'Mostra filmes e episódios com resume pendente para continuar de onde parou.', 'fanart': addonFanart})
    items.append(settings_item)
    return items

# =========================
# Rotas
# =========================
def guard_adult_flag_from_params(title='Conteúdo Adulto', fallback_flag='false'):
    if not normalize_bool(fallback_flag):
        return True
    if not is_adult_enabled():
        show_dialog('Conteúdo Adulto', 'O conteúdo adulto está desativado nas configurações do addon.')
        return False
    return True


# =========================
# Rotas
# =========================
PARAMS = get_param_map()
mode = get_param('mode', 'main')
suppress_expire_popup = normalize_bool(get_param('suppress_expire', 'false'))
log(f"Modo: {mode}")

if mode == 'download_apk':
    handle_apk_download()
    raise SystemExit
elif mode == 'install_help':
    show_install_apk_help()
    raise SystemExit

if mode == 'main':
    build_root_menu()

elif mode == 'enter':
    refresh_runtime_settings()
    data = None
    needs_qr = not USERNAME or not PASSWORD

    if not has_valid_credentials():
        if needs_qr:
            show_qr_code()
        if not open_settings_and_refresh():
            return_to_root_menu_with_message('Configuração necessária', 'Defina: usuário, senha e servidor para continuar.')
        else:
            try:
                previous_fingerprint = fingerprint()
                data = get_json("")
                if not data:
                    data = retry_after_settings_change(previous_fingerprint)
                if not data:
                    build_root_menu()
                else:
                    user_info = (data or {}).get('user_info', {})
                    exp_date = user_info.get('exp_date', 0)
                    days_left = days_until_expire(exp_date)
                    if not suppress_expire_popup:
                        show_expire_popup(days_left, exp_date)
                    build_menu(get_enter_menu_items())
            except Exception as e:
                log(f"Erro aviso vencimento: {e}", xbmc.LOGDEBUG)
                build_root_menu()
    else:
        try:
            previous_fingerprint = fingerprint()
            data = get_json("")
            if not data:
                data = retry_after_settings_change(previous_fingerprint)
            if not data:
                build_root_menu()
            else:
                user_info = (data or {}).get('user_info', {})
                exp_date = user_info.get('exp_date', 0)
                days_left = days_until_expire(exp_date)
                if not suppress_expire_popup:
                    show_expire_popup(days_left, exp_date)
                build_menu(get_enter_menu_items())
        except Exception as e:
            log(f"Erro aviso vencimento: {e}", xbmc.LOGDEBUG)
            build_root_menu()

elif mode == 'account_info':
    info_text = get_account_info()
    if info_text:
        xbmcgui.Dialog().textviewer("Informações da Conta", info_text)
        try:
            if xbmcgui.Dialog().yesno('Suporte', 'Abrir WhatsApp / QR Code do suporte agora?'):
                show_qr_code()
        except Exception as e:
            log(f"Falha ao oferecer QR Code após informações da conta: {e}", xbmc.LOGDEBUG)
    else:
        show_dialog("Erro", "Não foi possível obter informações da conta.")

elif mode == 'show_qr':
    show_qr_code()


elif mode == 'settings':
    ADDON.openSettings()

elif mode == 'change_adult_pin':
    current_pin = (ADULT_PIN or DEFAULT_ADULT_PIN).strip()
    if current_pin and not prompt_current_adult_pin('PIN atual do Conteúdo Adulto'):
        show_dialog('PIN adulto', 'PIN atual inválido.')
        raise SystemExit
    entered = xbmcgui.Dialog().input('Novo PIN adulto (4 dígitos)', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if entered is None:
        raise SystemExit
    new_pin = (entered or '').strip()
    if not re.fullmatch(r'\d{4}', new_pin):
        show_dialog('PIN adulto', 'Informe exatamente 4 dígitos numéricos.')
        raise SystemExit
    confirm = xbmcgui.Dialog().input('Confirme o novo PIN adulto', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if confirm is None or (confirm or '').strip() != new_pin:
        show_dialog('PIN adulto', 'A confirmação do PIN não confere.')
        raise SystemExit
    try:
        ADDON.setSetting('adult_pin', new_pin)
    except Exception as exc:
        log(f'Falha ao salvar PIN adulto: {exc}', xbmc.LOGERROR)
        show_dialog('PIN adulto', 'Não foi possível salvar o novo PIN.')
        raise SystemExit
    refresh_runtime_settings()
    clear_adult_session()
    notify('PIN adulto alterado com sucesso.', heading='Conteúdo Adulto', iconimage='INFO')

elif mode == 'favorites':
    build_favorites_menu()

elif mode == 'continue_watching':
    build_continue_watching_menu()

elif mode == 'clear_resume_entry':
    resume_key = get_param('resume_key', '')
    if not resume_key:
        show_dialog('Continue Assistindo', 'Resume inválido para remoção.')
    else:
        clear_resume_point(resume_key)
        notify('Item removido de Continue Assistindo.', heading='Continue Assistindo', iconimage='INFO')
        items, _legacy_count = list_continue_watching_items()
        try:
            if items:
                xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='continue_watching'))
            else:
                xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
        except Exception:
            refresh_container()
        raise SystemExit

elif mode == 'add_favorite':
    entry = favorite_entry_from_params(PARAMS)
    if not entry:
        show_dialog('Favoritos', 'Não foi possível adicionar este item aos favoritos.')
    elif add_favorite(entry):
        notify('Item adicionado aos favoritos.', heading='Favoritos', iconimage='INFO')
        if get_param('from_search', 'false') == 'true':
            mark_resume_search(get_param('search_scope', 'all'), get_param('search_query', ''))
            refresh_container()
        else:
            refresh_container()
    else:
        show_dialog('Favoritos', 'Não foi possível salvar o favorito.')

elif mode == 'remove_favorite':
    favorite_key_value = get_param('favorite_key', '')
    if not favorite_key_value:
        entry = favorite_entry_from_params(PARAMS)
        favorite_key_value = entry.get('key', '') if entry else ''
    if not favorite_key_value:
        show_dialog('Favoritos', 'Favorito inválido para remoção.')
    elif remove_favorite(favorite_key_value):
        notify('Item removido dos favoritos.', heading='Favoritos', iconimage='INFO')
        if get_param('from_search', 'false') == 'true':
            mark_resume_search(get_param('search_scope', 'all'), get_param('search_query', ''))
            refresh_container()
        elif get_param('from_favorites', 'false') == 'true':
            items = list_favorites_items()
            try:
                if items:
                    xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='favorites'))
                else:
                    xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
            except Exception:
                refresh_container()
            raise SystemExit
        else:
            refresh_container()
    else:
        show_dialog('Favoritos', 'Não foi possível remover o favorito.')

elif mode == 'tv':
    build_menu(get_categories('action=get_live_categories'), 'live_items')

elif mode == 'live_items':
    cid = get_param('category_id')
    adult_flag = get_param('is_adult', 'false')
    if guard_adult_flag_from_params(get_param('title', 'Categoria adulta'), adult_flag):
        build_menu(get_items('get_live_streams', cid, normalize_bool(adult_flag)), is_playable=True)

elif mode == 'movies':
    build_menu(get_categories('action=get_vod_categories'), 'movie_items')

elif mode == 'movie_items':
    cid = get_param('category_id')
    adult_flag = get_param('is_adult', 'false')
    if guard_adult_flag_from_params(get_param('title', 'Categoria adulta'), adult_flag):
        build_menu(get_items('get_vod_streams', cid, normalize_bool(adult_flag)), is_playable=True)

elif mode == 'series':
    build_menu(get_categories('action=get_series_categories'), 'series_items')

elif mode == 'series_items':
    cid = get_param('category_id')
    adult_flag = get_param('is_adult', 'false')
    if guard_adult_flag_from_params(get_param('title', 'Categoria adulta'), adult_flag):
        build_menu(get_items('get_series', cid, normalize_bool(adult_flag)), 'seasons')

elif mode == 'seasons':
    sid = get_param('series_id')
    adult_flag = get_param('is_adult', 'false')
    if guard_adult_flag_from_params(get_param('title', 'Série adulta'), adult_flag):
        build_menu(get_seasons(sid, get_param('category_id', ''), normalize_bool(adult_flag)), 'episodes')

elif mode == 'episodes':
    if not guard_adult_flag_from_params(get_param('title', 'Temporada adulta'), get_param('is_adult', 'false')):
        raise SystemExit
    eps_json = urllib.parse.unquote(get_param('episodes', '[]'))
    try:
        eps = json.loads(eps_json)
        if not isinstance(eps, list):
            raise ValueError('episodes inválido')
    except Exception as e:
        log(f"Falha ao carregar episódios: {e}", xbmc.LOGERROR)
        eps = []
    build_menu(eps, is_playable=True)

elif mode == 'search':
    resumed = pop_resume_search()
    if resumed:
        cached_results = resumed.get('results') if isinstance(resumed, dict) else None
        if isinstance(cached_results, list):
            if cached_results:
                build_menu(cached_results, is_playable=True)
            else:
                return_to_enter_menu_with_message('Pesquisa Global', 'Nenhum resultado encontrado no momento.')
        else:
            results = search_global(resumed.get('query', ''), scope=resumed.get('scope', 'all'))
            if results:
                remember_search(resumed.get('scope', 'all'), resumed.get('query', ''), results)
                build_menu(results, is_playable=True)
            else:
                return_to_enter_menu_with_message('Pesquisa Global', 'Nenhum resultado encontrado no momento.')
    else:
        scopes = [
            ('all', 'Tudo'),
            ('live', 'TV (Canais Ao Vivo)'),
            ('vod', 'Filmes'),
            ('series', 'Séries')
        ]
        labels = [label for _, label in scopes]
        sel = xbmcgui.Dialog().select('Onde deseja pesquisar?', labels)
        if sel >= 0:
            scope = scopes[sel][0]
            kb = xbmc.Keyboard('', 'Digite algo para pesquisar')
            kb.doModal()
            if kb.isConfirmed():
                query = (kb.getText() or '').strip()
                if query:
                    results = search_global(query, scope=scope)
                    if results:
                        remember_search(scope, query, results)
                        build_menu(results, is_playable=True)
                    else:
                        return_to_enter_menu_with_message('Pesquisa Global', 'Nenhum resultado encontrado no momento.')
                else:
                    return_to_enter_menu_with_message('Pesquisa Global', 'Nenhuma pesquisa no momento.')
            else:
                return_to_enter_menu_with_message('Pesquisa Global')
        else:
            return_to_enter_menu_with_message('Pesquisa Global')

elif mode == 'show_vod_plot':
    vod_id = get_param('vod_id')
    title = get_param('title', 'Sinopse')
    if vod_id:
        plot = get_vod_plot_cached(vod_id) or ''
        if plot:
            xbmcgui.Dialog().textviewer(title, plot)
        else:
            show_dialog("Sinopse", "Sem descrição disponível.")
    else:
        show_dialog("Erro", "vod_id ausente.")

elif mode == 'show_series_plot':
    series_id = get_param('series_id')
    title = get_param('title', 'Sinopse')
    if series_id:
        plot = get_series_plot_cached(series_id) or ''
        if plot:
            xbmcgui.Dialog().textviewer(title, plot)
        else:
            show_dialog("Sinopse", "Sem descrição disponível.")
    else:
        show_dialog("Erro", "series_id ausente.")

elif mode == 'play':
    url = get_param('url')
    normalplayer = get_param('normalplayer', 'false')
    title = get_param('title', 'Reproduzindo')
    icon = get_param('icon', addonIcon)
    fanart = get_param('fanart', addonFanart)
    vod_id = get_param('vod_id', '') or None
    series_id = get_param('series_id', '') or None
    stream_kind = get_param('stream_kind', '')
    container_extension = get_param('container_extension', '')
    if normalize_bool(get_param('is_adult', 'false')) and not ensure_adult_access(title):
        raise SystemExit
    if get_param('from_search', 'false') == 'true' and stream_kind in ('live', 'vod', 'episode'):
        mark_resume_search(get_param('search_scope', 'all'), get_param('search_query', ''))
    play_item(url, title, icon, normalplayer, fanart=fanart, vod_id=vod_id, series_id=series_id, stream_kind=stream_kind, container_extension=container_extension, stream_id=get_param('stream_id', ''), is_adult=normalize_bool(get_param('is_adult', 'false')))

else:
    show_dialog("Erro", f"Modo desconhecido: {mode}")