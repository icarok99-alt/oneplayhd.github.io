# -*- coding: utf-8 -*-
from variables import ADDON_PATH, HEADERS, SESSION_FILE, input_text, build_api_url
import os
from kodi_six import xbmc, xbmcaddon, xbmcgui, xbmcvfs, xbmcplugin
import pyxbmct
from customdns import DNSOverride
import requests
from content import ContentWindow  # Importando a classe ContentWindow
import json
import re


class CategoriesWindow(pyxbmct.AddonFullWindow):
    def __init__(self, title):
        super(CategoriesWindow, self).__init__(title)
        self.categories = []
        self.setGeometry(1280, 720, 100, 50)
        self.set_background(os.path.join(ADDON_PATH, 'resources', 'media', 'background.jpg'))
        xbmc.log(f"Inicializando CategoriesWindow com título: {title}", xbmc.LOGDEBUG)

    def configure(self, category_action, stream_action, username, password):
        """Configura os parâmetros adicionais após a inicialização."""
        self.category_action = category_action
        self.stream_action = stream_action
        self.username = username
        self.password = password
        xbmc.log(f"Configurando CategoriesWindow: action={category_action}, stream={stream_action}", xbmc.LOGDEBUG)
        self.create_controls()
        self.load_categories()
        self.setFocus(self.list_control)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def set_background(self, image):
        self.bg = xbmcgui.ControlImage(0, 0, 1280, 720, image)
        self.addControl(self.bg)

    def create_controls(self):
        self.list_control = pyxbmct.List()
        self.placeControl(self.list_control, 10, 10, 80, 30)
        self.connect(self.list_control, self.open_category)

    def load_categories(self):
        url = build_api_url(self.username, self.password, self.category_action)
        xbmc.log(f"Carregando categorias: {url}", xbmc.LOGDEBUG)
        try:
            DNSOverride()
            response = requests.get(url, headers=HEADERS, timeout=10)
            xbmc.log(f"Resposta da API: Status {response.status_code}", xbmc.LOGDEBUG)
            if response.status_code == 200:
                self.categories = response.json()
                xbmc.log(f"Categorias recebidas: {len(self.categories)}", xbmc.LOGDEBUG)
                if not self.categories:
                    xbmcgui.Dialog().ok("Erro", "Nenhuma categoria encontrada.")
                    self.close()
                    return
                for category in self.categories:
                    name = category.get('category_name', 'Sem Nome')
                    self.list_control.addItem(name)
                    xbmc.log(f"Adicionada categoria: {name}", xbmc.LOGDEBUG)
            else:
                xbmcgui.Dialog().ok("Erro", f"Falha ao carregar categorias: Status {response.status_code}")
                self.close()
        except Exception as e:
            xbmcgui.Dialog().ok("Erro", f"Erro ao carregar categorias: {str(e)}")
            xbmc.log(f"Erro ao carregar categorias: {str(e)}", xbmc.LOGERROR)
            self.close()

    def load_session(self):
        if os.path.exists(SESSION_FILE):
            try:
                with open(SESSION_FILE) as f:
                    return json.load(f)
            except Exception as e:
                xbmc.log(f"Erro ao carregar sessão: {str(e)}", xbmc.LOGERROR)
                xbmcgui.Dialog().ok("Erro", f"Sessão inválida: {str(e)}")
                os.remove(SESSION_FILE)
        return None         

    def open_category(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.categories):
            xbmc.log("Índice de categoria inválido", xbmc.LOGERROR)
            return
        category = self.categories[index]
        category_id = category.get('category_id')
        xbmc.log(f"Abrindo categoria: {category.get('category_name')} (ID: {category_id})", xbmc.LOGDEBUG)
        category_name = category.get('category_name', '')
        if re.search("Adult", category_name, re.IGNORECASE) or re.search("A Casa das Brasileirinhas", category_name, re.IGNORECASE):
            session = self.load_session() or {}
            password1 = session.get('parental', '')
            password2 = input_text('Senha Parental:')
            if str(password1) != str(password2):
                xbmcgui.Dialog().ok('ONEPLAY VIP', 'Senha Parental Incorreta')
                return
        content_window = ContentWindow(category.get('category_name', 'Conteúdo'))
        content_window.configure(self.stream_action, category_id, self.username, self.password)
        content_window.doModal()
        del content_window

    def close(self):
        super().close()