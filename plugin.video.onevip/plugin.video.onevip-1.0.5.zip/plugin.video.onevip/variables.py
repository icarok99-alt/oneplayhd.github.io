# -*- coding: utf-8 -*-
from kodi_six import xbmc, xbmcaddon, xbmcgui, xbmcvfs, xbmcplugin
import os
from urllib.parse import urlencode, quote

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = ADDON.getAddonInfo('path')
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
SESSION_FILE = os.path.join(PROFILE_PATH, 'session.json')
FAVORITES_FILE = os.path.join(PROFILE_PATH, 'favorites.json')
BASE_URL = 'http://rtext.vip'

if not os.path.exists(PROFILE_PATH):
    try:
        os.makedirs(PROFILE_PATH, exist_ok=True)
    except TypeError:
        if not os.path.exists(PROFILE_PATH):
            os.makedirs(PROFILE_PATH)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.122 Safari/537.36'
}

def encode_path_part(value):
    return quote(str(value), safe='')

def build_api_url(username, password, action=None, **params):
    query = {
        'username': str(username),
        'password': str(password),
    }
    if action is not None:
        query['action'] = action
    for key, value in params.items():
        if value is not None:
            query[key] = value
    return f"{BASE_URL}/player_api.php?{urlencode(query, doseq=True)}"

def to_unicode(text, encoding='utf-8', errors='strict'):
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string

def input_text(heading='Put text'):
    vq = get_search_string(heading=heading, message='')
    if not vq:
        return False
    return vq
