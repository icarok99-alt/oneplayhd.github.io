# -*- coding: utf-8 -*-
import os
import json
import requests
import pyxbmct
import sys
from datetime import datetime
import base64
import time
from kodi_six import xbmc, xbmcgui
from variables import ADDON_PATH, SESSION_FILE, HEADERS, input_text, build_api_url
from customdns import DNSOverride
from control import painel_interface


global exit_command
exit_command = False


class LoginWindow(pyxbmct.AddonFullWindow):
    def __init__(self, title="Login"):
        super(LoginWindow, self).__init__(title)
        self.setGeometry(1280, 720, 100, 50)
        self.set_background(os.path.join(ADDON_PATH, 'resources', 'media', 'background.jpg'))
        self.create_controls()
        self.set_navigation()
        self.setFocus(self.username_input)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def set_background(self, image):
        self.main_bg = xbmcgui.ControlImage(0, 0, 1280, 720, image)
        self.addControl(self.main_bg)

    def create_controls(self):
        self.username_input = pyxbmct.Edit('Usuário')
        self.placeControl(self.username_input, 38, 20, 9, 11)
        self.password_input = pyxbmct.Edit('Senha')
        self.placeControl(self.password_input, 46, 20, 9, 11)
        self.login_button = pyxbmct.Button('Login')
        self.placeControl(self.login_button, 54, 20, 10, 11)
        self.connect(self.login_button, self.attempt_login)
        self.login_back = pyxbmct.Button('Sair')
        self.placeControl(self.login_back, 63, 20, 10, 11)
        self.connect(self.login_back, self.close)

    def set_navigation(self):
        self.username_input.controlDown(self.password_input)
        self.password_input.controlUp(self.username_input)
        self.password_input.controlDown(self.login_button)
        self.login_button.controlDown(self.login_back)
        self.login_back.controlUp(self.login_button)
        self.login_button.controlUp(self.password_input)

    def attempt_login(self):
        username = self.username_input.getText()
        password = self.password_input.getText()
        if not username and not password:
            xbmcgui.Dialog().ok('Erro', 'Preencha o usuário e a senha.')
            return
        if not username:
            xbmcgui.Dialog().ok('Erro', 'Preencha o usuário.')
            return
        if not password:
            xbmcgui.Dialog().ok('Erro', 'Preencha a senha.')
            return
        url = build_api_url(username, password)
        try:
            DNSOverride()
            response = requests.get(url, headers=HEADERS, timeout=10)
            if response.status_code == 200:
                data = response.json()
                auth = data.get('user_info', {}).get('auth', 0)
                if auth == 1:
                    with open(SESSION_FILE, 'w') as f:
                        adult_password = input_text('Defina uma senha para Adultos')
                        if not adult_password:
                            adult_password = ''
                        json.dump({'username': username, 'password': password, 'data': data, 'parental': adult_password}, f)
                    self.close()
                    painel_interface()
                else:
                    xbmcgui.Dialog().ok('Erro', 'Usuário ou senha incorretos.')
            else:
                xbmcgui.Dialog().ok('Erro', f'Falha na conexão: Status {response.status_code}')
        except Exception as e:
            xbmcgui.Dialog().ok('Erro', f'Falha na conexão: {str(e)}')

    def close(self):
        global exit_command
        exit_command = True
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin("ActivateWindow(Home)")
        super().close()
