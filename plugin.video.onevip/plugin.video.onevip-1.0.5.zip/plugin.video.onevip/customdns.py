# -*- coding: utf-8 -*-
import socket
import random
import struct
import sys
import logging

logger = logging.getLogger(__name__)

class DNSOverride(object):
    _installed = False
    _original_getaddrinfo = socket.getaddrinfo
    _active_instance = None

    def __init__(self, dns_server="1.1.1.1"):
        self.dns_server = dns_server
        self.PY2 = sys.version_info[0] == 2
        self.cache = getattr(DNSOverride._active_instance, 'cache', {})
        self.debug_mode = False
        self.original_getaddrinfo = DNSOverride._original_getaddrinfo
        DNSOverride._active_instance = self
        if not DNSOverride._installed:
            socket.getaddrinfo = DNSOverride._dispatch
            DNSOverride._installed = True

    @classmethod
    def _dispatch(cls, host, port, *args, **kwargs):
        instance = cls._active_instance
        if instance is None:
            return cls._original_getaddrinfo(host, port, *args, **kwargs)
        return instance._resolver(host, port, *args, **kwargs)

    def bchr(self, val):
        return chr(val) if self.PY2 else bytes([val])

    def bjoin(self, parts):
        return b"".join(parts)

    def to_bytes(self, val):
        if self.PY2:
            return val if isinstance(val, str) else val.encode("utf-8")
        return val if isinstance(val, bytes) else val.encode("utf-8")

    def is_valid_ipv4(self, ip):
        try:
            socket.inet_aton(ip)
            return True
        except socket.error:
            return False

    def resolve(self, domain):
        if domain in self.cache:
            return self.cache[domain]

        def build_query(domain_name):
            tid = random.randint(0, 65535)
            header = struct.pack(">HHHHHH", tid, 0x0100, 1, 0, 0, 0)
            qname_parts = []
            for part in domain_name.split('.'):
                if not part:
                    continue
                qname_parts.append(self.bchr(len(part)))
                qname_parts.append(self.to_bytes(part))
            qname_parts.append(self.bchr(0))
            qname = self.bjoin(qname_parts)
            question = qname + struct.pack(">HH", 1, 1)
            return header + question, tid

        def parse_response(data, tid):
            if len(data) < 12:
                return None
            if struct.unpack(">H", data[:2])[0] != tid:
                return None
            answers = struct.unpack(">H", data[6:8])[0]
            i = 12
            while i < len(data) and (ord(data[i]) if self.PY2 else data[i]) != 0:
                i += 1
            i += 5
            for _ in range(answers):
                if i + 10 >= len(data):
                    return None
                i += 2
                type_, class_, ttl, rdlen = struct.unpack(">HHIH", data[i:i+10])
                i += 10
                if type_ == 1 and class_ == 1 and rdlen == 4:
                    ip = ".".join(str(ord(c)) if self.PY2 else str(c) for c in data[i:i+4])
                    self.cache[domain] = ip
                    return ip
                i += rdlen
            return None

        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(5)
            query, tid = build_query(domain)
            s.sendto(query, (self.dns_server, 53))
            data, _ = s.recvfrom(512)
            s.close()
            return parse_response(data, tid)
        except socket.timeout:
            logger.warning("Timeout ao consultar DNS para %s", domain)
            return None
        except Exception as e:
            logger.warning("Erro ao resolver %s: %s", domain, e)
            return None

    def _resolver(self, host, port, *args, **kwargs):
        try:
            if self.is_valid_ipv4(host):
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (host, port))]
            ip = self.resolve(host)
            if ip:
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, port))]
        except Exception as e:
            logger.warning("Erro no resolver para %s: %s", host, e)
        return self.original_getaddrinfo(host, port, *args, **kwargs)
