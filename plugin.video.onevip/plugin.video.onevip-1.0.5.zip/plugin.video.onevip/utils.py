# -*- coding: utf-8 -*-
import json
import os
from kodi_six import xbmc, xbmcgui
from variables import FAVORITES_FILE

def load_favorites():
    """Carrega os favoritos do arquivo favorites.json."""
    if os.path.exists(FAVORITES_FILE):
        try:
            with open(FAVORITES_FILE, 'r') as f:
                return json.load(f)
        except Exception as e:
            xbmc.log(f"Erro ao carregar favoritos: {str(e)}", xbmc.LOGERROR)
            return {"live": [], "movies": [], "series": []}
    return {"live": [], "movies": [], "series": []}

def save_favorites(favorites):
    """Salva os favoritos no arquivo favorites.json."""
    try:
        with open(FAVORITES_FILE, 'w') as f:
            json.dump(favorites, f, indent=2)
    except Exception as e:
        xbmc.log(f"Erro ao salvar favoritos: {str(e)}", xbmc.LOGERROR)

def add_favorite(item, content_type):
    """Adiciona um item aos favoritos."""
    favorites = load_favorites()
    if content_type not in favorites:
        favorites[content_type] = []
    for fav in favorites[content_type]:
        if fav.get("stream_id" if content_type != "series" else "series_id") == item.get("stream_id" if content_type != "series" else "series_id"):
            xbmcgui.Dialog().ok("Aviso", "Este item já está nos favoritos.")
            return
    favorites[content_type].append(item)
    save_favorites(favorites)
    xbmcgui.Dialog().ok("Sucesso", f"{item.get('name')} adicionado aos favoritos.")

def remove_favorite(item, content_type):
    """Remove um item dos favoritos."""
    favorites = load_favorites()
    if content_type in favorites:
        favorites[content_type] = [
            fav for fav in favorites[content_type]
            if fav.get("stream_id" if content_type != "series" else "series_id") != item.get("stream_id" if content_type != "series" else "series_id")
        ]
        save_favorites(favorites)
        xbmcgui.Dialog().ok("Sucesso", f"{item.get('name')} removido dos favoritos.")