# -*- coding: utf-8 -*-
from variables import ADDON_PATH, BASE_URL, HEADERS, FAVORITES_FILE, build_api_url, encode_path_part
import os
from kodi_six import xbmc, xbmcaddon, xbmcgui, xbmcvfs, xbmcplugin
import pyxbmct
from customdns import DNSOverride
import requests
from utils import load_favorites, add_favorite, remove_favorite
from urllib.parse import quote

def get_kversion():
    full_version_info = xbmc.getInfoLabel('System.BuildVersion')
    baseversion = full_version_info.split(".")
    intbase = int(baseversion[0])
    return intbase

def season_sort_key(value):
    text = str(value)
    try:
        return (0, int(text))
    except Exception:
        digits = ''.join(ch for ch in text if ch.isdigit())
        if digits:
            return (1, int(digits))
        return (2, text.lower())

def normalize_seasons(episodes_raw):
    if isinstance(episodes_raw, dict):
        return episodes_raw
    if isinstance(episodes_raw, list):
        grouped = {}
        for episode in episodes_raw:
            season = episode.get('season') or episode.get('season_num') or episode.get('season_number') or 1
            grouped.setdefault(str(season), []).append(episode)
        return grouped
    return {}

class SeriesWindow(pyxbmct.AddonFullWindow):
    def __init__(self, title):
        super(SeriesWindow, self).__init__(title)
        self.seasons = []
        self.setGeometry(1280, 720, 100, 50)
        self.set_background(os.path.join(ADDON_PATH, 'resources', 'media', 'background.jpg'))
        xbmc.log(f"Inicializando SeriesWindow com título: {title}", xbmc.LOGDEBUG)

    def configure(self, series_id, username, password):
        """Configura os parâmetros adicionais após a inicialização."""
        self.series_id = series_id
        self.username = username
        self.password = password
        xbmc.log(f"Configurando SeriesWindow: series_id={self.series_id}", xbmc.LOGDEBUG)
        self.create_controls()
        self.load_seasons()
        self.setFocus(self.list_control)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def set_background(self, image):
        self.bg = xbmcgui.ControlImage(0, 0, 1280, 720, image)
        self.addControl(self.bg)

    def create_controls(self):
        self.list_control = pyxbmct.List()
        self.placeControl(self.list_control, 10, 10, 80, 30)
        self.connect(self.list_control, self.open_season)

    def load_seasons(self):
        url = build_api_url(self.username, self.password, "get_series_info", series_id=self.series_id)
        xbmc.log(f"Carregando temporadas: {url}", xbmc.LOGDEBUG)
        try:
            DNSOverride()
            response = requests.get(url, headers=HEADERS, timeout=10)
            xbmc.log(f"Resposta da API: Status {response.status_code}", xbmc.LOGDEBUG)
            if response.status_code == 200:
                data = response.json()
                self.seasons = normalize_seasons(data.get('episodes', {}))
                xbmc.log(f"Temporadas recebidas: {len(self.seasons)}", xbmc.LOGDEBUG)
                if not self.seasons:
                    xbmcgui.Dialog().ok("Erro", "Nenhuma temporada encontrada.")
                    self.close()
                    return
                for season_num in sorted(self.seasons.keys(), key=season_sort_key):
                    label = f"Temporada {season_num}"
                    self.list_control.addItem(label)
            else:
                xbmcgui.Dialog().ok("Erro", f"Falha ao carregar temporadas: Status {response.status_code}")
                self.close()
        except Exception as e:
            xbmcgui.Dialog().ok("Erro", f"Erro ao carregar temporadas: {str(e)}")
            xbmc.log(f"Erro ao carregar temporadas: {str(e)}", xbmc.LOGERROR)
            self.close()

    def open_season(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.seasons):
            xbmc.log("Índice de temporada inválido", xbmc.LOGERROR)
            return
        season_num = sorted(self.seasons.keys(), key=season_sort_key)[index]
        season_data = self.seasons[season_num]
        episodes_window = EpisodesWindow(f"Temporada {season_num}")
        episodes_window.configure(season_data, self.username, self.password)
        episodes_window.doModal()
        del episodes_window

    def close(self):
        super().close()

class EpisodesWindow(pyxbmct.AddonFullWindow):
    def __init__(self, title):
        super(EpisodesWindow, self).__init__(title)
        self.episodes = []
        self.setGeometry(1280, 720, 100, 50)
        self.set_background(os.path.join(ADDON_PATH, 'resources', 'media', 'background.jpg'))
        self.sinopse_text = None
        self.logo_image = None
        xbmc.log(f"Inicializando EpisodesWindow com título: {title}", xbmc.LOGDEBUG)

    def configure(self, episodes, username, password):
        """Configura os parâmetros adicionais após a inicialização."""
        self.episodes = episodes
        self.username = username
        self.password = password
        xbmc.log(f"Configurando EpisodesWindow: {len(episodes)} episódios", xbmc.LOGDEBUG)
        self.create_controls()
        self.load_episodes()
        self.setFocus(self.list_control)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        # Exibir sinopse e logo do primeiro item
        if self.episodes:
            self.on_list_selection_changed(index=0)

    def set_background(self, image):
        self.bg = xbmcgui.ControlImage(0, 0, 1280, 720, image)
        self.addControl(self.bg)

    def create_controls(self):
        self.list_control = pyxbmct.List()
        self.placeControl(self.list_control, 10, 10, 70, 30)
        self.connect(self.list_control, self.play_episode)

        # TextBox para a sinopse
        self.sinopse_text = pyxbmct.TextBox()
        self.placeControl(self.sinopse_text, 82, 10, 18, 40)
        self.sinopse_text.setText("Selecione um episódio para ver a sinopse.")

        # Controle Image para a logo
        placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')
        self.logo_image = pyxbmct.Image(placeholder_image)
        self.placeControl(self.logo_image, 25, 42, 30, 6)

        # Conectar eventos de navegação
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
             pyxbmct.ACTION_MOVE_UP,
             pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
             pyxbmct.ACTION_MOUSE_WHEEL_UP,
             pyxbmct.ACTION_MOUSE_MOVE],
            self.on_list_selection_changed)

    def on_list_selection_changed(self, index=None):
        # Usar o índice fornecido (para inicialização) ou obter da seleção atual
        if index is None:
            index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.episodes):
            self.sinopse_text.setText("Selecione um episódio para ver a sinopse.")
            placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')
            self.logo_image.setImage(placeholder_image)
            xbmc.log("Nenhum episódio selecionado para sinopse ou logo", xbmc.LOGDEBUG)
            return

        episode = self.episodes[index]
        # Atualizar sinopse
        try:
            sinopse_text = episode.get('info', {}).get('plot', 'Sinopse não disponível.')
        except:
            sinopse_text = 'Sinopse não disponível.'
        self.sinopse_text.setText(sinopse_text)
        xbmc.log(f"Sinopse carregada: {sinopse_text[:100]}...", xbmc.LOGDEBUG)

        # Atualizar logo
        placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')
        logo_url = episode.get('info', {}).get('movie_image', episode.get('info', {}).get('cover_big', placeholder_image))
        if logo_url and str(logo_url).startswith(('http://', 'https://')):
            self.logo_image.setImage(logo_url)
            xbmc.log(f"Logo atualizada: {logo_url}", xbmc.LOGDEBUG)
        else:
            label = f"Episódio {episode.get('episode_num')} - {episode.get('title', 'Sem Título')}"
            self.logo_image.setImage(placeholder_image)
            xbmc.log(f"Nenhuma logo disponível para item: {label}", xbmc.LOGDEBUG)

    def load_episodes(self):
        if not self.episodes:
            xbmcgui.Dialog().ok("Erro", "Nenhum episódio encontrado.")
            self.close()
            return
        for episode in self.episodes:
            label = f"Episódio {episode.get('episode_num')} - {episode.get('title', 'Sem Título')}"
            self.list_control.addItem(label)
            xbmc.log(f"DADOS DO EPISÓDIO: {episode}", xbmc.LOGDEBUG)
        xbmc.log(f"Episódios carregados: {len(self.episodes)}", xbmc.LOGDEBUG)

    def play_episode(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.episodes):
            xbmc.log("Índice de episódio inválido", xbmc.LOGERROR)
            return
        episode = self.episodes[index]
        stream_id = episode.get('id') or episode.get('stream_id')
        url = f"{BASE_URL}/series/{encode_path_part(self.username)}/{encode_path_part(self.password)}/{encode_path_part(stream_id)}.mp4"
        xbmc.log(f"Reproduzindo episódio: {url}", xbmc.LOGDEBUG)
        label = f"Episódio {episode.get('episode_num')} - {episode.get('title', 'Sem Título')}"
        list_item = xbmcgui.ListItem(label)
        try:
            description = episode.get('info', {}).get('plot', 'Sinopse não disponível.')
        except:
            description = 'Sinopse não disponível.'
        if get_kversion() > 19:
            info = list_item.getVideoInfoTag()
            info.setTitle(label)
            info.setPlot(description)
        else:
            list_item.setInfo(type='Video', infoLabels={'Title': label, 'Plot': description})
        placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')
        logo = episode.get('info', {}).get('movie_image', episode.get('info', {}).get('cover_big', placeholder_image))
        if logo and str(logo).startswith(('http://', 'https://')):
            iconimage = logo
        else:
            iconimage = placeholder_image
            xbmc.log(f"Nenhuma logo disponível para item: {label}", xbmc.LOGDEBUG)
        list_item.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
        list_item.setPath(url)
        import mp4retry
        url = f'http://{mp4retry.HOST_NAME}:{mp4retry.PORT_NUMBER}/?url={quote(url)}'
        mp4retry.XtreamProxy().start()
        xbmc.Player().play(url, list_item)

    def close(self):
        super().close()