# -*- coding: utf-8 -*-

def painel_interface():
    from painel import MainPanel
    painel_interface = MainPanel()
    painel_interface.doModal()
    del painel_interface

def login_interface():
    from login import LoginWindow
    loginwindow_interface = LoginWindow()
    loginwindow_interface.doModal()
    del loginwindow_interface