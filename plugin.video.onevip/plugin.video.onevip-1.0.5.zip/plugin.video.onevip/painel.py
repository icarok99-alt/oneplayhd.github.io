# -*- coding: utf-8 -*-
import os
import json
import requests
import pyxbmct
import sys
from datetime import datetime
import base64
import time
from kodi_six import xbmc, xbmcgui
from variables import ADDON_PATH, SESSION_FILE, FAVORITES_FILE, BASE_URL, HEADERS, input_text, build_api_url, encode_path_part
from customdns import DNSOverride
from control import login_interface
from categories import CategoriesWindow
from content import ContentWindow
from series import SeriesWindow
from utils import load_favorites, add_favorite, remove_favorite
from urllib.parse import quote

def get_kversion():
    full_version_info = xbmc.getInfoLabel('System.BuildVersion')
    baseversion = full_version_info.split(".")
    intbase = int(baseversion[0])
    return intbase

class MainPanel(pyxbmct.AddonFullWindow):
    def __init__(self, title="Painel"):
        super(MainPanel, self).__init__(title)
        self.setGeometry(1280, 720, 100, 50)
        self.set_background(os.path.join(ADDON_PATH, 'resources', 'media', 'background.jpg'))
        self.setup_buttons()
        self.set_navigation()
        self.logo_ads()
        self.exibir_vencimento()
        self.setFocus(self.live_tv_btn)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)

    def set_background(self, image):
        self.bg = xbmcgui.ControlImage(0, 0, 1280, 720, image)
        self.addControl(self.bg)

    def logo_ads(self):
        self.ads = pyxbmct.Image('')
        self.placeControl(self.ads, 9, 21, 76, 30)
        self.ads.setImage(os.path.join(ADDON_PATH, 'resources', 'media', 'ads.png'))

    def setup_buttons(self):
        # button_configs = [
        #     ('live_tv_btn', 'live_tv.png', 'live_tv2.png', self.open_live_tv, 8, 2),
        #     ('movies_btn', 'movies.png', 'movies2.png', self.open_movies, 8, 12),
        #     ('series_btn', 'series.png', 'series2.png', self.open_series, 44, 12),
        #     ('fav_btn', 'fav.png', 'fav2.png', self.fav, 44, 2),
        #     ('exit_btn', 'exit.png', 'exit2.png', self.close, 85, 29),  
        #     ('logout_btn', 'logout.png', 'logout2.png', self.logout, 85, 34),  
        #     ('acc_info_btn', 'acc_info.png', 'acc_info2.png', self.show_acc_info, 85, 39),  
        #     ('setings_btn', 'setings.png', 'setings2.png', self.setings, 85, 44)
        # ]
        # retirado botao settings
        button_configs = [
            ('live_tv_btn', 'live_tv.png', 'live_tv2.png', self.open_live_tv, 8, 2),
            ('movies_btn', 'movies.png', 'movies2.png', self.open_movies, 8, 12),
            ('series_btn', 'series.png', 'series2.png', self.open_series, 44, 12),
            ('fav_btn', 'fav.png', 'fav2.png', self.fav, 44, 2),
            ('exit_btn', 'exit.png', 'exit2.png', self.close, 85, 32),  
            ('logout_btn', 'logout.png', 'logout2.png', self.logout, 85, 37),  
            ('acc_info_btn', 'acc_info.png', 'acc_info2.png', self.show_acc_info, 85, 42)
        ]        

        for attr_name, image, image2, callback, row, col in button_configs:
            image_path = os.path.join(ADDON_PATH, 'resources', 'media', image)
            image_path2 = os.path.join(ADDON_PATH, 'resources', 'media', image2)
            btn_label = image.replace('.png', '').capitalize()
            if not os.path.exists(image_path):
                xbmc.log(f"Imagem não encontrada: {image_path}, usando texto: {btn_label}", xbmc.LOGWARNING)
                btn = pyxbmct.Button(btn_label)
            else:
                xbmc.log(f"Criando botão com imagem: {image_path}", xbmc.LOGDEBUG)
                btn = pyxbmct.Button("", focusTexture=image_path, noFocusTexture=image_path2)
            self.connect(btn, lambda cb=callback: cb())
            xbmc.log(f"Botão {attr_name} conectado ao callback: {callback.__name__}", xbmc.LOGDEBUG)
            if attr_name in ['exit_btn', 'logout_btn', 'acc_info_btn', 'setings_btn']:
                self.placeControl(btn, row, col, 10, 5)
            else:
                self.placeControl(btn, row, col, 44, 10)
            setattr(self, attr_name, btn)

    def set_navigation(self):
        # retirado botao settings
        self.live_tv_btn.controlRight(self.movies_btn)
        self.live_tv_btn.controlDown(self.fav_btn)
        self.fav_btn.controlUp(self.live_tv_btn)
        self.movies_btn.controlDown(self.series_btn)
        self.series_btn.controlUp(self.movies_btn)
        self.series_btn.controlLeft(self.fav_btn)
        self.fav_btn.controlRight(self.series_btn)
        self.movies_btn.controlLeft(self.live_tv_btn)
        self.fav_btn.controlDown(self.exit_btn)
        self.movies_btn.controlRight(self.exit_btn)
        self.series_btn.controlDown(self.exit_btn)
        self.series_btn.controlRight(self.exit_btn)
        self.exit_btn.controlRight(self.logout_btn)
        self.logout_btn.controlLeft(self.exit_btn)
        self.logout_btn.controlRight(self.acc_info_btn)
        self.acc_info_btn.controlLeft(self.logout_btn)
        #self.acc_info_btn.controlRight(self.setings_btn)
        #self.setings_btn.controlLeft(self.acc_info_btn)
        self.exit_btn.controlUp(self.series_btn)
        self.exit_btn.controlLeft(self.series_btn)

    def open_live_tv(self):
        xbmc.log("Função open_live_tv chamada", xbmc.LOGDEBUG)
        session = self.load_session()
        if session:
            categories_window = CategoriesWindow('Canais Ao Vivo')
            categories_window.configure('get_live_categories', 'get_live_streams', session['username'], session['password'])
            categories_window.doModal()
            del categories_window
        else:
            xbmcgui.Dialog().ok("Erro", "Sessão inválida. Faça login novamente.")

    def open_movies(self):
        xbmc.log("Função open_movies chamada", xbmc.LOGDEBUG)
        session = self.load_session()
        if session:
            categories_window = CategoriesWindow('Filmes')
            categories_window.configure('get_vod_categories', 'get_vod_streams', session['username'], session['password'])
            categories_window.doModal()
            del categories_window
        else:
            xbmcgui.Dialog().ok("Erro", "Sessão inválida. Faça login novamente.")

    def open_series(self):
        xbmc.log("Função open_series chamada", xbmc.LOGDEBUG)
        session = self.load_session()
        if session:
            categories_window = CategoriesWindow('Séries')
            categories_window.configure('get_series_categories', 'get_series', session['username'], session['password'])
            categories_window.doModal()
            del categories_window
        else:
            xbmcgui.Dialog().ok("Erro", "Sessão inválida. Faça login novamente.")

    def fav(self):
        xbmc.log("Função de favoritos chamada", xbmc.LOGDEBUG)
        favorites_window = FavoritesWindow()
        favorites_window.doModal()
        del favorites_window

    def show_acc_info(self):
        xbmc.log("Função show_acc_info chamada", xbmc.LOGDEBUG)
        session_ = self.load_session()
        if session_:
            url = build_api_url(session_['username'], session_['password'])
            try:
                DNSOverride()
                response = requests.get(url, headers=HEADERS, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    auth = data.get('user_info', {}).get('auth', 0)
                    if auth == 1:
                        session = data
                        user_info = session['user_info']
                        exp_date = user_info.get('exp_date', 'N/A')
                        if exp_date != 'N/A' and exp_date is not None:
                            exp_date = datetime.fromtimestamp(int(exp_date)).strftime('%d/%m/%Y %H:%M')
                        elif exp_date is None or exp_date == 'None':
                            exp_date = 'Ilimitado'
                        else:
                            exp_date = 'None'
                        created = user_info.get('created_at', 'N/A')
                        if created != 'N/A' and created is not None:
                            created = datetime.fromtimestamp(int(created)).strftime('%d/%m/%Y %H:%M')
                        info = (f"Usuário: {user_info.get('username', 'N/A')}\n"
                                f"Criado: {created}\n"
                                f"Expira: {exp_date}\n"
                                f"Conexões Permitidas: {user_info.get('max_connections', 'N/A')}\n"
                                f"Conexões Usadas: {user_info.get('active_cons', 'N/A')}\n")
                        xbmcgui.Dialog().ok('Informações da Conta', info)     
                    else:
                        xbmcgui.Dialog().ok('Erro', 'Usuário ou senha incorretos.')
                else:
                    xbmcgui.Dialog().ok('Erro', f'Falha na conexão: Status {response.status_code}')
            except Exception as e:
                xbmcgui.Dialog().ok('Erro', f'Falha na conexão: {str(e)}')        

    def exibir_vencimento(self):
        xbmc.log("Função exibir vencimento", xbmc.LOGDEBUG)
        session_ = self.load_session()
        if session_:
            url = build_api_url(session_['username'], session_['password'])
            try:
                DNSOverride()
                response = requests.get(url, headers=HEADERS, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    auth = data.get('user_info', {}).get('auth', 0)
                    if auth == 1:
                        session = data
                        user_info = session['user_info']
                        exp_date = user_info.get('exp_date', 'N/A')
                        if exp_date != 'N/A' and exp_date is not None:
                            exp_date = datetime.fromtimestamp(int(exp_date)).strftime('%d/%m/%Y %H:%M')
                        elif exp_date is None:
                            exp_date = 'Ilimitado'
                        elif exp_date == 'None':
                            exp_date = 'Ilimitado'
                        else:
                            exp_date = 'None'
                    else:
                        exp_date = 'Erro ao obter data de expiração'
                else:
                    exp_date = 'Erro ao obter data de expiração'
            except Exception as e:
                exp_date = 'Erro ao obter data de expiração'
            if exp_date == 'Ilimitado':  
                self.vencimento_texto = pyxbmct.Label("Acesso: %s"%str(exp_date), textColor="0xFFFFFFFF", font='font50', alignment=pyxbmct.ALIGN_CENTER)
            elif not 'Erro' in exp_date and not 'None' in exp_date:  
                self.vencimento_texto = pyxbmct.Label("Recarregue em: %s"%str(exp_date), textColor="0xFFFFFFFF", font='font50', alignment=pyxbmct.ALIGN_CENTER)
            else:
                # falha
                self.vencimento_texto = pyxbmct.Label("", textColor="0xFFFFFFFF", font='font50', alignment=pyxbmct.ALIGN_CENTER)
            self.placeControl(self.vencimento_texto, 92, -6, 10, 29)

    def setings(self):
        xbmc.log("Função para as configuração", xbmc.LOGDEBUG)

    def logout(self):
        xbmc.log("Função logout chamada", xbmc.LOGDEBUG)
        if os.path.exists(SESSION_FILE):
            os.remove(SESSION_FILE)
        self.close()
        login_interface()

    def load_session(self):
        if os.path.exists(SESSION_FILE):
            try:
                with open(SESSION_FILE) as f:
                    return json.load(f)
            except Exception as e:
                xbmc.log(f"Erro ao carregar sessão: {str(e)}", xbmc.LOGERROR)
                xbmcgui.Dialog().ok("Erro", f"Sessão inválida: {str(e)}")
                os.remove(SESSION_FILE)
        return None

    def close(self):
        xbmc.log("Função close chamada", xbmc.LOGDEBUG)
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin("ActivateWindow(Home)")
        super().close()

class FavoritesWindow(pyxbmct.AddonFullWindow):
    def __init__(self, title="Favoritos"):
        super(FavoritesWindow, self).__init__(title)
        self.setGeometry(1280, 720, 100, 50)
        self.set_background(os.path.join(ADDON_PATH, 'resources', 'media', 'background.jpg'))
        self.favorites = load_favorites()
        self.items = []
        self.logo_image = None  # Controle para a logo
        self.create_controls()
        self.set_navigation()
        self.setFocus(self.list_control)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        # Exibir logo do primeiro item, se houver
        if self.items:
            self.on_list_selection_changed(index=0)

    def set_background(self, image):
        self.bg = xbmcgui.ControlImage(0, 0, 1280, 720, image)
        self.addControl(self.bg)

    def create_controls(self):
        self.list_control = pyxbmct.List()
        self.placeControl(self.list_control, 10, 10, 80, 30)
        self.connect(self.list_control, self.select_favorite)
        
        # Adiciona o botão de remover favoritos ao lado da lista
        self.remove_favorite_button = pyxbmct.Button("Remover dos Favoritos")
        self.placeControl(self.remove_favorite_button, 10, 41, 10, 8)
        self.connect(self.remove_favorite_button, self.remove_from_favorites)
        
        # Adiciona o controle Image para a logo abaixo do botão de remover
        placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')
        self.logo_image = pyxbmct.Image(placeholder_image)
        self.placeControl(self.logo_image, 25, 41, 30, 8)  # Ajustado para abaixo do botão
        
        # Conectar eventos de navegação para atualizar a logo
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
             pyxbmct.ACTION_MOVE_UP,
             pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
             pyxbmct.ACTION_MOUSE_WHEEL_UP,
             pyxbmct.ACTION_MOUSE_MOVE],
            self.on_list_selection_changed)
        
        # Carrega os itens na lista
        self.update_list()

    def set_navigation(self):
        self.list_control.controlRight(self.remove_favorite_button)
        self.remove_favorite_button.controlLeft(self.list_control)

    def update_list(self):
        self.favorites = load_favorites()
        self.items = []
        self.list_control.reset()
        for content_type, items in self.favorites.items():
            for item in items:
                self.items.append((content_type, item))
                self.list_control.addItem(item.get("name", "Sem Nome"))
        xbmc.log(f"Lista de favoritos atualizada: {len(self.items)} itens", xbmc.LOGDEBUG)

    def on_list_selection_changed(self, index=None):
        # Usar o índice fornecido (para inicialização) ou obter da seleção atual
        if index is None:
            index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.items):
            placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')
            self.logo_image.setImage(placeholder_image)
            xbmc.log("Nenhum item selecionado para logo", xbmc.LOGDEBUG)
            return

        content_type, item = self.items[index]
        # Obter a URL da logo (stream_icon para live/movies, cover para series)
        logo_url = item.get('stream_icon' if content_type != 'series' else 'cover', '')
        placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')
        
        if logo_url and str(logo_url).startswith(('http://', 'https://')):
            self.logo_image.setImage(logo_url)
            xbmc.log(f"Logo atualizada: {logo_url}", xbmc.LOGDEBUG)
        else:
            self.logo_image.setImage(placeholder_image)
            xbmc.log(f"Nenhuma logo disponível para item: {item.get('name')}", xbmc.LOGDEBUG)

    def remove_from_favorites(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.items):
            xbmc.log("Nenhum item selecionado para remover dos favoritos", xbmc.LOGERROR)
            return
        content_type, item = self.items[index]
        xbmc.log(f"Removendo favorito: {item.get('name')} (type: {content_type})", xbmc.LOGDEBUG)
        remove_favorite(item, content_type)
        self.update_list()
        self.setFocus(self.list_control)
        # Atualizar a logo após remover
        if self.items:
            self.on_list_selection_changed(index=0)
        else:
            placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')
            self.logo_image.setImage(placeholder_image)

    def select_favorite(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.items):
            xbmc.log("Índice de favorito inválido", xbmc.LOGERROR)
            return
        content_type, item = self.items[index]
        session = self.load_session()
        if not session:
            xbmcgui.Dialog().ok("Erro", "Sessão inválida. Faça login novamente.")
            return
        
        username = session['username']
        password = session['password']
        
        if content_type == "live":
            stream_id = item.get("stream_id")
            url = f"{BASE_URL}/live/{encode_path_part(username)}/{encode_path_part(password)}/{encode_path_part(stream_id)}.m3u8"
            # m3u8 to ts
            url = url.replace('live/', '').replace('.m3u8', '')
            xbmc.log(f"Reproduzindo canal favorito: {url}", xbmc.LOGDEBUG)
            list_item = xbmcgui.ListItem(item.get("name", "Canal"))
            if get_kversion() > 19:
                info = list_item.getVideoInfoTag()
                info.setTitle(item.get('name', 'Stream'))
                info.setPlot(item.get('plot', ''))
            else:
                list_item.setInfo(type='Video', infoLabels={'Title': item.get('name', 'Stream'), 'Plot': item.get('plot', '')})
            list_item.setArt({"icon": "DefaultVideo.png", "thumb": item.get('stream_icon', '')})          
            list_item.setPath(url)
            # import hlsretry
            # url = f'http://{hlsretry.HOST_NAME}:{hlsretry.PORT_NUMBER}/?url={quote(url)}'
            # hlsretry.XtreamProxy().start()
            import tsdownloader
            url = 'http://%s:%s/?url=%s'%(str(tsdownloader.HOST_NAME),str(tsdownloader.PORT_NUMBER),quote(url))
            tsdownloader.XtreamProxyTS().start()              
            xbmc.Player().play(url, list_item)
        
        elif content_type == "movies":
            stream_id = item.get("stream_id")
            url = f"{BASE_URL}/movie/{encode_path_part(username)}/{encode_path_part(password)}/{encode_path_part(stream_id)}.mp4"
            xbmc.log(f"Reproduzindo filme favorito: {url}", xbmc.LOGDEBUG)
            list_item = xbmcgui.ListItem(item.get("name", "Filme"))
            if get_kversion() > 19:
                info = list_item.getVideoInfoTag()
                info.setTitle(item.get('name', 'Stream'))
                info.setPlot(item.get('plot', ''))
            else:
                list_item.setInfo(type='Video', infoLabels={'Title': item.get('name', 'Stream'), 'Plot': item.get('plot', '')})
            list_item.setArt({"icon": "DefaultVideo.png", "thumb": item.get('stream_icon', '')})          
            list_item.setPath(url)
            import mp4retry
            url = f'http://{mp4retry.HOST_NAME}:{mp4retry.PORT_NUMBER}/?url={quote(url)}'
            mp4retry.XtreamProxy().start()
            xbmc.Player().play(url, list_item)
        
        elif content_type == "series":
            series_id = item.get("series_id")
            xbmc.log(f"Abrindo série favorita: {item.get('name')}", xbmc.LOGDEBUG)
            series_window = SeriesWindow(item.get("name", "Série"))
            series_window.configure(series_id, username, password)
            series_window.doModal()
            del series_window

    def load_session(self):
        if os.path.exists(SESSION_FILE):
            try:
                with open(SESSION_FILE) as f:
                    return json.load(f)
            except Exception as e:
                xbmc.log(f"Erro ao carregar sessão: {str(e)}", xbmc.LOGERROR)
                xbmcgui.Dialog().ok("Erro", f"Sessão inválida: {str(e)}")
                os.remove(SESSION_FILE)
        return None

    def close(self):
        super().close()