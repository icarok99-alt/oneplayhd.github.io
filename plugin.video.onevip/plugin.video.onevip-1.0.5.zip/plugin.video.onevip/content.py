# -*- coding: utf-8 -*-
from variables import ADDON_PATH, BASE_URL, HEADERS, FAVORITES_FILE, input_text, build_api_url, encode_path_part
import os
from kodi_six import xbmc, xbmcaddon, xbmcgui, xbmcvfs, xbmcplugin
import pyxbmct
from customdns import DNSOverride
import requests
import time
import json
import base64
from series import SeriesWindow
from urllib.parse import quote, quote_plus, unquote_plus, unquote, urlparse
from utils import load_favorites, add_favorite, remove_favorite

def get_kversion():
    full_version_info = xbmc.getInfoLabel('System.BuildVersion')
    baseversion = full_version_info.split(".")
    intbase = int(baseversion[0])
    return intbase

def safe_b64_decode(value):
    if not value:
        return ''
    if not isinstance(value, (bytes, str)):
        return str(value)
    try:
        raw = value if isinstance(value, bytes) else value.encode('utf-8')
        decoded = base64.b64decode(raw, validate=False)
        text = decoded.decode('utf-8', errors='ignore').strip()
        return text or (value.decode('utf-8', errors='ignore') if isinstance(value, bytes) else value)
    except Exception:
        return value.decode('utf-8', errors='ignore') if isinstance(value, bytes) else value

class ContentWindow(pyxbmct.AddonFullWindow):
    def __init__(self, title):
        super(ContentWindow, self).__init__(title)
        self.items = []
        self.original_items = []  # Armazena a lista completa para restaurar após pesquisa
        self.setGeometry(1280, 720, 100, 50)
        self.set_background(os.path.join(ADDON_PATH, 'resources', 'media', 'background.jpg'))
        self.last_epg_update = 0
        self.last_poster_update = 0
        self.epg_text = None
        self.poster_image = None
        self.sinopse_text = None
        self.iconimage = ''
        xbmc.log(f"Inicializando ContentWindow com título: {title}", xbmc.LOGDEBUG)

    def configure(self, stream_action, category_id, username, password):
        """Configura os parâmetros adicionais após a inicialização."""
        self.stream_action = stream_action
        self.category_id = category_id
        self.username = username
        self.password = password
        xbmc.log(f"Configurando ContentWindow: action={stream_action}, category_id={category_id}", xbmc.LOGDEBUG)
        self.create_controls()
        self.load_content()
        self.setFocus(self.list_control)
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.set_navigation()

    def set_background(self, image):
        self.bg = xbmcgui.ControlImage(0, 0, 1280, 720, image)
        self.addControl(self.bg)

    def create_controls(self):
        # Botão de pesquisa à esquerda da lista
        self.search_button = pyxbmct.Button("Pesquisar")
        self.placeControl(self.search_button, 10, 1, 10, 8)
        self.connect(self.search_button, self.search_content)

        # Lista de conteúdos
        self.list_control = pyxbmct.List()
        self.placeControl(self.list_control, 10, 10, 70, 30)
        self.connect(self.list_control, self.select_item)

        # Botão de favoritos à direita da lista
        self.favorite_button = pyxbmct.Button("Adicionar aos Favoritos")
        self.placeControl(self.favorite_button, 10, 41, 10, 8)
        self.connect(self.favorite_button, self.toggle_favorite)

        # Adicionar um TextBox para a sinopse
        self.sinopse_text = pyxbmct.TextBox()
        self.placeControl(self.sinopse_text, 82, 10, 18, 30)
        self.sinopse_text.setText("Selecione um item para ver a sinopse.")

        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
             pyxbmct.ACTION_MOVE_UP,
             pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
             pyxbmct.ACTION_MOUSE_WHEEL_UP,
             pyxbmct.ACTION_MOUSE_MOVE],
            self.on_list_selection_changed)
        xbmc.log("Eventos de navegação registrados para EPG, capas e sinopse", xbmc.LOGDEBUG)

        if self.stream_action == 'get_live_streams':
            self.epg_text = pyxbmct.Label("")
            self.placeControl(self.epg_text, 90, 10, 20, 28)
            self.epg_text.setLabel("Selecione um canal para ver o EPG.")

        placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')
        self.poster_image = pyxbmct.Image(placeholder_image)
        self.placeControl(self.poster_image, 25, 42, 30, 6)

    def set_navigation(self):
        self.list_control.controlLeft(self.search_button)
        self.list_control.controlRight(self.favorite_button)
        self.search_button.controlRight(self.list_control)
        self.favorite_button.controlLeft(self.list_control)

    def load_content(self):
        url = build_api_url(self.username, self.password, self.stream_action, category_id=self.category_id)
        xbmc.log(f"Carregando conteúdo: {url}", xbmc.LOGDEBUG)
        try:
            DNSOverride()
            response = requests.get(url, headers=HEADERS, timeout=10)
            xbmc.log(f"Resposta da API: Status {response.status_code}, Conteúdo: {response.text[:200]}...", xbmc.LOGDEBUG)
            if response.status_code == 200:
                self.items = response.json()
                self.original_items = self.items.copy()  # Armazena a lista completa
                xbmc.log(f"Itens recebidos: {len(self.items)}", xbmc.LOGDEBUG)
                if not self.items:
                    xbmcgui.Dialog().ok("Erro", "Nenhum item encontrado nesta categoria.")
                    self.close()
                    return
                for item in self.items:
                    self.list_control.addItem(item.get('name', 'Sem Nome'))
                if self.items:
                    self.on_list_selection_changed()
            else:
                xbmcgui.Dialog().ok("Erro", f"Falha ao carregar conteúdo: Status {response.status_code}")
                self.close()
        except Exception as e:
            xbmcgui.Dialog().ok("Erro", f"Erro ao carregar conteúdo: {str(e)}")
            xbmc.log(f"Erro ao carregar conteúdo: {str(e)}", xbmc.LOGERROR)
            self.close()

    def search_content(self):
        """Filtra a lista de conteúdos com base na entrada do usuário."""
        search_string = input_text("Digite o nome para pesquisar")
        if search_string is False:  # Usuário cancelou
            return
        self.list_control.reset()
        if not search_string:  # Pesquisa vazia restaura a lista original
            self.items = self.original_items.copy()
            for item in self.items:
                self.list_control.addItem(item.get('name', 'Sem Nome'))
            xbmc.log("Pesquisa vazia, lista original restaurada", xbmc.LOGDEBUG)
        else:
            search_string = search_string.lower()
            self.items = [item for item in self.original_items if search_string in item.get('name', '').lower()]
            for item in self.items:
                self.list_control.addItem(item.get('name', 'Sem Nome'))
            xbmc.log(f"Pesquisa por '{search_string}': {len(self.items)} itens encontrados", xbmc.LOGDEBUG)
        if not self.items:
            xbmcgui.Dialog().ok("Pesquisa", "Nenhum item encontrado.")
            self.items = self.original_items.copy()
            for item in self.items:
                self.list_control.addItem(item.get('name', 'Sem Nome'))
        self.setFocus(self.list_control)
        self.on_list_selection_changed()

    def on_list_selection_changed(self):
        current_time = time.time()
        if self.stream_action == 'get_live_streams':
            if current_time - self.last_epg_update < 1.0:
                xbmc.log("Ignorando atualização de EPG (debounce)", xbmc.LOGDEBUG)
            else:
                self.last_epg_update = current_time
                xbmc.log(f"Evento de navegação detectado: Posição {self.list_control.getSelectedPosition()}", xbmc.LOGDEBUG)
                self.update_epg()
        if current_time - self.last_poster_update < 0.5:
            xbmc.log("Ignorando atualização de capa (debounce)", xbmc.LOGDEBUG)
        else:
            self.last_poster_update = current_time
            self.update_poster()
        self.update_sinopse()
        self.update_favorite_button()

    def update_favorite_button(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.items):
            self.favorite_button.setLabel("Adicionar aos Favoritos")
            return
        item = self.items[index]
        content_type = {"get_live_streams": "live", "get_vod_streams": "movies", "get_series": "series"}.get(self.stream_action)
        favorite_item = {
            "stream_id" if content_type != "series" else "series_id": item.get("stream_id" if content_type != "series" else "series_id")
        }
        favorites = load_favorites()
        is_favorite = any(
            fav.get("stream_id" if content_type != "series" else "series_id") == favorite_item.get("stream_id" if content_type != "series" else "series_id")
            for fav in favorites.get(content_type, [])
        )
        self.favorite_button.setLabel("Remover dos Favoritos" if is_favorite else "Adicionar aos Favoritos")
        xbmc.log(f"Botão de favoritos atualizado para item: {item.get('name')} (is_favorite: {is_favorite})", xbmc.LOGDEBUG)

    def update_poster(self):
        if not hasattr(self, 'poster_image'):
            xbmc.log("Controle de capa não inicializado", xbmc.LOGERROR)
            return

        index = self.list_control.getSelectedPosition()
        placeholder_image = os.path.join(ADDON_PATH, 'resources', 'media', 'placeholder.png')

        if index < 0 or index >= len(self.items):
            self.poster_image.setImage(placeholder_image)
            self.iconimage = placeholder_image
            xbmc.log("Nenhum item selecionado para capa", xbmc.LOGDEBUG)
            return

        item = self.items[index]
        poster_url = item.get('stream_icon' if self.stream_action in ('get_live_streams', 'get_vod_streams') else 'cover', '')
        if poster_url and str(poster_url).startswith(('http://', 'https://')):
            self.poster_image.setImage(poster_url)
            self.iconimage = poster_url
            xbmc.log(f"Capa atualizada: {poster_url}", xbmc.LOGDEBUG)
        else:
            self.poster_image.setImage(placeholder_image)
            self.iconimage = placeholder_image
            xbmc.log(f"Nenhuma capa disponível para item: {item.get('name')}", xbmc.LOGDEBUG)

    def update_epg(self):
        if self.stream_action != 'get_live_streams':
            xbmc.log("EPG não atualizado: stream_action não é get_live_streams", xbmc.LOGDEBUG)
            return
        
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.items):
            try:
                self.epg_text.setLabel("Selecione um canal para ver o EPG.")
                xbmc.log("Nenhum canal selecionado para EPG", xbmc.LOGDEBUG)
            except Exception as e:
                xbmc.log(f"Erro ao definir texto de EPG (nenhum canal selecionado): {str(e)}", xbmc.LOGERROR)
            return
        
        item = self.items[index]
        stream_id = item.get('stream_id')
        if not stream_id:
            try:
                self.epg_text.setLabel("EPG não disponível para este canal.")
                xbmc.log(f"Stream ID não encontrado para canal: {item.get('name')}", xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f"Erro ao definir texto de EPG (sem stream_id): {str(e)}", xbmc.LOGERROR)
            return

        url = build_api_url(self.username, self.password, "get_short_epg", stream_id=stream_id, limit=3)
        xbmc.log(f"Carregando Short EPG: {url}", xbmc.LOGDEBUG)
        try:
            DNSOverride()
            response = requests.get(url, headers=HEADERS, timeout=5)
            xbmc.log(f"Resposta da API EPG: Status {response.status_code}, Conteúdo: {response.text[:200]}...", xbmc.LOGDEBUG)
            if response.status_code == 200:
                data = response.json()
                xbmc.log(f"Dados brutos do EPG: {json.dumps(data, indent=2)[:500]}...", xbmc.LOGDEBUG)
                epg_data = data.get('epg_listings', [])
                xbmc.log(f"EPG recebido: {len(epg_data)} programas", xbmc.LOGDEBUG)
                if not epg_data:
                    try:
                        self.epg_text.setLabel("Nenhum EPG disponível para este canal.")
                        xbmc.log("Nenhum dado de EPG recebido", xbmc.LOGDEBUG)
                    except Exception as e:
                        xbmc.log(f"Erro ao definir texto de EPG (sem dados): {str(e)}", xbmc.LOGERROR)
                    return
                
                epgs = data.get('epg_listings', [])
                text_epg = ''
                if epgs:
                    for i in epgs:
                        hora_inicio = i.get('start', '')
                        if hora_inicio:
                            hora_inicio = hora_inicio.split(' ')[1]
                            try:
                                if hora_inicio.count(':') > 1:
                                    hora_inicio = hora_inicio[:-3]
                            except:
                                pass
                        else:
                            hora_inicio = ''
                        hora_fim = i.get('stop', '')
                        if hora_fim:
                            hora_fim = hora_fim.split(' ')[1]
                            try:
                                if hora_fim.count(':') > 1:
                                    hora_fim = hora_fim[:-3]
                            except:
                                pass                        
                        else:
                            hora_fim = ''
                        if hora_inicio and hora_fim: 
                            tempo = str(hora_inicio) + ' - ' + str(hora_fim)
                        else:
                            tempo = ''
                        title = i.get('title', '')
                        if title:
                            title = safe_b64_decode(title)
                        else:
                            title = ''
                        if title and tempo:
                            text_epg += str(tempo) + ' => ' + str(title) + '\n'
                    self.epg_text.setLabel(text_epg)
                else:
                    self.epg_text.setLabel('Sem EPG disponivel')
            else:
                self.epg_text.setLabel(f'Erro ao acessar EPG codigo: {response.status_code}')

        except:
            self.epg_text.setLabel(f'Erro ao carregar epg')

    def update_sinopse(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.items):
            self.sinopse_text.setText("Selecione um item para ver a sinopse.")
            xbmc.log("Nenhum item selecionado para sinopse", xbmc.LOGDEBUG)
            return

        item = self.items[index]
        stream_id = item.get('stream_id')
        if self.stream_action == 'get_series':
            sinopse = item.get('plot', item.get('series_plot', item.get('overview', item.get('description', ''))))
            self.sinopse_text.setText(sinopse or '')
            xbmc.log(f"Sinopse de série carregada para item: {item.get('name')}", xbmc.LOGDEBUG)
            return

        if not stream_id:
            self.sinopse_text.setText("Sinopse não disponível.")
            xbmc.log(f"Stream ID não encontrado para item: {item.get('name')}", xbmc.LOGWARNING)
            return

        if self.stream_action == 'get_vod_streams':
            url = build_api_url(self.username, self.password, "get_vod_info", vod_id=stream_id)
            xbmc.log(f"Carregando sinopse: {url}", xbmc.LOGDEBUG)
            try:
                DNSOverride()
                response = requests.get(url, headers=HEADERS, timeout=5)
                xbmc.log(f"Resposta da API sinopse: Status {response.status_code}", xbmc.LOGDEBUG)
                if response.status_code == 200:
                    data = response.json()
                    info = data.get('info', {})
                    sinopse = info.get('plot', info.get('description', 'Sinopse não disponível.'))
                    self.sinopse_text.setText(sinopse)
                    xbmc.log(f"Sinopse carregada: {sinopse[:100]}...", xbmc.LOGDEBUG)
                else:
                    self.sinopse_text.setText("Erro ao carregar sinopse.")
                    xbmc.log(f"Falha ao carregar sinopse: Status {response.status_code}", xbmc.LOGWARNING)
            except Exception as e:
                self.sinopse_text.setText("Erro ao carregar sinopse.")
                xbmc.log(f"Erro ao carregar sinopse: {str(e)}", xbmc.LOGERROR)
        else:
            #self.sinopse_text.setText("Sinopse não disponível para este tipo de conteúdo.")
            self.sinopse_text.setText("")
            xbmc.log(f"Sinopse não suportada para stream_action: {self.stream_action}", xbmc.LOGDEBUG)

    def select_item(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.items):
            xbmc.log("Índice de item inválido", xbmc.LOGERROR)
            return
        item = self.items[index]
        xbmc.log(f"Item selecionado para reprodução: {item.get('name')}", xbmc.LOGDEBUG)
        
        if self.stream_action == 'get_series':
            series_id = item.get('series_id')
            series_window = SeriesWindow(item.get('name', 'Série'))
            series_window.configure(series_id, self.username, self.password)
            series_window.doModal()
            del series_window
        else:
            self.play_stream(item)

    def toggle_favorite(self):
        index = self.list_control.getSelectedPosition()
        if index < 0 or index >= len(self.items):
            xbmc.log("Nenhum item selecionado para favoritos", xbmc.LOGERROR)
            return
        item = self.items[index]
        content_type = {"get_live_streams": "live", "get_vod_streams": "movies", "get_series": "series"}.get(self.stream_action)
        favorite_item = {
            "name": item.get("name", "Sem Nome"),
            "stream_id" if content_type != "series" else "series_id": item.get("stream_id" if content_type != "series" else "series_id"),
            "category_id": self.category_id,
            "stream_icon" if content_type != "series" else "cover": item.get("stream_icon" if content_type != "series" else "cover", ""),
            "plot": item.get("plot", item.get('info', {}).get('plot', 'Sinopse não disponível.')) if content_type != "live" else ""
        }
        
        xbmc.log(f"Tentando adicionar/remover favorito: {item.get('name')} (index: {index}, type: {content_type})", xbmc.LOGDEBUG)
        
        favorites = load_favorites()
        is_favorite = any(
            fav.get("stream_id" if content_type != "series" else "series_id") == favorite_item.get("stream_id" if content_type != "series" else "series_id")
            for fav in favorites.get(content_type, [])
        )
        
        if is_favorite:
            remove_favorite(favorite_item, content_type)
            self.favorite_button.setLabel("Adicionar aos Favoritos")
            xbmc.log(f"Item removido dos favoritos: {item.get('name')}", xbmc.LOGDEBUG)
        else:
            add_favorite(favorite_item, content_type)
            self.favorite_button.setLabel("Remover dos Favoritos")
            xbmc.log(f"Item adicionado aos favoritos: {item.get('name')}", xbmc.LOGDEBUG)
        
        self.setFocus(self.list_control)

    def play_stream(self, item):
        stream_id = item.get('stream_id')
        extension = '.m3u8' if self.stream_action == 'get_live_streams' else '.mp4'
        stream_base = 'live' if self.stream_action == 'get_live_streams' else 'movie'
        url = f"{BASE_URL}/{stream_base}/{encode_path_part(self.username)}/{encode_path_part(self.password)}/{encode_path_part(stream_id)}{extension}"
        if '.m3u8' in url:
            mode = 'hls'
            url = url.replace('live/', '').replace('.m3u8', '')
            #import hlsretry
            #url = 'http://%s:%s/?url=%s'%(str(hlsretry.HOST_NAME),str(hlsretry.PORT_NUMBER),quote(url))
            #hlsretry.XtreamProxy().start()
            import tsdownloader
            url = 'http://%s:%s/?url=%s'%(str(tsdownloader.HOST_NAME),str(tsdownloader.PORT_NUMBER),quote(url))
            tsdownloader.XtreamProxyTS().start()            
        elif '.mp4' in url:
            mode = 'mp4'
            import mp4retry
            url = 'http://%s:%s/?url=%s'%(str(mp4retry.HOST_NAME),str(mp4retry.PORT_NUMBER),quote(url))
            mp4retry.XtreamProxy().start()
        else:
            mode = 'unknown'
            xbmc.log(f"Formato de URL desconhecido: {url}", xbmc.LOGERROR)
            return
        if mode == 'mp4':
            try:
                sinopse = self.sinopse_text.getText()
                if sinopse and sinopse != "Selecione um item para ver a sinopse." and sinopse != "Sinopse não disponível.":
                    description = sinopse
                else:
                    description = 'Nenhuma sinopse disponível para o item selecionado.'
            except Exception as e:
                xbmc.log(f"Erro ao obter sinopse: {str(e)}", xbmc.LOGERROR)
                description = ''
        elif mode == 'hls':
            try:
                description = self.epg_text.getLabel()
            except Exception as e:
                xbmc.log(f"Erro ao obter EPG: {str(e)}", xbmc.LOGERROR)
                description = ''
        else:
            description = ''
        xbmc.log(f"Reproduzindo stream: {url}", xbmc.LOGDEBUG)
        liz = xbmcgui.ListItem(item.get('name', 'Stream'))
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(item.get('name', 'Stream'))
            info.setPlot(description)
        else:
            liz.setInfo(type='Video', infoLabels={'Title': item.get('name', 'Stream'), 'Plot': description})
        liz.setArt({"icon": "DefaultVideo.png", "thumb": self.iconimage})
        liz.setPath(url)
        xbmc.Player().play(url, liz)
        self.setFocus(self.list_control)

    def close(self):
        super().close()