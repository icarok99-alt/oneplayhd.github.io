# -*- coding: utf-8 -*-
"""
Proxy hardening drop-in for OnePlay Matrix 3.2.93.

Objetivo:
- endurecer HLS e TS para listas ruins
- reduzir reconexão cega
- manter continuidade percebida com cache curto de cauda
- preservar a interface de uso mais provável do addon base

Observação honesta:
- este arquivo foi montado como substituto cirúrgico de resources/lib/proxy.py
  com base na auditoria funcional da base 3.2.93 e no estudo do plugin.video.f4mTester.
- sem o ZIP-base disponível aqui para inspeção direta, a implementação prioriza
  compatibilidade ampla e funções auxiliares extras para reduzir risco de integração.
"""

from __future__ import absolute_import, division, unicode_literals

import json
import os
import re
import socket
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse, urlunparse

try:
    import requests
    from requests.exceptions import RequestException
except Exception:  # pragma: no cover
    requests = None
    RequestException = Exception

try:  # Kodi runtime
    import xbmc
    import xbmcaddon
    import xbmcvfs
except Exception:  # local lint/runtime fallback
    xbmc = None
    xbmcaddon = None
    xbmcvfs = None

PORT = 8094
HOST = '127.0.0.1'
DEFAULT_USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'
)

URL_HLSRETRY = 'http://%s:%d/hlsretry?url=' % (HOST, PORT)
URL_TS_DOWNLOADER = 'http://%s:%d/tsdownloader?url=' % (HOST, PORT)

CONNECT_TIMEOUT = 4
READ_TIMEOUT = 12
MANIFEST_TIMEOUT = 8
SEGMENT_TIMEOUT = 12
PROBE_TIMEOUT = 4
CHUNK_SIZE = 64 * 1024
TS_PACKET = 188
TAIL_CACHE_SEGMENTS = 28
TS_STARTUP_PACKETS = 176
TS_STARTUP_BYTES = TS_PACKET * TS_STARTUP_PACKETS
TS_MIN_USEFUL_BYTES = TS_PACKET * 448
TS_STARTUP_DEADLINE = 2.8
TS_MAX_STARTUP_DEADLINE = 4.8
TS_STARTUP_MAX_BYTES = TS_PACKET * 512
TS_RECONNECT_TRIES = 10
TS_RECONNECT_SHORT_SECONDS = 22.0
TS_HARD_FAIL_TTL = 420.0
HLS_FORBIDDEN_TTL = 420.0
HOST_MODE_PIN_TTL = 300.0
MANIFEST_CACHE_TTL = 1.5
FINAL_URL_TTL = 15.0
STABLE_MODE_TTL = 1800
UNSTABLE_MODE_TTL = 300
MAX_HLS_RETRIES = 3
MAX_TS_RETRIES = 4
UA_ROTATE_THRESHOLD = 3
MAX_404_WINDOW = 4
MAX_REDIRECTS = 5
TS_GRACE_CORRUPT_BYTES = TS_PACKET * 64
TS_SURVIVAL_TAIL_REPLAY = 12
TS_SHORT_BACKOFF = (0.15, 0.35, 0.7, 1.1, 1.6, 2.2)
HOST_TS_SURVIVAL_TTL = 600.0
HOST_TS_SURVIVAL_SCORE_PIN = 3
TS_RECONNECT_TRIES_AGGRESSIVE = 14
TS_RECONNECT_SHORT_SECONDS_AGGRESSIVE = 32.0
TS_SURVIVAL_TAIL_REPLAY_AGGRESSIVE = 20
TS_MIN_USEFUL_BYTES_AGGRESSIVE = TS_PACKET * 640
TS_STARTUP_BYTES_AGGRESSIVE = TS_PACKET * 256
TS_STARTUP_MAX_BYTES_AGGRESSIVE = TS_PACKET * 768
TS_STARTUP_DEADLINE_AGGRESSIVE = 4.0
TS_MAX_STARTUP_DEADLINE_AGGRESSIVE = 6.5

_REWRITE_URI_RE = re.compile(r'URI="([^"]+)"')
_TS_NUMERIC_SEG_RE = re.compile(r'_(\d+)(\.ts(?:\?.*)?)$', re.I)

_SERVER = None
_SERVER_THREAD = None
_SERVER_LOCK = threading.Lock()
_STATE_LOCK = threading.RLock()
_STOP_EVENT = threading.Event()

MANIFEST_CACHE = {}
FINAL_URL_CACHE = {}
TAIL_CACHE = {}
STREAM_STATE = {}
MODE_CACHE = {}
HOST_HINTS = {}


def _xbmc_log_level(name):
    if xbmc is None:
        return None
    levels = {
        'debug': getattr(xbmc, 'LOGDEBUG', 0),
        'info': getattr(xbmc, 'LOGINFO', 1),
        'warning': getattr(xbmc, 'LOGWARNING', 2),
        'error': getattr(xbmc, 'LOGERROR', 4),
    }
    return levels.get(name, getattr(xbmc, 'LOGINFO', 1))


def log(message, level='info'):
    prefix = '[OnePlayProxy] '
    try:
        if xbmc is not None:
            xbmc.log(prefix + str(message), _xbmc_log_level(level))
        else:
            print(prefix + str(message))
    except Exception:
        try:
            print(prefix + str(message))
        except Exception:
            pass


def _addon_profile_dir():
    try:
        if xbmcaddon is None:
            return None
        addon = xbmcaddon.Addon()
        profile = addon.getAddonInfo('profile')
        if xbmcvfs is not None:
            profile = xbmcvfs.translatePath(profile)
        if profile and not os.path.isdir(profile):
            os.makedirs(profile)
        return profile
    except Exception:
        return None


def _metrics_path():
    base = _addon_profile_dir()
    if not base:
        return None
    return os.path.join(base, 'proxy_metrics.json')


def _save_metrics_snapshot():
    path = _metrics_path()
    if not path:
        return
    try:
        with _STATE_LOCK:
            data = {
                'updated_at': time.time(),
                'streams': STREAM_STATE,
                'mode_cache': MODE_CACHE,
            }
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
    except Exception as exc:
        log('Falha ao salvar proxy_metrics.json: %s' % exc, 'debug')


def customdns():
    """Tenta aplicar o DNS custom da base sem explodir se o módulo mudar."""
    candidates = (
        ('resources.lib.dns', 'customdns'),
        ('dns', 'customdns'),
    )
    for mod_name, func_name in candidates:
        try:
            module = __import__(mod_name, fromlist=[func_name])
            func = getattr(module, func_name, None)
            if callable(func):
                func()
                return True
        except Exception:
            continue
    return False


def strip_headers_suffix(url):
    if not url:
        return url
    if '|User-Agent=' in url or '|' in url:
        return url.split('|', 1)[0]
    if '%7C' in url:
        return url.split('%7C', 1)[0]
    return url


def normalize_url(url):
    url = unquote(url or '').strip()
    return strip_headers_suffix(url)


def convert_to_m3u8(url):
    url = normalize_url(url)
    if not url:
        return url
    low = url.lower()
    if '.m3u8' in low or '/hl' in low or '.mp4' in low or '.avi' in low or '.mkv' in low:
        return url
    if url.count('/') <= 4:
        return url
    try:
        parsed = urlparse(url)
        host_part = '%s://%s' % (parsed.scheme, parsed.netloc)
        host_tail = url.split(host_part, 1)[1]
        if not host_tail.startswith('/live/'):
            url = host_part + '/live' + host_tail
        file_name = os.path.basename(urlparse(url).path)
        if file_name.lower().endswith('.ts'):
            url = url[:-3] + 'm3u8'
        elif not url.lower().endswith('.m3u8'):
            url += '.m3u8'
    except Exception:
        pass
    return url


def m3u8_to_ts(url):
    url = normalize_url(url)
    if not url:
        return url
    if '.m3u8' in url and '/live/' in url and url.count('/') > 5:
        return url.replace('/live/', '/', 1).rsplit('.m3u8', 1)[0]
    if url.lower().endswith('.ts'):
        return url[:-3]
    return url


def _canonical_stream_key(url):
    url = normalize_url(url)
    try:
        parsed = urlparse(url)
        path = parsed.path or ''
        path = _TS_NUMERIC_SEG_RE.sub(r'_SEG\2', path)
        if path.endswith('.m3u8'):
            path = path[:-5] + '.m3u8'
        return urlunparse((parsed.scheme, parsed.netloc, path, '', '', ''))
    except Exception:
        return url


def _host_key(url):
    try:
        parsed = urlparse(normalize_url(url))
        return '%s://%s' % (parsed.scheme or 'http', parsed.netloc)
    except Exception:
        return normalize_url(url)


def _now():
    return time.time()


def _host_hint(host_key):
    with _STATE_LOCK:
        hint = HOST_HINTS.get(host_key)
        if hint is None:
            hint = {
                'prefer_mode': '',
                'prefer_mode_until': 0.0,
                'hls_forbidden_until': 0.0,
                'last_error': '',
                'last_ts_ok': 0.0,
                'ts_survival_until': 0.0,
                'ts_issue_score': 0,
                'last_issue_at': 0.0,
                'host_eof_reconnects': 0,
                'host_short_failures': 0,
            }
            HOST_HINTS[host_key] = hint
        return hint


def _pin_host_mode(url, mode, ttl, reason=''):
    host_key = _host_key(url)
    with _STATE_LOCK:
        hint = _host_hint(host_key)
        hint['prefer_mode'] = mode
        hint['prefer_mode_until'] = _now() + ttl
        if reason:
            hint['last_error'] = reason


def _get_pinned_host_mode(url):
    host_key = _host_key(url)
    with _STATE_LOCK:
        hint = HOST_HINTS.get(host_key)
        if not hint:
            return None
        if hint.get('prefer_mode_until', 0.0) < _now():
            hint['prefer_mode'] = ''
            return None
        return hint.get('prefer_mode') or None


def _mark_hls_forbidden(url, stream_key=None, reason=''):
    host_key = _host_key(url)
    now = _now()
    with _STATE_LOCK:
        hint = _host_hint(host_key)
        hint['hls_forbidden_until'] = now + HLS_FORBIDDEN_TTL
        hint['prefer_mode'] = 'ts'
        hint['prefer_mode_until'] = now + HOST_MODE_PIN_TTL
        if reason:
            hint['last_error'] = reason
        if stream_key:
            state = _get_state(stream_key)
            state['last_hls_forbidden'] = now
            state['force_mode_until'] = now + HOST_MODE_PIN_TTL
            state['force_mode'] = 'ts'
            if reason:
                state['last_error'] = reason


def _is_hls_forbidden(url, stream_key=None):
    host_key = _host_key(url)
    with _STATE_LOCK:
        hint = HOST_HINTS.get(host_key)
        if hint and hint.get('hls_forbidden_until', 0.0) >= _now():
            return True
        if stream_key:
            state = STREAM_STATE.get(stream_key)
            if state and state.get('last_hls_forbidden', 0.0) + HLS_FORBIDDEN_TTL >= _now():
                return True
    return False


def _mark_host_ts_issue(url, reason='', weight=1):
    host_key = _host_key(url)
    now = _now()
    with _STATE_LOCK:
        hint = _host_hint(host_key)
        hint['ts_issue_score'] = int(hint.get('ts_issue_score', 0) or 0) + int(max(1, weight))
        hint['last_issue_at'] = now
        hint['ts_survival_until'] = max(float(hint.get('ts_survival_until', 0.0) or 0.0), now + HOST_TS_SURVIVAL_TTL)
        if reason:
            hint['last_error'] = reason


def _record_host_ts_ok(url):
    host_key = _host_key(url)
    now = _now()
    with _STATE_LOCK:
        hint = _host_hint(host_key)
        hint['last_ts_ok'] = now
        score = int(hint.get('ts_issue_score', 0) or 0)
        last_issue = float(hint.get('last_issue_at', 0.0) or 0.0)
        if score > 0 and last_issue and (now - last_issue) >= 20.0:
            hint['ts_issue_score'] = max(0, score - 1)


def _host_survival_profile(url):
    host_key = _host_key(url)
    now = _now()
    with _STATE_LOCK:
        hint = _host_hint(host_key)
        issue_score = int(hint.get('ts_issue_score', 0) or 0)
        hls_forbidden_until = float(hint.get('hls_forbidden_until', 0.0) or 0.0)
        survive_until = float(hint.get('ts_survival_until', 0.0) or 0.0)
        aggressive = survive_until >= now or issue_score >= HOST_TS_SURVIVAL_SCORE_PIN or hls_forbidden_until >= now
        if aggressive and survive_until < now:
            hint['ts_survival_until'] = now + HOST_TS_SURVIVAL_TTL
    if aggressive:
        return {
            'aggressive': True,
            'tries': TS_RECONNECT_TRIES_AGGRESSIVE,
            'short_seconds': TS_RECONNECT_SHORT_SECONDS_AGGRESSIVE,
            'min_useful_bytes': TS_MIN_USEFUL_BYTES_AGGRESSIVE,
            'tail_replay': TS_SURVIVAL_TAIL_REPLAY_AGGRESSIVE,
            'startup_bytes': TS_STARTUP_BYTES_AGGRESSIVE,
            'startup_max_bytes': TS_STARTUP_MAX_BYTES_AGGRESSIVE,
            'startup_deadline': TS_STARTUP_DEADLINE_AGGRESSIVE,
            'startup_max_deadline': TS_MAX_STARTUP_DEADLINE_AGGRESSIVE,
        }
    return {
        'aggressive': False,
        'tries': TS_RECONNECT_TRIES,
        'short_seconds': TS_RECONNECT_SHORT_SECONDS,
        'min_useful_bytes': TS_MIN_USEFUL_BYTES,
        'tail_replay': TS_SURVIVAL_TAIL_REPLAY,
        'startup_bytes': TS_STARTUP_BYTES,
        'startup_max_bytes': TS_STARTUP_MAX_BYTES,
        'startup_deadline': TS_STARTUP_DEADLINE,
        'startup_max_deadline': TS_MAX_STARTUP_DEADLINE,
    }


def _get_state(key):
    with _STATE_LOCK:
        state = STREAM_STATE.get(key)
        if state is None:
            state = {
                'manifest_failures': 0,
                'segment_failures': 0,
                'midstream_disconnects': 0,
                'ts_sync_losses': 0,
                'ts_404_count': 0,
                'ts_404_window_start': 0.0,
                'last_good_segment_time': 0.0,
                'last_manifest_ok': 0.0,
                'current_mode': '',
                'resolved_final_url': '',
                'sticky_user_agent': DEFAULT_USER_AGENT,
                'ua_rotations': 0,
                'unstable': False,
                'last_error': '',
                'last_hls_forbidden': 0.0,
                'force_mode_until': 0.0,
                'force_mode': '',
                'last_ts_good': 0.0,
                'last_ts_connect': 0.0,
                'last_eof_recover': 0.0,
                'ts_short_failures': 0,
                'ts_tail_replays': 0,
                'ts_eof_reconnects': 0,
            }
            STREAM_STATE[key] = state
        return state


def _mark_unstable(key, reason=''):
    with _STATE_LOCK:
        state = _get_state(key)
        state['unstable'] = True
        if reason:
            state['last_error'] = reason


def _record_manifest_ok(key, final_url=''):
    with _STATE_LOCK:
        state = _get_state(key)
        state['manifest_failures'] = 0
        state['last_manifest_ok'] = _now()
        state['current_mode'] = 'hls'
        if final_url:
            state['resolved_final_url'] = final_url


def _record_segment_ok(key, final_url=''):
    with _STATE_LOCK:
        state = _get_state(key)
        state['segment_failures'] = 0
        state['last_good_segment_time'] = _now()
        state['last_ts_good'] = _now()
        state['ts_short_failures'] = 0
        if int(state.get('ts_eof_reconnects', 0)) > 0 and (state['last_ts_good'] - float(state.get('last_eof_recover', 0.0) or 0.0)) > 6.0:
            state['ts_eof_reconnects'] = 0
        if state.get('force_mode') == 'ts' and state.get('force_mode_until', 0.0) < _now():
            state['force_mode'] = ''
        if final_url:
            state['resolved_final_url'] = final_url


def _record_failure(key, bucket, message=''):
    with _STATE_LOCK:
        state = _get_state(key)
        if bucket in state:
            state[bucket] += 1
        if message:
            state['last_error'] = message
        if bucket in ('manifest_failures', 'segment_failures', 'midstream_disconnects', 'ts_sync_losses'):
            state['unstable'] = True
        if bucket in ('segment_failures', 'midstream_disconnects') and state.get('current_mode') == 'ts':
            state['ts_short_failures'] = int(state.get('ts_short_failures', 0)) + 1
        if bucket == 'manifest_failures':
            state['current_mode'] = 'hls'
        elif bucket in ('segment_failures', 'ts_sync_losses'):
            state['current_mode'] = 'ts'


def _record_ts_404(key):
    with _STATE_LOCK:
        state = _get_state(key)
        now = _now()
        start = state.get('ts_404_window_start', 0.0)
        if now - start > 10.0:
            state['ts_404_window_start'] = now
            state['ts_404_count'] = 1
        else:
            state['ts_404_count'] = int(state.get('ts_404_count', 0)) + 1
        return state['ts_404_count']


def _set_mode_cache(key, mode, unstable=False):
    ttl = UNSTABLE_MODE_TTL if unstable else STABLE_MODE_TTL
    with _STATE_LOCK:
        MODE_CACHE[key] = {'mode': mode, 'expires': _now() + ttl, 'unstable': unstable}


def _get_mode_cache(key):
    with _STATE_LOCK:
        entry = MODE_CACHE.get(key)
        if not entry:
            return None
        if entry.get('expires', 0.0) < _now():
            MODE_CACHE.pop(key, None)
            return None
        return entry.get('mode')


def _tail_deque_for(key):
    with _STATE_LOCK:
        dq = TAIL_CACHE.get(key)
        if dq is None:
            dq = deque(maxlen=TAIL_CACHE_SEGMENTS)
            TAIL_CACHE[key] = dq
        return dq


def _tail_push(key, chunk):
    if not chunk:
        return
    dq = _tail_deque_for(key)
    try:
        dq.append(bytes(chunk))
    except Exception:
        pass


def _tail_snapshot(key):
    with _STATE_LOCK:
        dq = TAIL_CACHE.get(key)
        return list(dq) if dq else []


def _should_reconnect_after_eof(stream_key, attempt_bytes, attempt_start, started, min_useful_bytes=None, short_seconds=None, aggressive=False):
    if not started:
        return False
    now = _now()
    min_useful_bytes = int(min_useful_bytes or TS_MIN_USEFUL_BYTES)
    short_seconds = float(short_seconds or TS_RECONNECT_SHORT_SECONDS)
    with _STATE_LOCK:
        state = _get_state(stream_key)
        last_good = float(state.get('last_good_segment_time', 0.0) or 0.0)
        eof_reconnects = int(state.get('ts_eof_reconnects', 0) or 0)
    age = now - attempt_start
    recently_good = (now - last_good) <= (10.0 if aggressive else 8.0) if last_good else False
    if attempt_bytes >= min_useful_bytes:
        return True
    if age >= short_seconds:
        return recently_good or eof_reconnects < (4 if aggressive else 2)
    return attempt_bytes > 0 or recently_good or aggressive


def _mark_eof_reconnect(stream_key):
    with _STATE_LOCK:
        state = _get_state(stream_key)
        state['ts_eof_reconnects'] = int(state.get('ts_eof_reconnects', 0)) + 1
        state['last_eof_recover'] = _now()


def _build_headers(extra=None, stream_key=None, ts_mode=False):
    headers = {
        'User-Agent': DEFAULT_USER_AGENT,
        'Accept': '*/*',
        'Accept-Encoding': 'identity',
        'Connection': 'keep-alive',
    }
    if stream_key:
        state = _get_state(stream_key)
        headers['User-Agent'] = state.get('sticky_user_agent') or DEFAULT_USER_AGENT
        if ts_mode:
            headers['User-Agent'] = headers['User-Agent'] or DEFAULT_USER_AGENT
    if extra:
        for key, value in extra.items():
            if not key:
                continue
            if key.lower() == 'host':
                continue
            headers[key] = value
    return headers


def _rotate_user_agent(stream_key):
    with _STATE_LOCK:
        state = _get_state(stream_key)
        state['ua_rotations'] = int(state.get('ua_rotations', 0)) + 1
        state['sticky_user_agent'] = '%s OPX/%d-%d' % (
            DEFAULT_USER_AGENT,
            int(_now()),
            state['ua_rotations'],
        )
        return state['sticky_user_agent']


def _get_cached_final_url(url):
    with _STATE_LOCK:
        item = FINAL_URL_CACHE.get(url)
        if not item:
            return None
        if item.get('expires', 0.0) < _now():
            FINAL_URL_CACHE.pop(url, None)
            return None
        return item.get('url')


def _cache_final_url(original_url, final_url):
    if not original_url or not final_url:
        return
    with _STATE_LOCK:
        FINAL_URL_CACHE[original_url] = {'url': final_url, 'expires': _now() + FINAL_URL_TTL}


def _get_cached_manifest(url):
    with _STATE_LOCK:
        item = MANIFEST_CACHE.get(url)
        if not item:
            return None
        if item.get('expires', 0.0) < _now():
            MANIFEST_CACHE.pop(url, None)
            return None
        return item


def _cache_manifest(url, body, content_type='application/x-mpegURL', final_url=''):
    with _STATE_LOCK:
        MANIFEST_CACHE[url] = {
            'body': body,
            'content_type': content_type,
            'expires': _now() + MANIFEST_CACHE_TTL,
            'final_url': final_url,
        }


def _open_session():
    if requests is None:
        raise RuntimeError('requests não disponível no ambiente do Kodi.')
    sess = requests.Session()
    sess.max_redirects = MAX_REDIRECTS
    return sess


def _resolve_url(url, headers=None, timeout=PROBE_TIMEOUT):
    cached = _get_cached_final_url(url)
    if cached:
        return cached
    sess = _open_session()
    try:
        response = sess.get(url, headers=headers or _build_headers(), stream=True,
                            allow_redirects=True, timeout=(CONNECT_TIMEOUT, timeout), verify=False)
        final_url = response.url or url
        _cache_final_url(url, final_url)
        return final_url
    finally:
        try:
            sess.close()
        except Exception:
            pass


def _read_small(response, limit=128 * 1024):
    chunks = []
    size = 0
    for chunk in response.iter_content(chunk_size=16 * 1024):
        if not chunk:
            continue
        chunks.append(chunk)
        size += len(chunk)
        if size >= limit:
            break
    return b''.join(chunks)


def _fetch_manifest(url, request_headers=None, stream_key=None):
    stream_key = stream_key or _canonical_stream_key(url)
    cached = _get_cached_manifest(url)
    if cached:
        return cached['body'], cached.get('content_type', 'application/x-mpegURL'), cached.get('final_url') or url

    headers = _build_headers(request_headers, stream_key=stream_key, ts_mode=False)
    last_error = None
    for attempt in range(MAX_HLS_RETRIES):
        sess = _open_session()
        try:
            target = _get_cached_final_url(url) or url
            response = sess.get(target, headers=headers, stream=True, allow_redirects=True,
                                timeout=(CONNECT_TIMEOUT, MANIFEST_TIMEOUT), verify=False)
            if response.status_code >= 400:
                last_error = 'HTTP %s ao buscar manifesto' % response.status_code
                _record_failure(stream_key, 'manifest_failures', last_error)
                if response.status_code in (401, 403):
                    _mark_hls_forbidden(url, stream_key=stream_key, reason=last_error)
                    break
                if response.status_code == 416 and 'Range' in headers:
                    headers.pop('Range', None)
                elif attempt + 1 >= UA_ROTATE_THRESHOLD:
                    headers['User-Agent'] = _rotate_user_agent(stream_key)
                time.sleep((0.25, 0.7, 1.5)[min(attempt, 2)])
                continue

            final_url = response.url or target
            content_type = response.headers.get('Content-Type', 'application/x-mpegURL')
            raw = _read_small(response)
            body = raw.decode('utf-8', errors='ignore')
            if '#EXTM3U' in body or '.ts' in body or '.m3u8' in final_url.lower() or 'mpegurl' in content_type.lower():
                _cache_final_url(url, final_url)
                _cache_manifest(url, body, content_type, final_url=final_url)
                _record_manifest_ok(stream_key, final_url=final_url)
                return body, content_type, final_url
            last_error = 'Conteúdo recebido não parece HLS.'
            _record_failure(stream_key, 'manifest_failures', last_error)
        except RequestException as exc:
            last_error = str(exc)
            _record_failure(stream_key, 'manifest_failures', last_error)
            if attempt + 1 >= UA_ROTATE_THRESHOLD:
                headers['User-Agent'] = _rotate_user_agent(stream_key)
            time.sleep((0.25, 0.7, 1.5)[min(attempt, 2)])
        finally:
            try:
                sess.close()
            except Exception:
                pass

    cached = _get_cached_manifest(url)
    if cached:
        log('Usando manifesto cacheado após falha: %s' % (last_error or url), 'warning')
        return cached['body'], cached.get('content_type', 'application/x-mpegURL'), cached.get('final_url') or url
    raise RuntimeError(last_error or 'Falha ao obter manifesto HLS.')


def _rewrite_uri_tag(line, base_url):
    def repl(match):
        target = match.group(1)
        absolute = urljoin(base_url, target)
        proxied = URL_HLSRETRY + quote(absolute, safe='')
        return 'URI="%s"' % proxied
    return _REWRITE_URI_RE.sub(repl, line)


def _rewrite_playlist(playlist_text, final_url):
    base_url = final_url.rsplit('/', 1)[0] + '/'
    rewritten = []
    for raw_line in playlist_text.splitlines():
        line = raw_line.strip()
        if not line:
            rewritten.append('')
            continue
        if line.startswith('#'):
            rewritten.append(_rewrite_uri_tag(line, base_url))
            continue
        absolute = urljoin(base_url, line)
        proxied = URL_HLSRETRY + quote(absolute, safe='')
        rewritten.append(proxied)
    return '\n'.join(rewritten) + '\n'


def _h264_start_ready(buffer):
    if not buffer:
        return False
    sps = False
    pps = False
    idr = False
    for needle in (b'\x00\x00\x01', b'\x00\x00\x00\x01'):
        pos = 0
        while True:
            idx = buffer.find(needle, pos)
            if idx < 0:
                break
            nal_idx = idx + len(needle)
            if nal_idx >= len(buffer):
                break
            nal_type = buffer[nal_idx] & 0x1F
            if nal_type == 7:
                sps = True
            elif nal_type == 8:
                pps = True
            elif nal_type == 5:
                idr = True
            if idr and (sps or pps):
                return True
            pos = nal_idx
    return False


def _ts_startup_ready(ts_startup, attempt_start, startup_bytes=None, startup_max_bytes=None, startup_deadline=None, startup_max_deadline=None):
    startup_bytes = int(startup_bytes or TS_STARTUP_BYTES)
    startup_max_bytes = int(startup_max_bytes or TS_STARTUP_MAX_BYTES)
    startup_deadline = float(startup_deadline or TS_STARTUP_DEADLINE)
    startup_max_deadline = float(startup_max_deadline or TS_MAX_STARTUP_DEADLINE)
    if len(ts_startup) >= startup_max_bytes:
        return True
    age = _now() - attempt_start
    if len(ts_startup) >= startup_bytes and _h264_start_ready(ts_startup):
        return True
    if age >= startup_max_deadline and len(ts_startup) >= TS_PACKET * 24:
        return True
    if age >= startup_deadline and len(ts_startup) >= startup_bytes * 2:
        return True
    if age >= (startup_max_deadline - 0.6) and len(ts_startup) >= TS_PACKET * 96 and _h264_start_ready(ts_startup):
        return True
    return False


def _sanitize_ts_buffer(buffer):
    if not buffer:
        return b'', b''

    first_sync = -1
    scan_limit = min(len(buffer), TS_PACKET * 8)
    for idx in range(scan_limit):
        if buffer[idx] != 0x47:
            continue
        good = 0
        probe = idx
        for _ in range(5):
            probe += TS_PACKET
            if probe < len(buffer) and buffer[probe] == 0x47:
                good += 1
        if good >= 2:
            first_sync = idx
            break

    if first_sync < 0:
        keep = buffer[-(TS_PACKET * 8):] if len(buffer) > TS_PACKET * 8 else buffer
        return b'', keep

    trimmed = buffer[first_sync:]
    usable = (len(trimmed) // TS_PACKET) * TS_PACKET
    if usable <= 0:
        return b'', trimmed
    return trimmed[:usable], trimmed[usable:]


def _copy_relevant_headers(handler):
    headers = {}
    for key in handler.headers.keys():
        value = handler.headers.get(key)
        if not value:
            continue
        low = key.lower()
        if low in ('host', 'content-length', 'accept-encoding'):
            continue
        headers[key] = value
    if 'Range' in handler.headers:
        headers['Range'] = handler.headers.get('Range')
    return headers


def probe_hls(url):
    url = convert_to_m3u8(url)
    stream_key = _canonical_stream_key(url)
    if _is_hls_forbidden(url, stream_key=stream_key):
        return False
    try:
        body, _ctype, _final = _fetch_manifest(url, stream_key=stream_key)
        return bool(body and '#EXTM3U' in body)
    except Exception:
        return False


def probe_ts(url):
    target = m3u8_to_ts(url)
    stream_key = _canonical_stream_key(target)
    sess = _open_session()
    try:
        response = sess.get(target, headers=_build_headers(stream_key=stream_key, ts_mode=True),
                            stream=True, allow_redirects=True,
                            timeout=(CONNECT_TIMEOUT, PROBE_TIMEOUT), verify=False)
        if response.status_code >= 400:
            return False
        raw = _read_small(response, limit=TS_PACKET * 32)
        cleaned, _rest = _sanitize_ts_buffer(raw)
        return bool(cleaned)
    except Exception:
        return False
    finally:
        try:
            sess.close()
        except Exception:
            pass


def choose_mode(url):
    key = _canonical_stream_key(url)
    state = _get_state(key)

    if state.get('force_mode') and state.get('force_mode_until', 0.0) >= _now():
        return state.get('force_mode')

    pinned = _get_pinned_host_mode(url)
    if pinned:
        return pinned

    cached = _get_mode_cache(key)
    if cached:
        return cached

    original = normalize_url(url)
    prefer_hls = '.m3u8' in original.lower() or '/live/' in original.lower()
    hls_forbidden = _is_hls_forbidden(url, stream_key=key)
    hls_ok = False if hls_forbidden else probe_hls(url)
    ts_ok = probe_ts(url)

    if hls_forbidden and ts_ok:
        mode = 'ts'
    elif prefer_hls and hls_ok:
        mode = 'hls'
    elif ts_ok and not hls_ok:
        mode = 'ts'
    elif hls_ok and not ts_ok:
        mode = 'hls'
    elif ts_ok and hls_ok:
        ts_bad = state.get('ts_sync_losses', 0) >= 3 or state.get('midstream_disconnects', 0) >= 3
        hls_bad = state.get('manifest_failures', 0) >= 2 or _is_hls_forbidden(url, stream_key=key)
        if hls_bad:
            mode = 'ts'
        else:
            mode = 'hls' if (prefer_hls and not ts_bad) else 'ts'
    else:
        mode = 'ts' if hls_forbidden else 'hls'

    unstable = hls_forbidden or not (hls_ok and ts_ok)
    _set_mode_cache(key, mode, unstable=unstable)
    with _STATE_LOCK:
        state['current_mode'] = mode
        if mode == 'ts' and (hls_forbidden or state.get('midstream_disconnects', 0) >= 2 or state.get('ts_short_failures', 0) >= 2):
            state['force_mode'] = 'ts'
            state['force_mode_until'] = _now() + HOST_MODE_PIN_TTL
    if mode == 'ts':
        _pin_host_mode(url, 'ts', HOST_MODE_PIN_TTL, reason='preferência survival/host')
    return mode


def build_hls_url(url):
    return URL_HLSRETRY + quote(convert_to_m3u8(url), safe='')


def build_ts_url(url):
    return URL_TS_DOWNLOADER + quote(m3u8_to_ts(url), safe='')


def build_balanced_url(url):
    mode = choose_mode(url)
    return build_ts_url(url) if mode == 'ts' else build_hls_url(url)


def hls_url(url):
    return build_hls_url(url)


def ts_url(url):
    return build_ts_url(url)


def balanced_url(url):
    return build_balanced_url(url)


def _send_bytes(handler, data, status=200, content_type='application/octet-stream', headers=None):
    handler.send_response(status)
    handler.send_header('Content-Type', content_type)
    handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
    handler.send_header('Pragma', 'no-cache')
    handler.send_header('Connection', 'close')
    if headers:
        for key, value in headers.items():
            if key.lower() in ('content-length', 'transfer-encoding', 'connection', 'server', 'date'):
                continue
            handler.send_header(key, value)
    if isinstance(data, (bytes, bytearray)):
        handler.send_header('Content-Length', str(len(data)))
    handler.end_headers()
    if data:
        handler.wfile.write(data)


def _send_head_ok(handler, content_type='application/octet-stream'):
    handler.send_response(200)
    handler.send_header('Content-Type', content_type)
    handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
    handler.send_header('Pragma', 'no-cache')
    handler.send_header('Accept-Ranges', 'none')
    handler.send_header('Connection', 'close')
    handler.end_headers()


class ProxyRequestHandler(BaseHTTPRequestHandler):
    server_version = 'OnePlayProxy/1.3'
    protocol_version = 'HTTP/1.0'

    def log_message(self, fmt, *args):  # silence noisy default logging
        log(fmt % args, 'debug')

    def do_HEAD(self):
        parsed = urlparse(self.path)
        route = parsed.path
        if route in ('/', '/health'):
            return _send_head_ok(self, 'application/json')
        if route == '/hlsretry':
            return _send_head_ok(self, 'application/x-mpegURL')
        if route == '/tsdownloader':
            return _send_head_ok(self, 'video/mp2t')
        return _send_head_ok(self, 'text/plain; charset=utf-8')

    def do_GET(self):
        try:
            customdns()
        except Exception:
            pass

        parsed = urlparse(self.path)
        route = parsed.path
        if route == '/':
            payload = json.dumps({'message': 'OnePlay Proxy Hardening', 'port': PORT}).encode('utf-8')
            return _send_bytes(self, payload, content_type='application/json')
        if route == '/health':
            payload = json.dumps({'ok': True, 'port': PORT, 'running': True}).encode('utf-8')
            return _send_bytes(self, payload, content_type='application/json')
        if route == '/stop':
            payload = b'OK'
            _send_bytes(self, payload, content_type='text/plain; charset=utf-8')
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        if route == '/hlsretry':
            return self._handle_hls(parsed)
        if route == '/tsdownloader':
            return self._handle_ts(parsed)

        _send_bytes(self, b'Not found', status=404, content_type='text/plain; charset=utf-8')

    def _handle_hls(self, parsed):
        query = parse_qs(parsed.query)
        url = normalize_url((query.get('url') or [''])[0])
        if not url:
            return _send_bytes(self, b'{"detail":"No URL provided"}', status=400, content_type='application/json')

        request_headers = _copy_relevant_headers(self)
        stream_key = _canonical_stream_key(url)
        low = url.lower()

        if '.m3u8' in low or low.endswith('/playlist') or '/manifest' in low or '/live/' in low:
            if _is_hls_forbidden(url, stream_key=stream_key):
                return _send_bytes(self, b'Forbidden cached for this host', status=502,
                                   content_type='text/plain; charset=utf-8')
            try:
                body, _ctype, final_url = _fetch_manifest(url, request_headers=request_headers, stream_key=stream_key)
                rewritten = _rewrite_playlist(body, final_url)
                return _send_bytes(self, rewritten.encode('utf-8'), content_type='application/x-mpegURL')
            except Exception as exc:
                log('Falha HLS manifesto: %s' % exc, 'warning')
                cached = _get_cached_manifest(url)
                if cached:
                    rewritten = _rewrite_playlist(cached['body'], cached.get('final_url') or url)
                    return _send_bytes(self, rewritten.encode('utf-8'), content_type='application/x-mpegURL')
                return _send_bytes(self, ('Falha ao obter manifesto: %s' % exc).encode('utf-8'), status=502,
                                   content_type='text/plain; charset=utf-8')

        return self._stream_binary(url, stream_key=stream_key, request_headers=request_headers, ts_mode=False)

    def _handle_ts(self, parsed):
        query = parse_qs(parsed.query)
        url = normalize_url((query.get('url') or [''])[0])
        if not url:
            return _send_bytes(self, b'{"detail":"No URL provided"}', status=400, content_type='application/json')
        request_headers = _copy_relevant_headers(self)
        stream_key = _canonical_stream_key(url)
        return self._stream_binary(url, stream_key=stream_key, request_headers=request_headers, ts_mode=True)

    def _stream_binary(self, url, stream_key, request_headers=None, ts_mode=False):
        headers = _build_headers(request_headers, stream_key=stream_key, ts_mode=ts_mode)
        content_type = 'video/mp2t' if ts_mode else 'application/octet-stream'
        profile = _host_survival_profile(url) if ts_mode else None
        tries = profile['tries'] if ts_mode else MAX_HLS_RETRIES
        backoff = TS_SHORT_BACKOFF if ts_mode else (0.25, 0.7, 1.5, 2.0)
        last_error = None
        started = False
        ever_sent = 0
        pending = b''
        host_key = _host_key(url)
        state = _get_state(stream_key)
        min_useful_bytes = profile['min_useful_bytes'] if ts_mode else TS_MIN_USEFUL_BYTES
        reconnect_short_seconds = profile['short_seconds'] if ts_mode else TS_RECONNECT_SHORT_SECONDS
        tail_replay_count = profile['tail_replay'] if ts_mode else TS_SURVIVAL_TAIL_REPLAY

        for attempt in range(tries):
            sess = _open_session()
            response = None
            attempt_bytes = 0
            attempt_start = _now()
            ts_startup = bytearray()
            startup_sent = False
            try:
                target = _get_cached_final_url(url) or url
                response = sess.get(target, headers=headers, stream=True, allow_redirects=True,
                                    timeout=(CONNECT_TIMEOUT, SEGMENT_TIMEOUT if not ts_mode else READ_TIMEOUT), verify=False)
                final_url = response.url or target
                _cache_final_url(url, final_url)
                if ts_mode:
                    _pin_host_mode(final_url, 'ts', HOST_MODE_PIN_TTL, reason='TS ativo estável')
                    _pin_host_mode(url, 'ts', HOST_MODE_PIN_TTL, reason='TS ativo estável')
                    _record_host_ts_ok(url)
                    with _STATE_LOCK:
                        st = _get_state(stream_key)
                        st['last_ts_connect'] = _now()

                if response.status_code == 416 and 'Range' in headers:
                    headers.pop('Range', None)
                    continue

                if response.status_code >= 400:
                    last_error = 'HTTP %s' % response.status_code
                    if not ts_mode and response.status_code in (401, 403):
                        _mark_hls_forbidden(url, stream_key=stream_key, reason=last_error)
                    if ts_mode:
                        _mark_host_ts_issue(url, last_error, weight=2 if response.status_code == 404 else 1)
                    if ts_mode and response.status_code == 404:
                        c404 = _record_ts_404(stream_key)
                        if c404 >= MAX_404_WINDOW:
                            _record_failure(stream_key, 'segment_failures', 'TS entrou em espiral 404')
                            _pin_host_mode(url, 'ts', TS_HARD_FAIL_TTL, reason='espiral 404 no TS')
                            break
                    _record_failure(stream_key, 'segment_failures', last_error)
                    if attempt + 1 >= UA_ROTATE_THRESHOLD:
                        headers['User-Agent'] = _rotate_user_agent(stream_key)
                    time.sleep(backoff[min(attempt, len(backoff)-1)])
                    continue

                response_headers = {}
                remote_type = response.headers.get('Content-Type')
                if remote_type:
                    content_type = remote_type if not ts_mode else 'video/mp2t'
                response_headers['Accept-Ranges'] = 'none'
                
                def ensure_started():
                    nonlocal started
                    if started:
                        return
                    self.send_response(200 if response.status_code == 200 else 206)
                    self.send_header('Content-Type', content_type)
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                    self.send_header('Pragma', 'no-cache')
                    self.send_header('Connection', 'close')
                    for key, value in response_headers.items():
                        self.send_header(key, value)
                    self.end_headers()
                    started = True

                if ts_mode:
                    for chunk in response.iter_content(chunk_size=TS_PACKET * 128):
                        if not chunk:
                            continue
                        pending += chunk
                        cleaned, pending = _sanitize_ts_buffer(pending)
                        if not cleaned:
                            if len(pending) > TS_PACKET * 384:
                                _record_failure(stream_key, 'ts_sync_losses', 'Sem sync TS suficiente; descartando buffer antigo')
                                _mark_host_ts_issue(url, 'Sem sync TS suficiente', weight=1)
                                log('TS sem sync suficiente, aparando buffer stream=%s pend=%d host=%s' % (stream_key, len(pending), host_key), 'debug')
                                pending = pending[-(TS_PACKET * 24):]
                            continue
                        _tail_push(stream_key, cleaned)
                        attempt_bytes += len(cleaned)
                        _record_segment_ok(stream_key, final_url=final_url)
                        _record_host_ts_ok(url)
                        if ts_mode:
                            _pin_host_mode(url, 'ts', HOST_MODE_PIN_TTL, reason='segmento TS ok')
                        if not startup_sent:
                            ts_startup.extend(cleaned)
                            ready = _ts_startup_ready(ts_startup, attempt_start, startup_bytes=profile['startup_bytes'], startup_max_bytes=profile['startup_max_bytes'], startup_deadline=profile['startup_deadline'], startup_max_deadline=profile['startup_max_deadline'])
                            if ready and len(ts_startup) < TS_GRACE_CORRUPT_BYTES and not _h264_start_ready(ts_startup):
                                ready = False
                            if ready:
                                ensure_started()
                                if ts_startup:
                                    self.wfile.write(bytes(ts_startup))
                                    self.wfile.flush()
                                    ever_sent += len(ts_startup)
                                    ts_startup = bytearray()
                                startup_sent = True
                            continue
                        self.wfile.write(cleaned)
                        self.wfile.flush()
                        ever_sent += len(cleaned)

                    if not startup_sent and ts_startup:
                        ensure_started()
                        self.wfile.write(bytes(ts_startup))
                        self.wfile.flush()
                        ever_sent += len(ts_startup)
                        ts_startup = bytearray()
                        startup_sent = True
                    if pending:
                        cleaned, pending = _sanitize_ts_buffer(pending)
                        if cleaned:
                            _tail_push(stream_key, cleaned)
                            if not startup_sent:
                                ensure_started()
                                startup_sent = True
                            self.wfile.write(cleaned)
                            self.wfile.flush()
                            attempt_bytes += len(cleaned)
                            ever_sent += len(cleaned)
                            _record_segment_ok(stream_key, final_url=final_url)
                            _record_host_ts_ok(url)
                            _pin_host_mode(url, 'ts', HOST_MODE_PIN_TTL, reason='flush TS ok')

                    short_attempt = (_now() - attempt_start) < reconnect_short_seconds or attempt_bytes < min_useful_bytes
                    eof_reconnect = attempt + 1 < tries and (attempt_bytes <= 0 or short_attempt or _should_reconnect_after_eof(stream_key, attempt_bytes, attempt_start, started, min_useful_bytes=min_useful_bytes, short_seconds=reconnect_short_seconds, aggressive=bool(profile and profile.get('aggressive'))))
                    if eof_reconnect:
                        _record_failure(stream_key, 'midstream_disconnects' if started else 'segment_failures',
                                        'TS chegou em EOF; survival reconnect')
                        _mark_host_ts_issue(url, 'TS chegou em EOF; survival reconnect', weight=2 if short_attempt else 1)
                        _mark_eof_reconnect(stream_key)
                        with _STATE_LOCK:
                            hint = _host_hint(host_key)
                            hint['host_eof_reconnects'] = int(hint.get('host_eof_reconnects', 0) or 0) + 1
                            if short_attempt:
                                hint['host_short_failures'] = int(hint.get('host_short_failures', 0) or 0) + 1
                        with _STATE_LOCK:
                            st = _get_state(stream_key)
                            st['force_mode'] = 'ts'
                            st['force_mode_until'] = _now() + HOST_MODE_PIN_TTL
                            st['ts_short_failures'] = int(st.get('ts_short_failures', 0)) + 1
                        _pin_host_mode(url, 'ts', HOST_MODE_PIN_TTL, reason='TS survival EOF reconnect')
                        _pin_host_mode(final_url, 'ts', HOST_MODE_PIN_TTL, reason='TS survival EOF reconnect')
                        log('TS survival EOF reconnect %d/%d stream=%s host=%s bytes=%d started=%s short=%s aggressive=%s' % (attempt + 1, tries, stream_key, host_key, attempt_bytes, started, short_attempt, bool(profile and profile.get('aggressive'))), 'warning')
                        with _STATE_LOCK:
                            st = _get_state(stream_key)
                            st['ts_tail_replays'] = int(st.get('ts_tail_replays', 0)) + 1
                        for cached in _tail_snapshot(stream_key)[-tail_replay_count:]:
                            try:
                                if not started:
                                    ensure_started()
                                self.wfile.write(cached)
                                self.wfile.flush()
                                ever_sent += len(cached)
                            except Exception:
                                break
                        time.sleep(backoff[min(attempt, len(backoff)-1)])
                        continue
                    log('TS estabilizado stream=%s bytes=%d tentativas=%d' % (stream_key, ever_sent + attempt_bytes, attempt + 1), 'info')
                    return

                ensure_started()
                for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                    if not chunk:
                        continue
                    _tail_push(stream_key, chunk)
                    self.wfile.write(chunk)
                    self.wfile.flush()
                    attempt_bytes += len(chunk)
                    ever_sent += len(chunk)
                    _record_segment_ok(stream_key, final_url=final_url)
                return

            except (socket.error, OSError, RequestException) as exc:
                last_error = str(exc)
                _record_failure(stream_key, 'midstream_disconnects' if started else 'segment_failures', last_error)
                if attempt + 1 >= UA_ROTATE_THRESHOLD:
                    headers['User-Agent'] = _rotate_user_agent(stream_key)
                if started:
                    for cached in _tail_snapshot(stream_key)[-tail_replay_count:]:
                        try:
                            self.wfile.write(cached)
                            self.wfile.flush()
                            ever_sent += len(cached)
                        except Exception:
                            break
                time.sleep(backoff[min(attempt, len(backoff)-1)])
            except Exception as exc:
                last_error = str(exc)
                _record_failure(stream_key, 'segment_failures', last_error)
                time.sleep(backoff[min(attempt, len(backoff)-1)])
            finally:
                try:
                    if response is not None:
                        response.close()
                except Exception:
                    pass
                try:
                    sess.close()
                except Exception:
                    pass

        if not started:
            log('Falha final stream=%s erro=%s' % (stream_key, last_error or 'desconhecido'), 'error')
            return _send_bytes(self, ('Falha ao abrir stream: %s' % (last_error or 'desconhecido')).encode('utf-8'),
                               status=502, content_type='text/plain; charset=utf-8')
        log('Fluxo encerrado stream=%s bytes_enviados=%d' % (stream_key, ever_sent), 'warning')
        try:
            self.wfile.flush()
        except Exception:
            pass


class _ProxyHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def is_running():
    global _SERVER_THREAD
    return _SERVER_THREAD is not None and _SERVER_THREAD.is_alive()


def server_run():
    global _SERVER
    customdns()
    with _SERVER_LOCK:
        if _SERVER is not None:
            return
        _STOP_EVENT.clear()
        _SERVER = _ProxyHTTPServer((HOST, PORT), ProxyRequestHandler)
    log('Proxy local iniciado em http://%s:%d' % (HOST, PORT), 'info')
    try:
        _SERVER.serve_forever(poll_interval=0.5)
    except Exception as exc:
        log('Proxy finalizado com exceção: %s' % exc, 'warning')
    finally:
        try:
            _SERVER.server_close()
        except Exception:
            pass
        with _SERVER_LOCK:
            _SERVER = None
        _STOP_EVENT.set()
        _save_metrics_snapshot()
        log('Proxy local encerrado.', 'info')


def kodiproxy():
    global _SERVER_THREAD
    if is_running():
        return True
    with _SERVER_LOCK:
        if _SERVER_THREAD is not None and _SERVER_THREAD.is_alive():
            return True
        _SERVER_THREAD = threading.Thread(target=server_run, name='OnePlayProxy8094', daemon=True)
        _SERVER_THREAD.start()
    deadline = _now() + 3.0
    while _now() < deadline:
        try:
            sock = socket.create_connection((HOST, PORT), timeout=0.3)
            sock.close()
            return True
        except Exception:
            time.sleep(0.1)
    return is_running()


def stop_proxy():
    global _SERVER
    with _SERVER_LOCK:
        if _SERVER is None:
            return True
        try:
            _SERVER.shutdown()
            return True
        except Exception as exc:
            log('Falha ao parar proxy: %s' % exc, 'warning')
            return False


def stop():
    return stop_proxy()


__all__ = [
    'PORT', 'URL_HLSRETRY', 'URL_TS_DOWNLOADER',
    'convert_to_m3u8', 'm3u8_to_ts',
    'build_hls_url', 'build_ts_url', 'build_balanced_url',
    'hls_url', 'ts_url', 'balanced_url',
    'probe_hls', 'probe_ts', 'choose_mode',
    'kodiproxy', 'server_run', 'stop_proxy', 'stop', 'is_running',
]
