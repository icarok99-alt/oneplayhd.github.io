# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from six import text_type
from six.moves.urllib.parse import quote
from resources.lib.dns import customdns
from resources.lib.common import make_session, log, DEFAULT_TIMEOUT

try:
    from kodi_six import xbmcaddon
except ImportError:
    import xbmcaddon

customdns()

API_KEY = "92c1507cc18d85290e7a0b96abb37316"
TMDB_BASE_URL = "https://api.themoviedb.org/3"
SESSION = make_session()


def _safe_text(value):
    if value is None:
        return ''
    if isinstance(value, text_type):
        return value
    try:
        return value.decode('utf-8')
    except Exception:
        return text_type(value)


def _addon():
    try:
        return xbmcaddon.Addon()
    except Exception:
        return None


def _setting(key, default=''):
    addon = _addon()
    if addon is None:
        return default
    try:
        value = addon.getSetting(key)
        return value if value not in (None, '') else default
    except Exception:
        return default


def _setting_bool(key, default=False):
    value = _setting(key, 'true' if default else 'false')
    return text_type(value).lower() == 'true'


def _setting_enum(key, values, default=None):
    if not values:
        return default
    try:
        index = int(_setting(key, '0'))
        if 0 <= index < len(values):
            return values[index]
    except Exception:
        pass
    return values[0] if default is None else default


def _language():
    return _setting_enum('tmdb_language', ['pt-BR', 'en-US', 'es-ES'], 'pt-BR')


def _region():
    return _setting_enum('tmdb_region', ['BR', 'US', 'PT', 'ES', 'MX'], 'BR')


def _items_per_page():
    raw = _setting_enum('itensporpagina', ['20', '40', '60'], '20')
    try:
        return max(20, min(60, int(raw)))
    except Exception:
        return 20


def _passes_filters(item):
    if item.get('adult'):
        return False
    if _setting_bool('ocultarsemposter', False):
        if not item.get('poster_path') and not item.get('backdrop_path') and not item.get('still_path'):
            return False
    return True


def get_json(url):
    try:
        response = SESSION.get(url, timeout=DEFAULT_TIMEOUT)
        response.encoding = 'utf-8'
        if response.status_code != 200:
            log('TMDB HTTP {} for {}'.format(response.status_code, url), level=2)
            return {}
        data = response.json()
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        log('TMDB request failed: {}'.format(exc), level=4)
        return {}


def _media_kind(type_):
    return 'tv' if type_ == 'series' else 'movie'


def _build_item(item, type_):
    year_key = 'release_date' if type_ == 'movie' else 'first_air_date'
    year = (item.get(year_key) or '')[:4]
    return {
        'id': text_type(item.get('id', '')),
        'title': _safe_text(item.get('title') or item.get('name') or ''),
        'poster': "https://image.tmdb.org/t/p/w500{}".format(item['poster_path']) if item.get('poster_path') else None,
        'background': "https://image.tmdb.org/t/p/original{}".format(item['backdrop_path']) if item.get('backdrop_path') else None,
        'description': _safe_text(item.get('overview', '')),
        'year': year
    }


def _fetch_paged_results(url_builder, type_, logical_page):
    per_page = _items_per_page()
    pages_needed = max(1, int(per_page / 20))
    start_page = ((max(1, logical_page) - 1) * pages_needed) + 1
    items = []
    for tmdb_page in range(start_page, start_page + pages_needed):
        data = get_json(url_builder(tmdb_page))
        results = data.get('results', [])
        if not results:
            continue
        for item in results:
            if item.get('id') and _passes_filters(item):
                items.append(_build_item(item, type_))
    return items[:per_page]


def get_items(type_, category, page=1):
    media = _media_kind(type_)
    language = _language()
    region = _region()

    def build_url(tmdb_page):
        if category == 'trending':
            return TMDB_BASE_URL + "/trending/{}/week?api_key={}&language={}&page={}".format(media, API_KEY, language, tmdb_page)
        elif category == 'top':
            return TMDB_BASE_URL + "/{}/top_rated?api_key={}&language={}&page={}".format(media, API_KEY, language, tmdb_page)
        elif category == 'latest':
            endpoint = 'airing_today' if media == 'tv' else 'now_playing'
            url = TMDB_BASE_URL + "/{}/{}?api_key={}&language={}&page={}".format(media, endpoint, API_KEY, language, tmdb_page)
            if media == 'movie' and region:
                url += '&region={}'.format(region)
            return url
        else:
            url = TMDB_BASE_URL + "/discover/{}?api_key={}&language={}&page={}".format(media, API_KEY, language, tmdb_page)
            if media == 'movie' and region:
                url += '&region={}'.format(region)
            return url

    return _fetch_paged_results(build_url, type_, int(page))


def get_meta(type_, tmdb_id):
    media = _media_kind(type_)
    url = TMDB_BASE_URL + "/{}/{}?api_key={}&language={}".format(media, tmdb_id, API_KEY, _language())
    data = get_json(url)
    year_key = 'first_air_date' if type_ == 'series' else 'release_date'
    year = (data.get(year_key) or '')[:4]
    return {
        'name': _safe_text(data.get('name') if type_ == 'series' else data.get('title')),
        'description': _safe_text(data.get('overview', '')),
        'poster': "https://image.tmdb.org/t/p/w500{}".format(data['poster_path']) if data.get('poster_path') else None,
        'background': "https://image.tmdb.org/t/p/original{}".format(data['backdrop_path']) if data.get('backdrop_path') else None,
        'year': year
    }


def get_seasons(type_, tmdb_id):
    if type_ != 'series':
        return []

    url = TMDB_BASE_URL + "/tv/{}?api_key={}&language={}".format(tmdb_id, API_KEY, _language())
    data = get_json(url)
    seasons = []
    for season in data.get('seasons', []):
        if season.get('season_number') is None:
            continue
        year = (season.get('air_date') or '')[:4]
        if _setting_bool('ocultarsemposter', False) and not season.get('poster_path'):
            continue
        seasons.append({
            'season_number': season['season_number'],
            'name': _safe_text(season.get('name') or 'Temporada {}'.format(season['season_number'])),
            'poster': "https://image.tmdb.org/t/p/w500{}".format(season['poster_path']) if season.get('poster_path') else None,
            'description': _safe_text(season.get('overview', '')),
            'episode_count': season.get('episode_count', 0),
            'year': year
        })
    return seasons


def get_episodes(type_, tmdb_id, season_number):
    if type_ != 'series':
        return []

    url = TMDB_BASE_URL + "/tv/{}/season/{}?api_key={}&language={}".format(tmdb_id, season_number, API_KEY, _language())
    data = get_json(url)
    episodes = []
    for episode in data.get('episodes', []):
        number = episode.get('episode_number')
        if number is None:
            continue
        year = (episode.get('air_date') or '')[:4]
        if _setting_bool('ocultarsemposter', False) and not episode.get('still_path'):
            continue
        episodes.append({
            'episode_number': number,
            'name': _safe_text(episode.get('name') or 'Episódio {}'.format(number)),
            'poster': "https://image.tmdb.org/t/p/w500{}".format(episode['still_path']) if episode.get('still_path') else None,
            'description': _safe_text(episode.get('overview', '')),
            'id': text_type(episode.get('id', '')),
            'year': year
        })
    return episodes


def search(type_, query, page=1):
    query = _safe_text(query).strip()
    if not query:
        return []

    encoded_query = quote(query, safe='')
    media = _media_kind(type_)
    language = _language()

    def build_url(tmdb_page):
        return TMDB_BASE_URL + "/search/{}?api_key={}&language={}&query={}&page={}".format(
            media, API_KEY, language, encoded_query, tmdb_page
        )

    return _fetch_paged_results(build_url, type_, int(page))


def get_imdb_id_tmdb(tmdb_id, media_type):
    media = 'tv' if media_type == 'series' else media_type
    url = TMDB_BASE_URL + "/{}/{}/external_ids?api_key={}".format(text_type(media), text_type(tmdb_id), text_type(API_KEY))
    data = get_json(url)
    imdb_id = data.get('imdb_id')
    if not imdb_id:
        log('TMDB external_ids sem imdb_id para {} {}'.format(media, tmdb_id), level=2)
    return imdb_id
