# scrapy.py
# -*- coding: utf-8 -*-
import base64

# Lista de tuplas (nome de exibição)
APKS_LIST = [
    ("OnePlay Alpha - PRINCIPAL",  "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlBbHBoYS5hcGs="),
    ("OnePlay Xtream - ESSENCIAL",  "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlYdHJlYW0uYXBr"),
    ("Aptoide TV - LOJA APPS ALTERNATIVO",  "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL0FwdG9pZFRWLmFwaw=="),
    ("SmartTube - YOUTUBE ALTERNATIVO",  "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL1NtYXJ0VHViZS5hcGs="),
    ("WARP VPN - RESOLVEDOR DE DNS",  "aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL1ZQTi5hcGs"),
]

def safe_b64decode(data: str) -> str:
    """Decodifica base64 mesmo se faltar padding"""
    # adiciona "=" até o comprimento ser múltiplo de 4
    missing_padding = len(data) % 4
    if missing_padding:
        data += "=" * (4 - missing_padding)
    return base64.b64decode(data.encode("utf-8")).decode("utf-8")

def listar_apks():
    """
    Retorna uma lista de tuplas (nome, url) a partir de APKS_LIST.
    O 'nome' será exibido no diálogo, e o 'url' (decodificado de Base64)
    será usado para download.
    """
    resultado = []
    for nome, b64 in APKS_LIST:
        url = safe_b64decode(b64)
        resultado.append((nome, url))
    return resultado


if __name__ == "__main__":
    for nome, url in listar_apks():
        print(f"{nome} → {url}")
